<?php
echo "=== Server Info ===\n";
echo "PHP Version: " . phpversion() . "\n";
echo "Sistema Operativo: " . PHP_OS . "\n";
echo "Extensiones cargadas: " . implode(", ", get_loaded_extensions()) . "\n";
