<?php
// Obtener datos enviados por POST
$input = file_get_contents("php://input");
parse_str($input, $data);

echo "=== Datos recibidos ===\n";
print_r($data);

// Ejemplo de cálculo
if (isset($data['x']) && isset($data['y'])) {
    $suma = $data['x'] + $data['y'];
    echo "\nResultado de x + y = $suma\n";
}
