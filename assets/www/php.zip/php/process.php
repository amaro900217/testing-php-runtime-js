<?php
// Obtener datos enviados por POST
$data = $_POST;

echo "=== Datos recibidos ===\n";
print_r($data);

// Ejemplo de cálculo
if (isset($data['x']) && isset($data['y'])) {
    $suma = $data['x'] + $data['y'];
    echo "\nResultado de x + y = $suma\n";
}

