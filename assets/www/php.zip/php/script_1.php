<?php
echo "Hola desde script_1.php\n";
echo "Fecha actual: " . date("Y-m-d H:i:s") . "\n";
