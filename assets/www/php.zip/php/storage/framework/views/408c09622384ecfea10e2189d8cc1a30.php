
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post">
        <h2><?php echo e($post->title); ?></h2>
        <p><?php echo e($post->content); ?></p>
        <small>Creado: <?php echo e($post->created_at->format('d/m/Y')); ?></small>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/linux/Documents/GitHub/testing-php-runtime-js/assets/www/php/resources/views/api/posts.blade.php ENDPATH**/ ?>