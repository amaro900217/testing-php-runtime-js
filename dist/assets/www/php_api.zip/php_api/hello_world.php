<?php
$timestamp = date("Y-m-d H:i:s");
echo "Hola desde PHP, corriendo como API REST dentro de este navegador!! Timestamp: $timestamp";
?>
