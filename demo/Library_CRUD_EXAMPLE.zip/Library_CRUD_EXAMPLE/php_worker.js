const STR = "string";
const NUM = "number";
class PhpBase extends EventTarget {
  constructor(PhpBinary, args = {}) {
    super();
    this.onerror = function() {
    };
    this.onoutput = function() {
    };
    this.onready = function() {
    };
    Object.defineProperty(this, "encoder", { value: new TextEncoder() });
    Object.defineProperty(this, "buffers", { value: {
      stdin: [],
      stdout: new EventBuffer(this, "output", -1),
      stderr: new EventBuffer(this, "error", -1)
    } });
    Object.freeze(this.buffers);
    const defaults = {
      stdin: () => this.buffers.stdin.shift() ?? null,
      stdout: (byte) => this.buffers.stdout.push(byte),
      stderr: (byte) => this.buffers.stderr.push(byte),
      postRun: () => {
        const event = new _Event("ready");
        this.onready(event);
        this.dispatchEvent(event);
      }
    };
    const fixed = { onRefresh: /* @__PURE__ */ new Set() };
    const phpSettings = globalThis.phpSettings ?? {};
    this.binary = new PhpBinary(Object.assign({}, defaults, phpSettings, args, fixed)).then((php) => {
      php.ccall(
        "pib_init",
        NUM,
        [STR],
        []
      );
      return php;
    }).catch((error) => console.error(error));
  }
  inputString(byteString) {
    this.input(this.encoder.encode(byteString));
  }
  input(items) {
    this.buffers.stdin.push(...items);
  }
  flush() {
    this.buffers.stdout.flush();
    this.buffers.stderr.flush();
  }
  run(phpCode) {
    return this.binary.then((php) => php.ccall(
      "pib_run",
      NUM,
      [STR],
      [`?>${phpCode}`],
      { async: true }
    )).finally(() => this.flush());
  }
  exec(phpCode) {
    return this.binary.then((php) => php.ccall(
      "pib_exec",
      STR,
      [STR],
      [phpCode],
      { async: true }
    )).finally(() => this.flush());
  }
  tokenize(phpCode) {
    return this.binary.then((php) => php.ccall(
      "pib_tokenize",
      STR,
      [STR],
      [phpCode],
      { async: true }
    ));
  }
  refresh() {
    const call = this.binary.then((php) => {
      for (const callback of php.onRefresh) {
        callback();
      }
      return php.ccall(
        "pib_refresh",
        NUM,
        [],
        [],
        { async: true }
      );
    });
    call.catch((error) => console.error(error));
    return call;
  }
}
const _Event = globalThis.CustomEvent ?? class extends globalThis.Event {
  constructor(name, options = {}) {
    super(name, options);
    this.detail = options.detail;
  }
};
class EventBuffer {
  constructor(target, eventType, maxLength) {
    Object.defineProperty(this, "target", { value: target });
    Object.defineProperty(this, "buffer", { value: [] });
    Object.defineProperty(this, "eventType", { value: eventType });
    Object.defineProperty(this, "maxLength", { value: maxLength });
    Object.defineProperty(this, "decoder", { value: new TextDecoder() });
  }
  push(...items) {
    this.buffer.push(...items);
    const end = this.buffer.length - 1;
    if (this.maxLength === -1 && this.buffer[end] === 10) {
      this.flush();
    }
    if (this.maxLength >= 0 && this.buffer.length >= this.maxLength) {
      this.flush();
    }
  }
  flush() {
    if (!this.buffer.length) {
      return;
    }
    const event = new _Event(this.eventType, {
      detail: [this.decoder.decode(new Uint8Array(this.buffer))]
    });
    if (this.target["on" + this.eventType]) {
      if (this.target["on" + this.eventType](event) === false) {
        return;
      }
    }
    if (!this.target.dispatchEvent(event)) {
      return;
    }
    this.buffer.splice(0);
  }
}
var PHP = (() => {
  var _scriptDir = import.meta.url;
  return function(moduleArg = {}) {
    var Module = moduleArg;
    var readyPromiseResolve, readyPromiseReject;
    Module["ready"] = new Promise((resolve, reject) => {
      readyPromiseResolve = resolve;
      readyPromiseReject = reject;
    });
    ["_pib_init", "_pib_destroy", "_pib_run", "_pib_exec", "_pib_refresh", "_main", "_php_embed_init", "_php_embed_shutdown", "_zend_eval_string", "_vrzno_expose_inc_zrefcount", "_vrzno_expose_dec_zrefcount", "_vrzno_expose_zrefcount", "_vrzno_expose_inc_crefcount", "_vrzno_expose_dec_crefcount", "_vrzno_expose_crefcount", "_vrzno_expose_efree", "_vrzno_expose_create_bool", "_vrzno_expose_create_null", "_vrzno_expose_create_undef", "_vrzno_expose_create_long", "_vrzno_expose_create_double", "_vrzno_expose_create_string", "_vrzno_expose_create_object_for_target", "_vrzno_expose_create_params", "_vrzno_expose_set_param", "_vrzno_expose_zval_is_target", "_vrzno_expose_object_keys", "_vrzno_expose_zval_dump", "_vrzno_expose_type", "_vrzno_expose_callable", "_vrzno_expose_long", "_vrzno_expose_double", "_vrzno_expose_string", "_vrzno_expose_property_pointer", "_vrzno_exec_callback", "_vrzno_del_callback", "_fflush", "_pib_tokenize", "_exec_callback", "_del_callback", "onRuntimeInitialized"].forEach((prop) => {
      if (!Object.getOwnPropertyDescriptor(Module["ready"], prop)) {
        Object.defineProperty(Module["ready"], prop, { get: () => abort("You are getting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js"), set: () => abort("You are setting " + prop + " on the Promise object, instead of the instance. Use .then() to get called back with the instance, see the MODULARIZE docs in src/settings.js") });
      }
    });
    Module.WeakerMap = Module.WeakerMap || class WeakerMap {
      constructor(entries) {
        this.registry = new FinReg((held) => this.delete(held));
        this.map = /* @__PURE__ */ new Map();
        entries && entries.forEach(([key, value]) => this.set(key, value));
      }
      get size() {
        return this.map.size;
      }
      clear() {
        this.map.clear();
      }
      delete(key) {
        this.map.delete(key);
      }
      [Symbol.iterator]() {
        const mapIterator = this.map[Symbol.iterator]();
        return { next: () => {
          do {
            const entry = mapIterator.next();
            if (entry.done) {
              return { done: true };
            }
            const [key, ref] = entry.value;
            const value = ref.deref();
            if (!value) {
              this.map.delete(key);
              continue;
            }
            return { done: false, value: [key, value] };
          } while (true);
        } };
      }
      entries() {
        return { [Symbol.iterator]: () => this[Symbol.iterator]() };
      }
      forEach(callback) {
        for (const [k, v] of this) {
          callback(v, k, this);
        }
      }
      get(key) {
        if (!this.has(key)) {
          return;
        }
        return this.map.get(key).deref();
      }
      has(key) {
        if (!this.map.has(key)) {
          return false;
        }
        const result = this.map.get(key).deref();
        if (!result) {
          this.map.delete(key);
        }
        return result;
      }
      keys() {
        return [...this].map((v) => v[0]);
      }
      set(key, value) {
        if (typeof value !== "function" && typeof value !== "object") {
          throw new Error("WeakerMap values must be objects.");
        }
        if (this.map.has(key)) {
          this.registry.unregister(this.get(key));
        }
        this.registry.register(value, key, value);
        return this.map.set(key, new wRef(value));
      }
      values() {
        return [...this].map((v) => v[1]);
      }
    };
    const FinReg = globalThis.FinalizationRegistry || class {
      register() {
      }
      unregister() {
      }
    };
    const wRef = globalThis.WeakRef || class {
      constructor(val) {
        this.val = val;
      }
      deref() {
        return this.val;
      }
    };
    Module.UniqueIndex = Module.UniqueIndex || class UniqueIndex {
      constructor() {
        this.byObject = /* @__PURE__ */ new WeakMap();
        this.byInteger = new Module.WeakerMap();
        this.id = 0;
        Object.defineProperty(this, "clear", { configurable: false, writable: false, value: () => {
          this.byInteger.clear();
        } });
        Object.defineProperty(this, "add", { configurable: false, writable: false, value: (callback) => {
          if (this.byObject.has(callback)) {
            const id = this.byObject.get(callback);
            return id;
          }
          const newid = ++this.id;
          this.byObject.set(callback, newid);
          this.byInteger.set(newid, callback);
          return newid;
        } });
        Object.defineProperty(this, "has", { configurable: false, writable: false, value: (obj) => {
          if (this.byObject.has(obj)) {
            const id = this.byObject.get(obj);
            return this.byInteger.has(id);
          }
        } });
        Object.defineProperty(this, "hasId", { configurable: false, writable: false, value: (address) => {
          if (this.byInteger.has(address)) {
            return this.byInteger.get(address);
          }
        } });
        Object.defineProperty(this, "get", { configurable: false, writable: false, value: (address) => {
          if (this.byInteger.has(address)) {
            return this.byInteger.get(address);
          }
        } });
        Object.defineProperty(this, "getId", { configurable: false, writable: false, value: (obj) => {
          if (this.byObject.has(obj)) {
            return this.byObject.get(obj);
          }
        } });
        Object.defineProperty(this, "remove", { configurable: false, writable: false, value: (address) => {
          const obj = this.byInteger.get(address);
          if (obj) {
            this.byObject.delete(obj);
            this.byInteger.delete(address);
          }
        } });
      }
    };
    const zvalSym = Symbol("ZVAL");
    Module.marshalObject = (zvalPtr) => {
      const nativeTarget = Module.ccall("vrzno_expose_zval_is_target", "number", ["number"], [zvalPtr]);
      if (nativeTarget && Module.targets.hasId(nativeTarget)) {
        return Module.targets.get(nativeTarget);
      }
      const proxy = new Proxy({}, { ownKeys: (target) => {
        const keysLoc = Module.ccall("vrzno_expose_object_keys", "number", ["number"], [zvalPtr]);
        const keyJson = UTF8ToString(keysLoc);
        const keys = JSON.parse(keyJson);
        _free(keysLoc);
        keys.push(...Reflect.ownKeys(target));
        return keys;
      }, has: (target, prop) => {
        if (typeof prop === "symbol") {
          return false;
        }
        const len2 = lengthBytesUTF8(prop) + 1;
        const namePtr = _malloc(len2);
        stringToUTF8(prop, namePtr, len2);
        const retPtr = Module.ccall("vrzno_expose_property_pointer", "number", ["number", "number"], [zvalPtr, namePtr]);
        return !!retPtr;
      }, get: (target, prop, receiver) => {
        if (typeof prop === "symbol") {
          return target[prop];
        }
        const len2 = lengthBytesUTF8(prop) + 1;
        const namePtr = _malloc(len2);
        stringToUTF8(prop, namePtr, len2);
        const retPtr = Module.ccall("vrzno_expose_property_pointer", "number", ["number", "number"], [zvalPtr, namePtr]);
        const proxy2 = Module.zvalToJS(retPtr);
        if (proxy2 && ["function", "object"].includes(typeof proxy2)) {
          Module.zvalMap.set(proxy2, retPtr);
          Module._zvalMap.set(retPtr, proxy2);
        }
        _free(namePtr);
        return proxy2 ?? Reflect.get(target, prop);
      }, getOwnPropertyDescriptor: (target, prop) => {
        if (typeof prop === "symbol" || prop in target) {
          return Reflect.getOwnPropertyDescriptor(target, prop);
        }
        const len2 = lengthBytesUTF8(prop) + 1;
        const namePtr = _malloc(len2);
        stringToUTF8(prop, namePtr, len2);
        const retPtr = Module.ccall("vrzno_expose_property_pointer", "number", ["number", "number"], [zvalPtr, namePtr]);
        const proxy2 = Module.zvalToJS(retPtr);
        if (proxy2 && ["function", "object"].includes(typeof proxy2)) {
          Module.zvalMap.set(proxy2, retPtr);
          Module._zvalMap.set(retPtr, proxy2);
        }
        _free(namePtr);
        return { configurable: true, enumerable: true, value: target[prop] };
      } });
      Object.defineProperty(proxy, zvalSym, { value: `PHP_@{${zvalPtr}}` });
      Module.zvalMap.set(proxy, zvalPtr);
      Module._zvalMap.set(zvalPtr, proxy);
      if (!Module.targets.has(proxy)) {
        Module.targets.add(proxy);
        Module.ccall("vrzno_expose_inc_zrefcount", "number", ["number"], [zvalPtr]);
        Module.fRegistry.register(proxy, zvalPtr, proxy);
      }
      return proxy;
    };
    Module.callableToJs = Module.callableToJs || ((funcPtr) => {
      if (Module.callables.has(funcPtr)) {
        return Module.callables.get(funcPtr);
      }
      const wrapped = (...args) => {
        let paramPtrs = [], paramsPtr = null;
        if (args.length) {
          paramsPtr = Module.ccall("vrzno_expose_create_params", "number", ["number"], [args.length]);
          paramPtrs = args.map((a) => Module.jsToZval(a));
          paramPtrs.forEach((paramPtr, i2) => {
            Module.ccall("vrzno_expose_set_param", "number", ["number", "number", "number"], [paramsPtr, i2, paramPtr]);
          });
        }
        const zvalPtr = Module.ccall("vrzno_exec_callback", "number", ["number", "number", "number"], [funcPtr, paramsPtr, args.length]);
        if (args.length) {
          paramPtrs.forEach((p, i2) => {
            if (!args[i2] || !["function", "object"].includes(typeof args[i2])) {
              Module.ccall("vrzno_expose_efree", "number", ["number"], [p]);
            }
          });
          Module.ccall("vrzno_expose_efree", "number", ["number", "number"], [paramsPtr, false]);
        }
        if (zvalPtr) {
          const result = Module.zvalToJS(zvalPtr);
          if (!result || !["function", "object"].includes(typeof result)) {
            Module.ccall("vrzno_expose_efree", "number", ["number"], [zvalPtr]);
          }
          return result;
        }
      };
      Object.defineProperty(wrapped, "name", { value: `PHP_@{${funcPtr}}` });
      Module.ccall("vrzno_expose_inc_crefcount", "number", ["number"], [funcPtr]);
      Module.callables.set(funcPtr, wrapped);
      return wrapped;
    });
    Module.zvalToJS = Module.zvalToJS || ((zvalPtr) => {
      if (Module._zvalMap.has(zvalPtr)) {
        return Module._zvalMap.get(zvalPtr);
      }
      const IS_UNDEF = 0;
      const IS_NULL = 1;
      const IS_FALSE = 2;
      const IS_TRUE = 3;
      const IS_LONG = 4;
      const IS_DOUBLE = 5;
      const IS_STRING = 6;
      const IS_OBJECT = 8;
      const callable = Module.ccall("vrzno_expose_callable", "number", ["number"], [zvalPtr]);
      let valPtr;
      if (callable) {
        const nativeTarget = Module.ccall("vrzno_expose_zval_is_target", "number", ["number"], [zvalPtr]);
        if (nativeTarget) {
          return Module.targets.get(nativeTarget);
        }
        const wrapped = nativeTarget ? Module.targets.get(nativeTarget) : Module.callableToJs(callable);
        if (!Module.targets.has(wrapped)) {
          Module.targets.add(wrapped);
          Module.ccall("vrzno_expose_inc_zrefcount", "number", ["number"], [zvalPtr]);
        }
        Module.zvalMap.set(wrapped, zvalPtr);
        Module._zvalMap.set(zvalPtr, wrapped);
        Module.fRegistry.register(wrapped, zvalPtr, wrapped);
        return wrapped;
      }
      const type = Module.ccall("vrzno_expose_type", "number", ["number"], [zvalPtr]);
      switch (type) {
        case IS_UNDEF:
          return void 0;
        case IS_NULL:
          return null;
        case IS_TRUE:
          return true;
        case IS_FALSE:
          return false;
        case IS_LONG:
          return Module.ccall("vrzno_expose_long", "number", ["number"], [zvalPtr]);
        case IS_DOUBLE:
          valPtr = Module.ccall("vrzno_expose_double", "number", ["number"], [zvalPtr]);
          if (!valPtr) {
            return null;
          }
          return getValue(valPtr, "double");
        case IS_STRING:
          valPtr = Module.ccall("vrzno_expose_string", "number", ["number"], [zvalPtr]);
          if (!valPtr) {
            return null;
          }
          return UTF8ToString(valPtr);
        case IS_OBJECT:
          const proxy = Module.marshalObject(zvalPtr);
          return proxy;
        default:
          return null;
      }
    });
    Module.jsToZval = Module.jsToZval || ((value) => {
      let zvalPtr;
      if (typeof value === "undefined") {
        zvalPtr = Module.ccall("vrzno_expose_create_undef", "number", [], []);
      } else if (value === null) {
        zvalPtr = Module.ccall("vrzno_expose_create_null", "number", [], []);
      } else if ([true, false].includes(value)) {
        zvalPtr = Module.ccall("vrzno_expose_create_bool", "number", ["number"], [value]);
      } else if (value && ["function", "object"].includes(typeof value)) {
        let index, existed;
        if (!Module.targets.has(value)) {
          index = Module.targets.add(value);
          existed = false;
        } else {
          index = Module.targets.getId(value);
          existed = true;
        }
        const isFunction = typeof value === "function" ? index : 0;
        const isConstructor = isFunction && !!(value.prototype && value.prototype.constructor);
        zvalPtr = Module.ccall("vrzno_expose_create_object_for_target", "number", ["number", "number", "number"], [index, isFunction, isConstructor]);
        Module.zvalMap.set(value, zvalPtr);
        Module._zvalMap.set(zvalPtr, value);
        if (!existed) {
          Module.ccall("vrzno_expose_inc_zrefcount", "number", ["number"], [zvalPtr]);
          Module.fRegistry.register(value, zvalPtr, value);
        }
      } else if (typeof value === "number") {
        if (Number.isInteger(value)) {
          zvalPtr = Module.ccall("vrzno_expose_create_long", "number", ["number"], [value]);
        } else if (Number.isFinite(value)) {
          zvalPtr = Module.ccall("vrzno_expose_create_double", "number", ["number"], [value]);
        }
      } else if (typeof value === "string") {
        const len2 = lengthBytesUTF8(value) + 1;
        const strLoc2 = _malloc(len2);
        stringToUTF8(value, strLoc2, len2);
        zvalPtr = Module.ccall("vrzno_expose_create_string", "number", ["number"], [strLoc2]);
        _free(strLoc2);
      }
      return zvalPtr;
    });
    Module.PdoD1Driver = Module.PdoD1Driver || class PdoD1Driver {
      prepare(db, query) {
        console.log("prepare", { db, query });
        return db.prepare(query);
      }
      doer(db, query) {
        console.log("doer", { db, query });
      }
    };
    HEAP8 = new Int8Array(1);
    Module.zvalMap = /* @__PURE__ */ new WeakMap();
    Module._zvalMap = Module._zvalMap || new Module.WeakerMap();
    Module.fRegistry = Module.fRegistry || new FinReg((zvalPtr) => {
      console.log("Garbage collecting! zVal@" + zvalPtr);
      Module.ccall("vrzno_expose_dec_zrefcount", "number", ["number"], [zvalPtr]);
    });
    Module.bufferMaps = /* @__PURE__ */ new WeakMap();
    Module.callables = Module.callables || new Module.WeakerMap();
    Module.targets = Module.targets || new Module.UniqueIndex();
    Module.classes = Module.classes || /* @__PURE__ */ new WeakMap();
    Module._classes = Module._classes || new Module.WeakerMap();
    Module.PdoParams = /* @__PURE__ */ new WeakMap();
    Module.pdoDriver = Module.pdoDriver || new Module.PdoD1Driver();
    Module.targets.add(globalThis);
    Module.onRefresh = Module.onRefresh || /* @__PURE__ */ new Set();
    Module.onRefresh.add(() => {
      Module.callables.clear();
      Module.targets.clear();
      Module._classes.clear();
      Module._zvalMap.clear();
      Module.targets.byObject.set(globalThis, 1);
      Module.targets.byInteger.set(1, globalThis);
    });
    var moduleOverrides = Object.assign({}, Module);
    var thisProgram = "./this.program";
    var quit_ = (status, toThrow) => {
      throw toThrow;
    };
    var ENVIRONMENT_IS_WEB = true;
    if (Module["ENVIRONMENT"]) {
      throw new Error("Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -sENVIRONMENT=web or -sENVIRONMENT=node)");
    }
    var scriptDirectory = "";
    function locateFile(path) {
      if (Module["locateFile"]) {
        return Module["locateFile"](path, scriptDirectory);
      }
      return scriptDirectory + path;
    }
    var read_, readAsync;
    {
      if (typeof document != "undefined" && document.currentScript) {
        scriptDirectory = document.currentScript.src;
      }
      if (_scriptDir) {
        scriptDirectory = _scriptDir;
      }
      if (scriptDirectory.indexOf("blob:") !== 0) {
        scriptDirectory = scriptDirectory.substr(0, scriptDirectory.replace(/[?#].*/, "").lastIndexOf("/") + 1);
      } else {
        scriptDirectory = "";
      }
      if (!(typeof window == "object" || typeof importScripts == "function")) throw new Error("not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)");
      {
        read_ = (url) => {
          var xhr = new XMLHttpRequest();
          xhr.open("GET", url, false);
          xhr.send(null);
          return xhr.responseText;
        };
        readAsync = (url, onload, onerror) => {
          var xhr = new XMLHttpRequest();
          xhr.open("GET", url, true);
          xhr.responseType = "arraybuffer";
          xhr.onload = () => {
            if (xhr.status == 200 || xhr.status == 0 && xhr.response) {
              onload(xhr.response);
              return;
            }
            onerror();
          };
          xhr.onerror = onerror;
          xhr.send(null);
        };
      }
    }
    var out = Module["print"] || console.log.bind(console);
    var err = Module["printErr"] || console.error.bind(console);
    Object.assign(Module, moduleOverrides);
    moduleOverrides = null;
    checkIncomingModuleAPI();
    if (Module["arguments"]) Module["arguments"];
    legacyModuleProp("arguments", "arguments_");
    if (Module["thisProgram"]) thisProgram = Module["thisProgram"];
    legacyModuleProp("thisProgram", "thisProgram");
    if (Module["quit"]) quit_ = Module["quit"];
    legacyModuleProp("quit", "quit_");
    assert(typeof Module["memoryInitializerPrefixURL"] == "undefined", "Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead");
    assert(typeof Module["pthreadMainPrefixURL"] == "undefined", "Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead");
    assert(typeof Module["cdInitializerPrefixURL"] == "undefined", "Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead");
    assert(typeof Module["filePackagePrefixURL"] == "undefined", "Module.filePackagePrefixURL option was removed, use Module.locateFile instead");
    assert(typeof Module["read"] == "undefined", "Module.read option was removed (modify read_ in JS)");
    assert(typeof Module["readAsync"] == "undefined", "Module.readAsync option was removed (modify readAsync in JS)");
    assert(typeof Module["readBinary"] == "undefined", "Module.readBinary option was removed (modify readBinary in JS)");
    assert(typeof Module["setWindowTitle"] == "undefined", "Module.setWindowTitle option was removed (modify setWindowTitle in JS)");
    assert(typeof Module["TOTAL_MEMORY"] == "undefined", "Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY");
    legacyModuleProp("read", "read_");
    legacyModuleProp("readAsync", "readAsync");
    legacyModuleProp("readBinary", "readBinary");
    legacyModuleProp("setWindowTitle", "setWindowTitle");
    var NODEFS = "NODEFS is no longer included by default; build with -lnodefs.js";
    assert(true, "worker environment detected but not enabled at build time.  Add 'worker' to `-sENVIRONMENT` to enable.");
    assert(true, "node environment detected but not enabled at build time.  Add 'node' to `-sENVIRONMENT` to enable.");
    assert(true, "shell environment detected but not enabled at build time.  Add 'shell' to `-sENVIRONMENT` to enable.");
    var wasmBinary;
    if (Module["wasmBinary"]) wasmBinary = Module["wasmBinary"];
    legacyModuleProp("wasmBinary", "wasmBinary");
    var noExitRuntime = Module["noExitRuntime"] || false;
    legacyModuleProp("noExitRuntime", "noExitRuntime");
    if (typeof WebAssembly != "object") {
      abort("no native wasm support detected");
    }
    var wasmMemory;
    var ABORT = false;
    var EXITSTATUS;
    function assert(condition, text) {
      if (!condition) {
        abort("Assertion failed" + (text ? ": " + text : ""));
      }
    }
    var HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
    function updateMemoryViews() {
      var b = wasmMemory.buffer;
      Module["HEAP8"] = HEAP8 = new Int8Array(b);
      Module["HEAP16"] = HEAP16 = new Int16Array(b);
      Module["HEAP32"] = HEAP32 = new Int32Array(b);
      Module["HEAPU8"] = HEAPU8 = new Uint8Array(b);
      Module["HEAPU16"] = HEAPU16 = new Uint16Array(b);
      Module["HEAPU32"] = HEAPU32 = new Uint32Array(b);
      Module["HEAPF32"] = HEAPF32 = new Float32Array(b);
      Module["HEAPF64"] = HEAPF64 = new Float64Array(b);
    }
    assert(!Module["STACK_SIZE"], "STACK_SIZE can no longer be set at runtime.  Use -sSTACK_SIZE at link time");
    assert(typeof Int32Array != "undefined" && typeof Float64Array !== "undefined" && Int32Array.prototype.subarray != void 0 && Int32Array.prototype.set != void 0, "JS engine does not provide full typed array support");
    assert(!Module["wasmMemory"], "Use of `wasmMemory` detected.  Use -sIMPORTED_MEMORY to define wasmMemory externally");
    assert(!Module["INITIAL_MEMORY"], "Detected runtime INITIAL_MEMORY setting.  Use -sIMPORTED_MEMORY to define wasmMemory dynamically");
    var wasmTable;
    function writeStackCookie() {
      var max2 = _emscripten_stack_get_end();
      assert((max2 & 3) == 0);
      if (max2 == 0) {
        max2 += 4;
      }
      HEAPU32[max2 >>> 2] = 34821223;
      HEAPU32[max2 + 4 >>> 2] = 2310721022;
      HEAPU32[0 >>> 2] = 1668509029;
    }
    function checkStackCookie() {
      if (ABORT) return;
      var max2 = _emscripten_stack_get_end();
      if (max2 == 0) {
        max2 += 4;
      }
      var cookie1 = HEAPU32[max2 >>> 2];
      var cookie2 = HEAPU32[max2 + 4 >>> 2];
      if (cookie1 != 34821223 || cookie2 != 2310721022) {
        abort(`Stack overflow! Stack cookie has been overwritten at ${ptrToString(max2)}, expected hex dwords 0x89BACDFE and 0x2135467, but received ${ptrToString(cookie2)} ${ptrToString(cookie1)}`);
      }
      if (HEAPU32[0 >>> 2] != 1668509029) {
        abort("Runtime error: The application has corrupted its heap memory area (address zero)!");
      }
    }
    (function() {
      var h16 = new Int16Array(1);
      var h8 = new Int8Array(h16.buffer);
      h16[0] = 25459;
      if (h8[0] !== 115 || h8[1] !== 99) throw "Runtime error: expected the system to be little-endian! (Run with -sSUPPORT_BIG_ENDIAN to bypass)";
    })();
    var __ATPRERUN__ = [];
    var __ATINIT__ = [];
    var __ATMAIN__ = [];
    var __ATEXIT__ = [];
    var __ATPOSTRUN__ = [];
    var runtimeInitialized = false;
    var runtimeExited = false;
    var runtimeKeepaliveCounter = 0;
    function keepRuntimeAlive() {
      return noExitRuntime || runtimeKeepaliveCounter > 0;
    }
    function preRun() {
      if (Module["preRun"]) {
        if (typeof Module["preRun"] == "function") Module["preRun"] = [Module["preRun"]];
        while (Module["preRun"].length) {
          addOnPreRun(Module["preRun"].shift());
        }
      }
      callRuntimeCallbacks(__ATPRERUN__);
    }
    function initRuntime() {
      assert(!runtimeInitialized);
      runtimeInitialized = true;
      checkStackCookie();
      if (!Module["noFSInit"] && !FS.init.initialized) FS.init();
      FS.ignorePermissions = false;
      SOCKFS.root = FS.mount(SOCKFS, {}, null);
      PIPEFS.root = FS.mount(PIPEFS, {}, null);
      callRuntimeCallbacks(__ATINIT__);
    }
    function preMain() {
      checkStackCookie();
      callRuntimeCallbacks(__ATMAIN__);
    }
    function exitRuntime() {
      assert(!runtimeExited);
      Asyncify.state = Asyncify.State.Disabled;
      checkStackCookie();
      ___funcs_on_exit();
      callRuntimeCallbacks(__ATEXIT__);
      FS.quit();
      IDBFS.quit();
      runtimeExited = true;
    }
    function postRun() {
      checkStackCookie();
      if (Module["postRun"]) {
        if (typeof Module["postRun"] == "function") Module["postRun"] = [Module["postRun"]];
        while (Module["postRun"].length) {
          addOnPostRun(Module["postRun"].shift());
        }
      }
      callRuntimeCallbacks(__ATPOSTRUN__);
    }
    function addOnPreRun(cb) {
      __ATPRERUN__.unshift(cb);
    }
    function addOnInit(cb) {
      __ATINIT__.unshift(cb);
    }
    function addOnPostRun(cb) {
      __ATPOSTRUN__.unshift(cb);
    }
    assert(Math.imul, "This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
    assert(Math.fround, "This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
    assert(Math.clz32, "This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
    assert(Math.trunc, "This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill");
    var runDependencies = 0;
    var runDependencyWatcher = null;
    var dependenciesFulfilled = null;
    var runDependencyTracking = {};
    function getUniqueRunDependency(id) {
      var orig = id;
      while (1) {
        if (!runDependencyTracking[id]) return id;
        id = orig + Math.random();
      }
    }
    function addRunDependency(id) {
      runDependencies++;
      if (Module["monitorRunDependencies"]) {
        Module["monitorRunDependencies"](runDependencies);
      }
      if (id) {
        assert(!runDependencyTracking[id]);
        runDependencyTracking[id] = 1;
        if (runDependencyWatcher === null && typeof setInterval != "undefined") {
          runDependencyWatcher = setInterval(() => {
            if (ABORT) {
              clearInterval(runDependencyWatcher);
              runDependencyWatcher = null;
              return;
            }
            var shown = false;
            for (var dep in runDependencyTracking) {
              if (!shown) {
                shown = true;
                err("still waiting on run dependencies:");
              }
              err("dependency: " + dep);
            }
            if (shown) {
              err("(end of list)");
            }
          }, 1e4);
        }
      } else {
        err("warning: run dependency added without ID");
      }
    }
    function removeRunDependency(id) {
      runDependencies--;
      if (Module["monitorRunDependencies"]) {
        Module["monitorRunDependencies"](runDependencies);
      }
      if (id) {
        assert(runDependencyTracking[id]);
        delete runDependencyTracking[id];
      } else {
        err("warning: run dependency removed without ID");
      }
      if (runDependencies == 0) {
        if (runDependencyWatcher !== null) {
          clearInterval(runDependencyWatcher);
          runDependencyWatcher = null;
        }
        if (dependenciesFulfilled) {
          var callback = dependenciesFulfilled;
          dependenciesFulfilled = null;
          callback();
        }
      }
    }
    function abort(what) {
      if (Module["onAbort"]) {
        Module["onAbort"](what);
      }
      what = "Aborted(" + what + ")";
      err(what);
      ABORT = true;
      EXITSTATUS = 1;
      if (what.indexOf("RuntimeError: unreachable") >= 0) {
        what += '. "unreachable" may be due to ASYNCIFY_STACK_SIZE not being large enough (try increasing it)';
      }
      var e = new WebAssembly.RuntimeError(what);
      readyPromiseReject(e);
      throw e;
    }
    var dataURIPrefix = "data:application/octet-stream;base64,";
    function isDataURI(filename) {
      return filename.startsWith(dataURIPrefix);
    }
    function isFileURI(filename) {
      return filename.startsWith("file://");
    }
    function createExportWrapper(name, fixedasm) {
      return function() {
        var displayName = name;
        var asm = fixedasm;
        {
          asm = Module["asm"];
        }
        assert(runtimeInitialized, "native function `" + displayName + "` called before runtime initialization");
        assert(!runtimeExited, "native function `" + displayName + "` called after runtime exit (use NO_EXIT_RUNTIME to keep it alive after main() exits)");
        if (!asm[name]) {
          assert(asm[name], "exported native function `" + displayName + "` not found");
        }
        return asm[name].apply(null, arguments);
      };
    }
    var wasmBinaryFile;
    if (Module["locateFile"]) {
      wasmBinaryFile = "php-web.mjs.wasm";
      if (!isDataURI(wasmBinaryFile)) {
        wasmBinaryFile = locateFile(wasmBinaryFile);
      }
    } else {
      wasmBinaryFile = new URL("php-web.mjs.wasm", import.meta.url).href;
    }
    function getBinarySync(file) {
      if (file == wasmBinaryFile && wasmBinary) {
        return new Uint8Array(wasmBinary);
      }
      throw "both async and sync fetching of the wasm failed";
    }
    function getBinaryPromise(binaryFile) {
      if (!wasmBinary && ENVIRONMENT_IS_WEB) {
        if (typeof fetch == "function") {
          return fetch(binaryFile, { credentials: "same-origin" }).then((response) => {
            if (!response["ok"]) {
              throw "failed to load wasm binary file at '" + binaryFile + "'";
            }
            return response["arrayBuffer"]();
          }).catch(() => getBinarySync(binaryFile));
        }
      }
      return Promise.resolve().then(() => getBinarySync(binaryFile));
    }
    function instantiateArrayBuffer(binaryFile, imports, receiver) {
      return getBinaryPromise(binaryFile).then((binary) => WebAssembly.instantiate(binary, imports)).then((instance) => instance).then(receiver, (reason) => {
        err("failed to asynchronously prepare wasm: " + reason);
        if (isFileURI(wasmBinaryFile)) {
          err("warning: Loading from a file URI (" + wasmBinaryFile + ") is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing");
        }
        abort(reason);
      });
    }
    function instantiateAsync(binary, binaryFile, imports, callback) {
      if (!binary && typeof WebAssembly.instantiateStreaming == "function" && !isDataURI(binaryFile) && typeof fetch == "function") {
        return fetch(binaryFile, { credentials: "same-origin" }).then((response) => {
          var result = WebAssembly.instantiateStreaming(response, imports);
          return result.then(callback, function(reason) {
            err("wasm streaming compile failed: " + reason);
            err("falling back to ArrayBuffer instantiation");
            return instantiateArrayBuffer(binaryFile, imports, callback);
          });
        });
      }
      return instantiateArrayBuffer(binaryFile, imports, callback);
    }
    function createWasm() {
      var info = { "env": wasmImports, "wasi_snapshot_preview1": wasmImports };
      function receiveInstance(instance, module) {
        var exports = instance.exports;
        exports = Asyncify.instrumentWasmExports(exports);
        exports = applySignatureConversions(exports);
        Module["asm"] = exports;
        wasmMemory = Module["asm"]["memory"];
        assert(wasmMemory, "memory not found in wasm exports");
        updateMemoryViews();
        wasmTable = Module["asm"]["__indirect_function_table"];
        assert(wasmTable, "table not found in wasm exports");
        addOnInit(Module["asm"]["__wasm_call_ctors"]);
        removeRunDependency("wasm-instantiate");
        return exports;
      }
      addRunDependency("wasm-instantiate");
      var trueModule = Module;
      function receiveInstantiationResult(result) {
        assert(Module === trueModule, "the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?");
        trueModule = null;
        receiveInstance(result["instance"]);
      }
      if (Module["instantiateWasm"]) {
        try {
          return Module["instantiateWasm"](info, receiveInstance);
        } catch (e) {
          err("Module.instantiateWasm callback failed with error: " + e);
          readyPromiseReject(e);
        }
      }
      instantiateAsync(wasmBinary, wasmBinaryFile, info, receiveInstantiationResult).catch(readyPromiseReject);
      return {};
    }
    var tempDouble;
    var tempI64;
    function legacyModuleProp(prop, newName) {
      if (!Object.getOwnPropertyDescriptor(Module, prop)) {
        Object.defineProperty(Module, prop, { configurable: true, get() {
          abort("Module." + prop + " has been replaced with plain " + newName + " (the initial value can be provided on Module, but after startup the value is only looked for on a local variable of that name)");
        } });
      }
    }
    function ignoredModuleProp(prop) {
      if (Object.getOwnPropertyDescriptor(Module, prop)) {
        abort("`Module." + prop + "` was supplied but `" + prop + "` not included in INCOMING_MODULE_JS_API");
      }
    }
    function isExportedByForceFilesystem(name) {
      return name === "FS_createPath" || name === "FS_createDataFile" || name === "FS_createPreloadedFile" || name === "FS_unlink" || name === "addRunDependency" || name === "FS_createLazyFile" || name === "FS_createDevice" || name === "removeRunDependency";
    }
    function missingGlobal(sym, msg) {
      if (typeof globalThis !== "undefined") {
        Object.defineProperty(globalThis, sym, { configurable: true, get() {
          warnOnce("`" + sym + "` is not longer defined by emscripten. " + msg);
          return void 0;
        } });
      }
    }
    missingGlobal("buffer", "Please use HEAP8.buffer or wasmMemory.buffer");
    function missingLibrarySymbol(sym) {
      if (typeof globalThis !== "undefined" && !Object.getOwnPropertyDescriptor(globalThis, sym)) {
        Object.defineProperty(globalThis, sym, { configurable: true, get() {
          var msg = "`" + sym + "` is a library symbol and not included by default; add it to your library.js __deps or to DEFAULT_LIBRARY_FUNCS_TO_INCLUDE on the command line";
          var librarySymbol = sym;
          if (!librarySymbol.startsWith("_")) {
            librarySymbol = "$" + sym;
          }
          msg += " (e.g. -sDEFAULT_LIBRARY_FUNCS_TO_INCLUDE='" + librarySymbol + "')";
          if (isExportedByForceFilesystem(sym)) {
            msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
          }
          warnOnce(msg);
          return void 0;
        } });
      }
      unexportedRuntimeSymbol(sym);
    }
    function unexportedRuntimeSymbol(sym) {
      if (!Object.getOwnPropertyDescriptor(Module, sym)) {
        Object.defineProperty(Module, sym, { configurable: true, get() {
          var msg = "'" + sym + "' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the Emscripten FAQ)";
          if (isExportedByForceFilesystem(sym)) {
            msg += ". Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you";
          }
          abort(msg);
        } });
      }
    }
    var ASM_CONSTS = { 3572092: ($02, $1) => {
      const target = Module.targets.get($02);
      const property = UTF8ToString($1);
      if (!(property in target)) {
        return Module.jsToZval(void 0);
      }
      if (target[property] === null) {
        return Module.jsToZval(null);
      }
      const result = target[property];
      if (!result || !["function", "object"].includes(typeof result)) {
        return Module.jsToZval(result);
      }
      return 0;
    }, 3572440: ($02, $1, $2) => {
      const target = Module.targets.get($02);
      const property = UTF8ToString($1);
      const result = target[property];
      const zvalPtr = $2;
      if (result && ["function", "object"].includes(typeof result)) {
        let index = Module.targets.getId(result);
        if (!Module.targets.has(result)) {
          index = Module.targets.add(result);
          Module.zvalMap.set(result, zvalPtr);
          Module._zvalMap.set(zvalPtr, result);
        }
        return index;
      }
      return 0;
    }, 3572848: ($02) => "function" === typeof Module.targets.get($02) ? $02 : 0, 3572916: ($02) => !!(Module.targets.get($02).prototype && Module.targets.get($02).prototype.constructor), 3573017: ($02, $1, $2) => {
      (() => {
        Module.targets.get($02);
        UTF8ToString($1);
      })();
    }, 3573129: ($02, $1, $2, $3, $4) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        const funcPtr = $2;
        target[property] = Module.callableToJs(funcPtr);
      })();
    }, 3573332: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        const zvalPtr = $2;
        if (!Module.targets.has(target[property])) {
          target[property] = Module.marshalObject(zvalPtr);
        }
      })();
    }, 3573539: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        delete target[property];
      })();
    }, 3573655: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        target[property] = null;
      })();
    }, 3573771: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        target[property] = false;
      })();
    }, 3573888: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        target[property] = true;
      })();
    }, 3574004: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        target[property] = $2;
      })();
    }, 3574118: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        target[property] = $2;
      })();
    }, 3574232: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        const newValue = UTF8ToString($2);
        target[property] = newValue;
      })();
    }, 3574387: ($02, $1) => {
      let target = Module.targets.get($02);
      const property = $1;
      if (target instanceof ArrayBuffer) {
        if (!Module.bufferMaps.has(target)) {
          Module.bufferMaps.set(target, new Uint8Array(target));
        }
        target = Module.bufferMaps.get(target);
      }
      if (!(property in target)) {
        const jsRet3 = "UN";
        const len3 = lengthBytesUTF8(jsRet3) + 1;
        const strLoc3 = _malloc(len3);
        stringToUTF8(jsRet3, strLoc3, len3);
        return strLoc3;
      }
      if (target[property] === null) {
        const jsRet3 = "NU";
        const len3 = lengthBytesUTF8(jsRet3) + 1;
        const strLoc3 = _malloc(len3);
        stringToUTF8(jsRet3, strLoc3, len3);
        return strLoc3;
      }
      const result = target[property];
      if (!result || !["function", "object"].includes(typeof result)) {
        const jsRet3 = "OK" + String(result);
        const len3 = lengthBytesUTF8(jsRet3) + 1;
        const strLoc3 = _malloc(len3);
        stringToUTF8(jsRet3, strLoc3, len3);
        return strLoc3;
      }
      const jsRet2 = "XX";
      const len2 = lengthBytesUTF8(jsRet2) + 1;
      const strLoc2 = _malloc(len2);
      stringToUTF8(jsRet2, strLoc2, len2);
      return strLoc2;
    }, 3575353: ($02, $1, $2) => {
      const target = Module.targets.get($02);
      const property = UTF8ToString($1);
      const result = target[property];
      const zvalPtr = $2;
      if (result && ["function", "object"].includes(typeof result)) {
        let index = Module.targets.getId(result);
        if (!Module.targets.has(result)) {
          index = Module.targets.add(result);
          Module.zvalMap.set(result, zvalPtr);
          Module._zvalMap.set(zvalPtr, result);
        }
        return index;
      }
      return 0;
    }, 3575761: ($02) => "function" === typeof Module.targets.get($02) ? $02 : 0, 3575829: ($02) => !!(Module.targets.get($02).prototype && Module.targets.get($02).prototype.constructor), 3575930: ($02, $1, $2) => {
      (() => {
        Module.targets.get($02);
      })();
    }, 3576028: ($02, $1, $2, $3) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        const funcPtr = $2;
        target[property] = Module.callableToJs(funcPtr);
      })();
    }, 3576194: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        const zvalPtr = $2;
        if (!Module.targets.has(target[property])) {
          target[property] = Module.marshalObject(zvalPtr);
        }
      })();
    }, 3576387: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        delete target[property];
      })();
    }, 3576489: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        target[property] = null;
      })();
    }, 3576591: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        target[property] = false;
      })();
    }, 3576694: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        target[property] = true;
      })();
    }, 3576796: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        target[property] = $2;
      })();
    }, 3576896: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        target[property] = $2;
      })();
    }, 3576996: ($02, $1, $2) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        const newValue = UTF8ToString($2);
        target[property] = newValue;
      })();
    }, 3577137: ($02, $1, $2) => {
      const target = Module.targets.get($02);
      const property = $1;
      const check_empty = $2;
      if (Array.isArray(target)) {
        return typeof target[property] !== "undefined";
      }
      if (target instanceof ArrayBuffer) {
        if (!Module.bufferMaps.has(target)) {
          Module.bufferMaps.set(target, new Uint8Array(target));
        }
        const targetBytes = Module.bufferMaps.get(target);
        return targetBytes[property] !== "undefined";
      }
      if (!check_empty) {
        return property in target;
      } else {
        return !!target[property];
      }
    }, 3577616: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = UTF8ToString($1);
        delete target[property];
      })();
    }, 3577732: ($02, $1) => {
      (() => {
        const target = Module.targets.get($02);
        const property = $1;
        delete target[property];
      })();
    }, 3577834: ($02) => {
      const target = Module.targets.get($02);
      let json;
      if (typeof target === "function") {
        json = JSON.stringify({});
      } else {
        try {
          json = JSON.stringify({ ...target });
        } catch {
          json = JSON.stringify({});
        }
      }
      const jsRet2 = String(json);
      const len2 = lengthBytesUTF8(jsRet2) + 1;
      const strLoc2 = _malloc(len2);
      stringToUTF8(jsRet2, strLoc2, len2);
      return strLoc2;
    }, 3578186: ($02, $1) => {
      const target = Module.targets.get($02);
      const property = UTF8ToString($1);
      return property in target;
    }, 3578291: ($02) => {
      const target = Module.targets.get($02);
      const name = target.constructor && target.constructor.name || "Object";
      const len2 = lengthBytesUTF8(name) + 1;
      const namePtr = _malloc(name);
      stringToUTF8(name, namePtr, len2);
      return namePtr;
    }, 3578528: ($02, $1, $2, $3, $4) => {
      const target = Module.targets.get($02);
      const method_name = UTF8ToString($1);
      const argp = $2;
      const argc = $3;
      const size = $4;
      const args = [];
      for (let i2 = 0; i2 < argc; i2++) {
        const loc = argp + i2 * size;
        const ptr = Module.getValue(loc, "*");
        const arg = Module.zvalToJS(ptr);
        args.push(arg);
      }
      const jsRet2 = target[method_name](...args);
      const retZval = Module.jsToZval(jsRet2);
      return retZval;
    }, 3578929: ($02, $1, $2, $3) => {
      const target = Module.targets.get($02);
      const argv = $1;
      const argc = $2;
      const size = $3;
      const args = [];
      for (let i2 = 0; i2 < argc; i2++) {
        args.push(Module.zvalToJS(argv + i2 * size));
      }
      const jsRet2 = target(...args);
      return Module.jsToZval(jsRet2);
    }, 3579181: ($02, $1) => {
      const target = Module.targets.get($02);
      const property_name = UTF8ToString($1);
      const jsRet2 = target[property_name];
      return Module.jsToZval(jsRet2);
    }, 3579332: ($02, $1, $2, $3) => {
      const _class = Module._classes.get($02);
      const argv = $1;
      const argc = $2;
      const size = $3;
      const args = [];
      for (let i2 = 0; i2 < argc; i2++) {
        args.push(Module.zvalToJS(argv + i2 * size));
      }
      const _object = new _class(...args);
      const index = Module.targets.add(_object);
      return index;
    }, 3579617: ($0) => {
      const jsRet = String(eval(UTF8ToString($0)));
      const len = lengthBytesUTF8(jsRet) + 1;
      const strLoc = _malloc(len);
      stringToUTF8(jsRet, strLoc, len);
      return strLoc;
    }, 3579785: ($02, $1) => {
      const funcName = UTF8ToString($02);
      const argJson = UTF8ToString($1);
      const func = globalThis[funcName];
      const args = JSON.parse(argJson || "[]") || [];
      const jsRet2 = String(func(...args));
      const len2 = lengthBytesUTF8(jsRet2) + 1;
      const strLoc2 = _malloc(len2);
      stringToUTF8(jsRet2, strLoc2, len2);
      return strLoc2;
    }, 3580096: ($02, $1) => {
      const timeout = Number(UTF8ToString($02));
      const funcPtr = $1;
      setTimeout(() => {
        Module.ccall("vrzno_exec_callback", "number", ["number", "number", "number"], [funcPtr, null, 0]);
        Module.ccall("vrzno_del_callback", "number", ["number"], [funcPtr]);
      }, timeout);
    }, 3580368: ($02) => Module.jsToZval(Module[UTF8ToString($02)]), 3580422: ($02, $1, $2, $3) => {
      const _class = Module.targets.get($02);
      const argv = $1;
      const argc = $2;
      const size = $3;
      const args = [];
      for (let i2 = 0; i2 < argc; i2++) {
        args.push(Module.zvalToJS(argv + i2 * size));
      }
      const _object = new _class(...args);
      return Module.jsToZval(_object);
    }, 3580682: ($02) => {
      const name = UTF8ToString($02);
      return Module.jsToZval(import(name));
    }, 3580755: ($02) => {
      const target = Module.targets.get($02);
      return Module.classes.get(target);
    }, 3580833: ($02, $1) => {
      const target = Module.targets.get($02);
      Module.classes.set(target, $1);
      Module._classes.set($1, target);
    }, 3580941: ($02) => {
      const results = Module.targets.get($02);
      if (results) {
        return results.length;
      }
      return 0;
    }, 3581034: ($02) => {
      const results = Module.targets.get($02);
      if (results.length) {
        return Object.keys(results[0]).length;
      }
      return 0;
    }, 3581150: ($02, $1) => {
      const targetId = $02;
      const target = Module.targets.get(targetId);
      const current = $1;
      if (current >= target.length) {
        return null;
      }
      return Module.jsToZval(target[current]);
    }, 3581327: ($02, $1) => {
      const results = Module.targets.get($02);
      if (results.length) {
        const jsRet2 = Object.keys(results[0])[$1];
        const len2 = lengthBytesUTF8(jsRet2) + 1;
        const strLoc2 = _malloc(len2);
        stringToUTF8(jsRet2, strLoc2, len2);
        return strLoc2;
      }
      return 0;
    }, 3581565: ($02, $1, $2) => {
      const results = Module.targets.get($02);
      const current = -1 + $1;
      if (current >= results.length) {
        return null;
      }
      const result = results[current];
      const key = Object.keys(result)[$2];
      const zval = Module.jsToZval(result[key]);
      return zval;
    }, 3581825: ($02, $1) => {
      const statement = Module.targets.get($02);
      const paramVal = Module.zvalToJS($1);
      if (!Module.PdoParams.has(statement)) {
        Module.PdoParams.set(statement, []);
      }
      const paramList = Module.PdoParams.get(statement);
      paramList.push(paramVal);
    }, 3582064: ($02, $1, $2) => {
      console.log("GET ATTR", $02, $1, $2);
    }, 3582105: ($02, $1, $2) => {
      console.log("COL META", $02, $1, $2);
    }, 3582146: ($02, $1, $2) => {
      console.log("CLOSE", $02, $1, $2);
    }, 3582184: ($02) => {
      console.log("CLOSE", $02);
    }, 3582214: ($02, $1) => {
      const target = Module.targets.get($02);
      const query = UTF8ToString($1);
      if (Module.pdoDriver && Module.pdoDriver.prepare) {
        const prepared = Module.pdoDriver.prepare(target, query);
        const zval = Module.jsToZval(prepared);
        return zval;
      }
      return null;
    }, 3582466: ($02, $1) => {
      console.log("DO", $02, UTF8ToString($1));
      const target = Module.targets.get($02);
      const query = UTF8ToString($1);
      if (Module.pdoDriver && Module.pdoDriver.doer) {
        return Module.pdoDriver.doer(target, query);
      }
      return 1;
    }, 3582687: ($02) => {
      console.log("BEGIN TXN", $02);
      return true;
    }, 3582734: ($02) => {
      console.log("COMMIT TXN", $02);
      return true;
    }, 3582782: ($02) => {
      console.log("ROLLBACK TXN", $02);
      return true;
    }, 3582832: ($02, $1, $2) => {
      console.log("SET ATTR", $02, $1, $2);
      return true;
    }, 3582886: ($02, $1) => {
      console.log("LAST INSERT ID", $02, UTF8ToString($1));
      return 0;
    }, 3582953: ($02, $1, $2) => {
      console.log("FETCH ERROR FUNC", $02, $1, $2);
    }, 3583002: ($02, $1, $2) => {
      console.log("GET ATTR", $02, $1, $2);
      return 0;
    }, 3583053: ($02) => {
      console.log("SHUTDOWN", $02);
    }, 3583086: ($02, $1) => {
      console.log("GET GC", $02, $1);
    }, 3583121: () => Module.targets.getId(globalThis), 3583166: ($02, $1) => {
      let target = Module.targets.get($02);
      const property = $1;
      if (target instanceof ArrayBuffer) {
        if (!Module.bufferMaps.has(target)) {
          Module.bufferMaps.set(target, new Uint8Array(target));
        }
        target = Module.bufferMaps.get(target);
      }
      if (Array.isArray(target) || ArrayBuffer.isView(target)) {
        if (property >= 0 && property < target.length) {
          return 1;
        }
      }
      return 0;
    }, 3583529: ($02, $1) => {
      let target = Module.targets.get($02);
      const property = $1;
      if (target instanceof ArrayBuffer) {
        if (!Module.bufferMaps.has(target)) {
          Module.bufferMaps.set(target, new Uint8Array(target));
        }
        target = Module.bufferMaps.get(target);
      }
      return Module.jsToZval(target[property]);
    }, 3583805: ($02) => {
      if (Module.persist) {
        const localPath = Module.persist.localPath || "./persist";
        const mountPath = Module.persist.mountPath || "/persist";
        const wasmEnv = UTF8ToString($02);
        FS.mkdir(mountPath);
        switch (wasmEnv) {
          case "web":
            FS.mount(IDBFS, {}, mountPath);
            break;
          case "node":
            const fs = require("fs");
            if (!fs.existsSync(localPath)) {
              fs.mkdirSync(localPath, { recursive: true });
            }
            FS.mount(NODEFS, { root: localPath }, mountPath);
            break;
        }
      }
    } };
    function __asyncjs__vrzno_await_internal(targetId) {
      return Asyncify.handleAsync(async () => {
        const target = Module.targets.get(targetId);
        const result = await target;
        return Module.jsToZval(result);
      });
    }
    function __asyncjs__pdo_vrzno_real_stmt_execute(targetId) {
      return Asyncify.handleAsync(async () => {
        let statement = Module.targets.get(targetId);
        if (!Module.PdoParams.has(statement)) {
          Module.PdoParams.set(statement, []);
        }
        const paramList = Module.PdoParams.get(statement);
        const bound = paramList.length ? statement.bind(...paramList) : statement;
        const result = await bound.run();
        Module.PdoParams.delete(statement);
        if (!result.success) {
          return false;
        }
        return Module.jsToZval(result.results);
      });
    }
    function ExitStatus(status) {
      this.name = "ExitStatus";
      this.message = `Program terminated with exit(${status})`;
      this.status = status;
    }
    var callRuntimeCallbacks = (callbacks) => {
      while (callbacks.length > 0) {
        callbacks.shift()(Module);
      }
    };
    function getValue(ptr, type = "i8") {
      if (type.endsWith("*")) type = "*";
      switch (type) {
        case "i1":
          return HEAP8[ptr >>> 0];
        case "i8":
          return HEAP8[ptr >>> 0];
        case "i16":
          return HEAP16[ptr >>> 1];
        case "i32":
          return HEAP32[ptr >>> 2];
        case "i64":
          abort("to do getValue(i64) use WASM_BIGINT");
        case "float":
          return HEAPF32[ptr >>> 2];
        case "double":
          return HEAPF64[ptr >>> 3];
        case "*":
          return HEAPU32[ptr >>> 2];
        default:
          abort(`invalid type for getValue: ${type}`);
      }
    }
    var ptrToString = (ptr) => {
      assert(typeof ptr === "number");
      return "0x" + ptr.toString(16).padStart(8, "0");
    };
    var warnOnce = (text) => {
      if (!warnOnce.shown) warnOnce.shown = {};
      if (!warnOnce.shown[text]) {
        warnOnce.shown[text] = 1;
        err(text);
      }
    };
    function convertI32PairToI53Checked(lo, hi) {
      assert(lo == lo >>> 0 || lo == (lo | 0));
      assert(hi === (hi | 0));
      return hi + 2097152 >>> 0 < 4194305 - !!lo ? (lo >>> 0) + hi * 4294967296 : NaN;
    }
    var UTF8Decoder = typeof TextDecoder != "undefined" ? new TextDecoder("utf8") : void 0;
    var UTF8ArrayToString = (heapOrArray, idx, maxBytesToRead) => {
      idx >>>= 0;
      var endIdx = idx + maxBytesToRead;
      var endPtr = idx;
      while (heapOrArray[endPtr] && !(endPtr >= endIdx)) ++endPtr;
      if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) {
        return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr));
      }
      var str = "";
      while (idx < endPtr) {
        var u0 = heapOrArray[idx++];
        if (!(u0 & 128)) {
          str += String.fromCharCode(u0);
          continue;
        }
        var u1 = heapOrArray[idx++] & 63;
        if ((u0 & 224) == 192) {
          str += String.fromCharCode((u0 & 31) << 6 | u1);
          continue;
        }
        var u2 = heapOrArray[idx++] & 63;
        if ((u0 & 240) == 224) {
          u0 = (u0 & 15) << 12 | u1 << 6 | u2;
        } else {
          if ((u0 & 248) != 240) warnOnce("Invalid UTF-8 leading byte " + ptrToString(u0) + " encountered when deserializing a UTF-8 string in wasm memory to a JS string!");
          u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | heapOrArray[idx++] & 63;
        }
        if (u0 < 65536) {
          str += String.fromCharCode(u0);
        } else {
          var ch = u0 - 65536;
          str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
        }
      }
      return str;
    };
    var UTF8ToString = (ptr, maxBytesToRead) => {
      assert(typeof ptr == "number");
      ptr >>>= 0;
      return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead) : "";
    };
    function ___assert_fail(condition, filename, line, func) {
      condition >>>= 0;
      filename >>>= 0;
      func >>>= 0;
      abort(`Assertion failed: ${UTF8ToString(condition)}, at: ` + [filename ? UTF8ToString(filename) : "unknown filename", line, func ? UTF8ToString(func) : "unknown function"]);
    }
    var ___call_sighandler = function(fp, sig) {
      fp >>>= 0;
      return ((a1) => dynCall_vi.apply(null, [fp, a1]))(sig);
    };
    var PATH = { isAbs: (path) => path.charAt(0) === "/", splitPath: (filename) => {
      var splitPathRe = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
      return splitPathRe.exec(filename).slice(1);
    }, normalizeArray: (parts, allowAboveRoot) => {
      var up = 0;
      for (var i2 = parts.length - 1; i2 >= 0; i2--) {
        var last = parts[i2];
        if (last === ".") {
          parts.splice(i2, 1);
        } else if (last === "..") {
          parts.splice(i2, 1);
          up++;
        } else if (up) {
          parts.splice(i2, 1);
          up--;
        }
      }
      if (allowAboveRoot) {
        for (; up; up--) {
          parts.unshift("..");
        }
      }
      return parts;
    }, normalize: (path) => {
      var isAbsolute = PATH.isAbs(path), trailingSlash = path.substr(-1) === "/";
      path = PATH.normalizeArray(path.split("/").filter((p) => !!p), !isAbsolute).join("/");
      if (!path && !isAbsolute) {
        path = ".";
      }
      if (path && trailingSlash) {
        path += "/";
      }
      return (isAbsolute ? "/" : "") + path;
    }, dirname: (path) => {
      var result = PATH.splitPath(path), root = result[0], dir = result[1];
      if (!root && !dir) {
        return ".";
      }
      if (dir) {
        dir = dir.substr(0, dir.length - 1);
      }
      return root + dir;
    }, basename: (path) => {
      if (path === "/") return "/";
      path = PATH.normalize(path);
      path = path.replace(/\/$/, "");
      var lastSlash = path.lastIndexOf("/");
      if (lastSlash === -1) return path;
      return path.substr(lastSlash + 1);
    }, join: function() {
      var paths = Array.prototype.slice.call(arguments);
      return PATH.normalize(paths.join("/"));
    }, join2: (l, r) => PATH.normalize(l + "/" + r) };
    var initRandomFill = () => {
      if (typeof crypto == "object" && typeof crypto["getRandomValues"] == "function") {
        return (view) => crypto.getRandomValues(view);
      } else abort("no cryptographic support found for randomDevice. consider polyfilling it if you want to use something insecure like Math.random(), e.g. put this in a --pre-js: var crypto = { getRandomValues: (array) => { for (var i = 0; i < array.length; i++) array[i] = (Math.random()*256)|0 } };");
    };
    var randomFill = (view) => (randomFill = initRandomFill())(view);
    var PATH_FS = { resolve: function() {
      var resolvedPath = "", resolvedAbsolute = false;
      for (var i2 = arguments.length - 1; i2 >= -1 && !resolvedAbsolute; i2--) {
        var path = i2 >= 0 ? arguments[i2] : FS.cwd();
        if (typeof path != "string") {
          throw new TypeError("Arguments to path.resolve must be strings");
        } else if (!path) {
          return "";
        }
        resolvedPath = path + "/" + resolvedPath;
        resolvedAbsolute = PATH.isAbs(path);
      }
      resolvedPath = PATH.normalizeArray(resolvedPath.split("/").filter((p) => !!p), !resolvedAbsolute).join("/");
      return (resolvedAbsolute ? "/" : "") + resolvedPath || ".";
    }, relative: (from, to) => {
      from = PATH_FS.resolve(from).substr(1);
      to = PATH_FS.resolve(to).substr(1);
      function trim(arr) {
        var start = 0;
        for (; start < arr.length; start++) {
          if (arr[start] !== "") break;
        }
        var end = arr.length - 1;
        for (; end >= 0; end--) {
          if (arr[end] !== "") break;
        }
        if (start > end) return [];
        return arr.slice(start, end - start + 1);
      }
      var fromParts = trim(from.split("/"));
      var toParts = trim(to.split("/"));
      var length = Math.min(fromParts.length, toParts.length);
      var samePartsLength = length;
      for (var i2 = 0; i2 < length; i2++) {
        if (fromParts[i2] !== toParts[i2]) {
          samePartsLength = i2;
          break;
        }
      }
      var outputParts = [];
      for (var i2 = samePartsLength; i2 < fromParts.length; i2++) {
        outputParts.push("..");
      }
      outputParts = outputParts.concat(toParts.slice(samePartsLength));
      return outputParts.join("/");
    } };
    var FS_stdin_getChar_buffer = [];
    var lengthBytesUTF8 = (str) => {
      var len2 = 0;
      for (var i2 = 0; i2 < str.length; ++i2) {
        var c = str.charCodeAt(i2);
        if (c <= 127) {
          len2++;
        } else if (c <= 2047) {
          len2 += 2;
        } else if (c >= 55296 && c <= 57343) {
          len2 += 4;
          ++i2;
        } else {
          len2 += 3;
        }
      }
      return len2;
    };
    var stringToUTF8Array = (str, heap, outIdx, maxBytesToWrite) => {
      outIdx >>>= 0;
      assert(typeof str === "string");
      if (!(maxBytesToWrite > 0)) return 0;
      var startIdx = outIdx;
      var endIdx = outIdx + maxBytesToWrite - 1;
      for (var i2 = 0; i2 < str.length; ++i2) {
        var u = str.charCodeAt(i2);
        if (u >= 55296 && u <= 57343) {
          var u1 = str.charCodeAt(++i2);
          u = 65536 + ((u & 1023) << 10) | u1 & 1023;
        }
        if (u <= 127) {
          if (outIdx >= endIdx) break;
          heap[outIdx++ >>> 0] = u;
        } else if (u <= 2047) {
          if (outIdx + 1 >= endIdx) break;
          heap[outIdx++ >>> 0] = 192 | u >> 6;
          heap[outIdx++ >>> 0] = 128 | u & 63;
        } else if (u <= 65535) {
          if (outIdx + 2 >= endIdx) break;
          heap[outIdx++ >>> 0] = 224 | u >> 12;
          heap[outIdx++ >>> 0] = 128 | u >> 6 & 63;
          heap[outIdx++ >>> 0] = 128 | u & 63;
        } else {
          if (outIdx + 3 >= endIdx) break;
          if (u > 1114111) warnOnce("Invalid Unicode code point " + ptrToString(u) + " encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).");
          heap[outIdx++ >>> 0] = 240 | u >> 18;
          heap[outIdx++ >>> 0] = 128 | u >> 12 & 63;
          heap[outIdx++ >>> 0] = 128 | u >> 6 & 63;
          heap[outIdx++ >>> 0] = 128 | u & 63;
        }
      }
      heap[outIdx >>> 0] = 0;
      return outIdx - startIdx;
    };
    function intArrayFromString(stringy, dontAddNull, length) {
      var len2 = lengthBytesUTF8(stringy) + 1;
      var u8array = new Array(len2);
      var numBytesWritten = stringToUTF8Array(stringy, u8array, 0, u8array.length);
      if (dontAddNull) u8array.length = numBytesWritten;
      return u8array;
    }
    var FS_stdin_getChar = () => {
      if (!FS_stdin_getChar_buffer.length) {
        var result = null;
        if (typeof window != "undefined" && typeof window.prompt == "function") {
          result = window.prompt("Input: ");
          if (result !== null) {
            result += "\n";
          }
        } else if (typeof readline == "function") {
          result = readline();
          if (result !== null) {
            result += "\n";
          }
        }
        if (!result) {
          return null;
        }
        FS_stdin_getChar_buffer = intArrayFromString(result, true);
      }
      return FS_stdin_getChar_buffer.shift();
    };
    var TTY = { ttys: [], init: function() {
    }, shutdown: function() {
    }, register: function(dev, ops) {
      TTY.ttys[dev] = { input: [], output: [], ops };
      FS.registerDevice(dev, TTY.stream_ops);
    }, stream_ops: { open: function(stream) {
      var tty = TTY.ttys[stream.node.rdev];
      if (!tty) {
        throw new FS.ErrnoError(43);
      }
      stream.tty = tty;
      stream.seekable = false;
    }, close: function(stream) {
      stream.tty.ops.fsync(stream.tty);
    }, fsync: function(stream) {
      stream.tty.ops.fsync(stream.tty);
    }, read: function(stream, buffer, offset, length, pos) {
      if (!stream.tty || !stream.tty.ops.get_char) {
        throw new FS.ErrnoError(60);
      }
      var bytesRead = 0;
      for (var i2 = 0; i2 < length; i2++) {
        var result;
        try {
          result = stream.tty.ops.get_char(stream.tty);
        } catch (e) {
          throw new FS.ErrnoError(29);
        }
        if (result === void 0 && bytesRead === 0) {
          throw new FS.ErrnoError(6);
        }
        if (result === null || result === void 0) break;
        bytesRead++;
        buffer[offset + i2] = result;
      }
      if (bytesRead) {
        stream.node.timestamp = Date.now();
      }
      return bytesRead;
    }, write: function(stream, buffer, offset, length, pos) {
      if (!stream.tty || !stream.tty.ops.put_char) {
        throw new FS.ErrnoError(60);
      }
      try {
        for (var i2 = 0; i2 < length; i2++) {
          stream.tty.ops.put_char(stream.tty, buffer[offset + i2]);
        }
      } catch (e) {
        throw new FS.ErrnoError(29);
      }
      if (length) {
        stream.node.timestamp = Date.now();
      }
      return i2;
    } }, default_tty_ops: { get_char: function(tty) {
      return FS_stdin_getChar();
    }, put_char: function(tty, val) {
      if (val === null || val === 10) {
        out(UTF8ArrayToString(tty.output, 0));
        tty.output = [];
      } else {
        if (val != 0) tty.output.push(val);
      }
    }, fsync: function(tty) {
      if (tty.output && tty.output.length > 0) {
        out(UTF8ArrayToString(tty.output, 0));
        tty.output = [];
      }
    }, ioctl_tcgets: function(tty) {
      return { c_iflag: 25856, c_oflag: 5, c_cflag: 191, c_lflag: 35387, c_cc: [3, 28, 127, 21, 4, 0, 1, 0, 17, 19, 26, 0, 18, 15, 23, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] };
    }, ioctl_tcsets: function(tty, optional_actions, data) {
      return 0;
    }, ioctl_tiocgwinsz: function(tty) {
      return [24, 80];
    } }, default_tty1_ops: { put_char: function(tty, val) {
      if (val === null || val === 10) {
        err(UTF8ArrayToString(tty.output, 0));
        tty.output = [];
      } else {
        if (val != 0) tty.output.push(val);
      }
    }, fsync: function(tty) {
      if (tty.output && tty.output.length > 0) {
        err(UTF8ArrayToString(tty.output, 0));
        tty.output = [];
      }
    } } };
    var zeroMemory = (address, size) => {
      HEAPU8.fill(0, address, address + size);
      return address;
    };
    var alignMemory = (size, alignment) => {
      assert(alignment, "alignment argument is required");
      return Math.ceil(size / alignment) * alignment;
    };
    var mmapAlloc = (size) => {
      size = alignMemory(size, 65536);
      var ptr = _emscripten_builtin_memalign(65536, size);
      if (!ptr) return 0;
      return zeroMemory(ptr, size);
    };
    var MEMFS = { ops_table: null, mount(mount) {
      return MEMFS.createNode(null, "/", 16384 | 511, 0);
    }, createNode(parent, name, mode, dev) {
      if (FS.isBlkdev(mode) || FS.isFIFO(mode)) {
        throw new FS.ErrnoError(63);
      }
      if (!MEMFS.ops_table) {
        MEMFS.ops_table = { dir: { node: { getattr: MEMFS.node_ops.getattr, setattr: MEMFS.node_ops.setattr, lookup: MEMFS.node_ops.lookup, mknod: MEMFS.node_ops.mknod, rename: MEMFS.node_ops.rename, unlink: MEMFS.node_ops.unlink, rmdir: MEMFS.node_ops.rmdir, readdir: MEMFS.node_ops.readdir, symlink: MEMFS.node_ops.symlink }, stream: { llseek: MEMFS.stream_ops.llseek } }, file: { node: { getattr: MEMFS.node_ops.getattr, setattr: MEMFS.node_ops.setattr }, stream: { llseek: MEMFS.stream_ops.llseek, read: MEMFS.stream_ops.read, write: MEMFS.stream_ops.write, allocate: MEMFS.stream_ops.allocate, mmap: MEMFS.stream_ops.mmap, msync: MEMFS.stream_ops.msync } }, link: { node: { getattr: MEMFS.node_ops.getattr, setattr: MEMFS.node_ops.setattr, readlink: MEMFS.node_ops.readlink }, stream: {} }, chrdev: { node: { getattr: MEMFS.node_ops.getattr, setattr: MEMFS.node_ops.setattr }, stream: FS.chrdev_stream_ops } };
      }
      var node = FS.createNode(parent, name, mode, dev);
      if (FS.isDir(node.mode)) {
        node.node_ops = MEMFS.ops_table.dir.node;
        node.stream_ops = MEMFS.ops_table.dir.stream;
        node.contents = {};
      } else if (FS.isFile(node.mode)) {
        node.node_ops = MEMFS.ops_table.file.node;
        node.stream_ops = MEMFS.ops_table.file.stream;
        node.usedBytes = 0;
        node.contents = null;
      } else if (FS.isLink(node.mode)) {
        node.node_ops = MEMFS.ops_table.link.node;
        node.stream_ops = MEMFS.ops_table.link.stream;
      } else if (FS.isChrdev(node.mode)) {
        node.node_ops = MEMFS.ops_table.chrdev.node;
        node.stream_ops = MEMFS.ops_table.chrdev.stream;
      }
      node.timestamp = Date.now();
      if (parent) {
        parent.contents[name] = node;
        parent.timestamp = node.timestamp;
      }
      return node;
    }, getFileDataAsTypedArray(node) {
      if (!node.contents) return new Uint8Array(0);
      if (node.contents.subarray) return node.contents.subarray(0, node.usedBytes);
      return new Uint8Array(node.contents);
    }, expandFileStorage(node, newCapacity) {
      var prevCapacity = node.contents ? node.contents.length : 0;
      if (prevCapacity >= newCapacity) return;
      var CAPACITY_DOUBLING_MAX = 1024 * 1024;
      newCapacity = Math.max(newCapacity, prevCapacity * (prevCapacity < CAPACITY_DOUBLING_MAX ? 2 : 1.125) >>> 0);
      if (prevCapacity != 0) newCapacity = Math.max(newCapacity, 256);
      var oldContents = node.contents;
      node.contents = new Uint8Array(newCapacity);
      if (node.usedBytes > 0) node.contents.set(oldContents.subarray(0, node.usedBytes), 0);
    }, resizeFileStorage(node, newSize) {
      if (node.usedBytes == newSize) return;
      if (newSize == 0) {
        node.contents = null;
        node.usedBytes = 0;
      } else {
        var oldContents = node.contents;
        node.contents = new Uint8Array(newSize);
        if (oldContents) {
          node.contents.set(oldContents.subarray(0, Math.min(newSize, node.usedBytes)));
        }
        node.usedBytes = newSize;
      }
    }, node_ops: { getattr(node) {
      var attr = {};
      attr.dev = FS.isChrdev(node.mode) ? node.id : 1;
      attr.ino = node.id;
      attr.mode = node.mode;
      attr.nlink = 1;
      attr.uid = 0;
      attr.gid = 0;
      attr.rdev = node.rdev;
      if (FS.isDir(node.mode)) {
        attr.size = 4096;
      } else if (FS.isFile(node.mode)) {
        attr.size = node.usedBytes;
      } else if (FS.isLink(node.mode)) {
        attr.size = node.link.length;
      } else {
        attr.size = 0;
      }
      attr.atime = new Date(node.timestamp);
      attr.mtime = new Date(node.timestamp);
      attr.ctime = new Date(node.timestamp);
      attr.blksize = 4096;
      attr.blocks = Math.ceil(attr.size / attr.blksize);
      return attr;
    }, setattr(node, attr) {
      if (attr.mode !== void 0) {
        node.mode = attr.mode;
      }
      if (attr.timestamp !== void 0) {
        node.timestamp = attr.timestamp;
      }
      if (attr.size !== void 0) {
        MEMFS.resizeFileStorage(node, attr.size);
      }
    }, lookup(parent, name) {
      throw FS.genericErrors[44];
    }, mknod(parent, name, mode, dev) {
      return MEMFS.createNode(parent, name, mode, dev);
    }, rename(old_node, new_dir, new_name) {
      if (FS.isDir(old_node.mode)) {
        var new_node;
        try {
          new_node = FS.lookupNode(new_dir, new_name);
        } catch (e) {
        }
        if (new_node) {
          for (var i2 in new_node.contents) {
            throw new FS.ErrnoError(55);
          }
        }
      }
      delete old_node.parent.contents[old_node.name];
      old_node.parent.timestamp = Date.now();
      old_node.name = new_name;
      new_dir.contents[new_name] = old_node;
      new_dir.timestamp = old_node.parent.timestamp;
      old_node.parent = new_dir;
    }, unlink(parent, name) {
      delete parent.contents[name];
      parent.timestamp = Date.now();
    }, rmdir(parent, name) {
      var node = FS.lookupNode(parent, name);
      for (var i2 in node.contents) {
        throw new FS.ErrnoError(55);
      }
      delete parent.contents[name];
      parent.timestamp = Date.now();
    }, readdir(node) {
      var entries = [".", ".."];
      for (var key in node.contents) {
        if (!node.contents.hasOwnProperty(key)) {
          continue;
        }
        entries.push(key);
      }
      return entries;
    }, symlink(parent, newname, oldpath) {
      var node = MEMFS.createNode(parent, newname, 511 | 40960, 0);
      node.link = oldpath;
      return node;
    }, readlink(node) {
      if (!FS.isLink(node.mode)) {
        throw new FS.ErrnoError(28);
      }
      return node.link;
    } }, stream_ops: { read(stream, buffer, offset, length, position) {
      var contents = stream.node.contents;
      if (position >= stream.node.usedBytes) return 0;
      var size = Math.min(stream.node.usedBytes - position, length);
      assert(size >= 0);
      if (size > 8 && contents.subarray) {
        buffer.set(contents.subarray(position, position + size), offset);
      } else {
        for (var i2 = 0; i2 < size; i2++) buffer[offset + i2] = contents[position + i2];
      }
      return size;
    }, write(stream, buffer, offset, length, position, canOwn) {
      assert(!(buffer instanceof ArrayBuffer));
      if (buffer.buffer === HEAP8.buffer) {
        canOwn = false;
      }
      if (!length) return 0;
      var node = stream.node;
      node.timestamp = Date.now();
      if (buffer.subarray && (!node.contents || node.contents.subarray)) {
        if (canOwn) {
          assert(position === 0, "canOwn must imply no weird position inside the file");
          node.contents = buffer.subarray(offset, offset + length);
          node.usedBytes = length;
          return length;
        } else if (node.usedBytes === 0 && position === 0) {
          node.contents = buffer.slice(offset, offset + length);
          node.usedBytes = length;
          return length;
        } else if (position + length <= node.usedBytes) {
          node.contents.set(buffer.subarray(offset, offset + length), position);
          return length;
        }
      }
      MEMFS.expandFileStorage(node, position + length);
      if (node.contents.subarray && buffer.subarray) {
        node.contents.set(buffer.subarray(offset, offset + length), position);
      } else {
        for (var i2 = 0; i2 < length; i2++) {
          node.contents[position + i2] = buffer[offset + i2];
        }
      }
      node.usedBytes = Math.max(node.usedBytes, position + length);
      return length;
    }, llseek(stream, offset, whence) {
      var position = offset;
      if (whence === 1) {
        position += stream.position;
      } else if (whence === 2) {
        if (FS.isFile(stream.node.mode)) {
          position += stream.node.usedBytes;
        }
      }
      if (position < 0) {
        throw new FS.ErrnoError(28);
      }
      return position;
    }, allocate(stream, offset, length) {
      MEMFS.expandFileStorage(stream.node, offset + length);
      stream.node.usedBytes = Math.max(stream.node.usedBytes, offset + length);
    }, mmap(stream, length, position, prot, flags) {
      if (!FS.isFile(stream.node.mode)) {
        throw new FS.ErrnoError(43);
      }
      var ptr;
      var allocated;
      var contents = stream.node.contents;
      if (!(flags & 2) && contents.buffer === HEAP8.buffer) {
        allocated = false;
        ptr = contents.byteOffset;
      } else {
        if (position > 0 || position + length < contents.length) {
          if (contents.subarray) {
            contents = contents.subarray(position, position + length);
          } else {
            contents = Array.prototype.slice.call(contents, position, position + length);
          }
        }
        allocated = true;
        ptr = mmapAlloc(length);
        if (!ptr) {
          throw new FS.ErrnoError(48);
        }
        HEAP8.set(contents, ptr >>> 0);
      }
      return { ptr, allocated };
    }, msync(stream, buffer, offset, length, mmapFlags) {
      MEMFS.stream_ops.write(stream, buffer, 0, length, offset, false);
      return 0;
    } } };
    var asyncLoad = (url, onload, onerror, noRunDep) => {
      var dep = getUniqueRunDependency(`al ${url}`);
      readAsync(url, (arrayBuffer) => {
        assert(arrayBuffer, `Loading data file "${url}" failed (no arrayBuffer).`);
        onload(new Uint8Array(arrayBuffer));
        if (dep) removeRunDependency(dep);
      }, (event) => {
        if (onerror) {
          onerror();
        } else {
          throw `Loading data file "${url}" failed.`;
        }
      });
      if (dep) addRunDependency(dep);
    };
    var preloadPlugins = Module["preloadPlugins"] || [];
    function FS_handledByPreloadPlugin(byteArray, fullname, finish, onerror) {
      if (typeof Browser != "undefined") Browser.init();
      var handled = false;
      preloadPlugins.forEach(function(plugin) {
        if (handled) return;
        if (plugin["canHandle"](fullname)) {
          plugin["handle"](byteArray, fullname, finish, onerror);
          handled = true;
        }
      });
      return handled;
    }
    function FS_createPreloadedFile(parent, name, url, canRead, canWrite, onload, onerror, dontCreateFile, canOwn, preFinish) {
      var fullname = name ? PATH_FS.resolve(PATH.join2(parent, name)) : parent;
      var dep = getUniqueRunDependency(`cp ${fullname}`);
      function processData(byteArray) {
        function finish(byteArray2) {
          if (preFinish) preFinish();
          if (!dontCreateFile) {
            FS.createDataFile(parent, name, byteArray2, canRead, canWrite, canOwn);
          }
          if (onload) onload();
          removeRunDependency(dep);
        }
        if (FS_handledByPreloadPlugin(byteArray, fullname, finish, () => {
          if (onerror) onerror();
          removeRunDependency(dep);
        })) {
          return;
        }
        finish(byteArray);
      }
      addRunDependency(dep);
      if (typeof url == "string") {
        asyncLoad(url, (byteArray) => processData(byteArray), onerror);
      } else {
        processData(url);
      }
    }
    function FS_modeStringToFlags(str) {
      var flagModes = { "r": 0, "r+": 2, "w": 512 | 64 | 1, "w+": 512 | 64 | 2, "a": 1024 | 64 | 1, "a+": 1024 | 64 | 2 };
      var flags = flagModes[str];
      if (typeof flags == "undefined") {
        throw new Error(`Unknown file open mode: ${str}`);
      }
      return flags;
    }
    function FS_getMode(canRead, canWrite) {
      var mode = 0;
      if (canRead) mode |= 292 | 73;
      if (canWrite) mode |= 146;
      return mode;
    }
    var IDBFS = { dbs: {}, indexedDB: () => {
      if (typeof indexedDB != "undefined") return indexedDB;
      var ret = null;
      if (typeof window == "object") ret = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;
      assert(ret, "IDBFS used, but indexedDB not supported");
      return ret;
    }, DB_VERSION: 21, DB_STORE_NAME: "FILE_DATA", mount: function(mount) {
      return MEMFS.mount.apply(null, arguments);
    }, syncfs: (mount, populate, callback) => {
      IDBFS.getLocalSet(mount, (err2, local) => {
        if (err2) return callback(err2);
        IDBFS.getRemoteSet(mount, (err3, remote) => {
          if (err3) return callback(err3);
          var src = populate ? remote : local;
          var dst = populate ? local : remote;
          IDBFS.reconcile(src, dst, callback);
        });
      });
    }, quit: () => {
      Object.values(IDBFS.dbs).forEach((value) => value.close());
      IDBFS.dbs = {};
    }, getDB: (name, callback) => {
      var db = IDBFS.dbs[name];
      if (db) {
        return callback(null, db);
      }
      var req;
      try {
        req = IDBFS.indexedDB().open(name, IDBFS.DB_VERSION);
      } catch (e) {
        return callback(e);
      }
      if (!req) {
        return callback("Unable to connect to IndexedDB");
      }
      req.onupgradeneeded = (e) => {
        var db2 = e.target.result;
        var transaction = e.target.transaction;
        var fileStore;
        if (db2.objectStoreNames.contains(IDBFS.DB_STORE_NAME)) {
          fileStore = transaction.objectStore(IDBFS.DB_STORE_NAME);
        } else {
          fileStore = db2.createObjectStore(IDBFS.DB_STORE_NAME);
        }
        if (!fileStore.indexNames.contains("timestamp")) {
          fileStore.createIndex("timestamp", "timestamp", { unique: false });
        }
      };
      req.onsuccess = () => {
        db = req.result;
        IDBFS.dbs[name] = db;
        callback(null, db);
      };
      req.onerror = (e) => {
        callback(e.target.error);
        e.preventDefault();
      };
    }, getLocalSet: (mount, callback) => {
      var entries = {};
      function isRealDir(p) {
        return p !== "." && p !== "..";
      }
      function toAbsolute(root) {
        return (p) => PATH.join2(root, p);
      }
      var check = FS.readdir(mount.mountpoint).filter(isRealDir).map(toAbsolute(mount.mountpoint));
      while (check.length) {
        var path = check.pop();
        var stat;
        try {
          stat = FS.stat(path);
        } catch (e) {
          return callback(e);
        }
        if (FS.isDir(stat.mode)) {
          check.push.apply(check, FS.readdir(path).filter(isRealDir).map(toAbsolute(path)));
        }
        entries[path] = { "timestamp": stat.mtime };
      }
      return callback(null, { type: "local", entries });
    }, getRemoteSet: (mount, callback) => {
      var entries = {};
      IDBFS.getDB(mount.mountpoint, (err2, db) => {
        if (err2) return callback(err2);
        try {
          var transaction = db.transaction([IDBFS.DB_STORE_NAME], "readonly");
          transaction.onerror = (e) => {
            callback(e.target.error);
            e.preventDefault();
          };
          var store = transaction.objectStore(IDBFS.DB_STORE_NAME);
          var index = store.index("timestamp");
          index.openKeyCursor().onsuccess = (event) => {
            var cursor = event.target.result;
            if (!cursor) {
              return callback(null, { type: "remote", db, entries });
            }
            entries[cursor.primaryKey] = { "timestamp": cursor.key };
            cursor.continue();
          };
        } catch (e) {
          return callback(e);
        }
      });
    }, loadLocalEntry: (path, callback) => {
      var stat, node;
      try {
        var lookup = FS.lookupPath(path);
        node = lookup.node;
        stat = FS.stat(path);
      } catch (e) {
        return callback(e);
      }
      if (FS.isDir(stat.mode)) {
        return callback(null, { "timestamp": stat.mtime, "mode": stat.mode });
      } else if (FS.isFile(stat.mode)) {
        node.contents = MEMFS.getFileDataAsTypedArray(node);
        return callback(null, { "timestamp": stat.mtime, "mode": stat.mode, "contents": node.contents });
      } else {
        return callback(new Error("node type not supported"));
      }
    }, storeLocalEntry: (path, entry, callback) => {
      try {
        if (FS.isDir(entry["mode"])) {
          FS.mkdirTree(path, entry["mode"]);
        } else if (FS.isFile(entry["mode"])) {
          FS.writeFile(path, entry["contents"], { canOwn: true });
        } else {
          return callback(new Error("node type not supported"));
        }
        FS.chmod(path, entry["mode"]);
        FS.utime(path, entry["timestamp"], entry["timestamp"]);
      } catch (e) {
        return callback(e);
      }
      callback(null);
    }, removeLocalEntry: (path, callback) => {
      try {
        var stat = FS.stat(path);
        if (FS.isDir(stat.mode)) {
          FS.rmdir(path);
        } else if (FS.isFile(stat.mode)) {
          FS.unlink(path);
        }
      } catch (e) {
        return callback(e);
      }
      callback(null);
    }, loadRemoteEntry: (store, path, callback) => {
      var req = store.get(path);
      req.onsuccess = (event) => {
        callback(null, event.target.result);
      };
      req.onerror = (e) => {
        callback(e.target.error);
        e.preventDefault();
      };
    }, storeRemoteEntry: (store, path, entry, callback) => {
      try {
        var req = store.put(entry, path);
      } catch (e) {
        callback(e);
        return;
      }
      req.onsuccess = () => {
        callback(null);
      };
      req.onerror = (e) => {
        callback(e.target.error);
        e.preventDefault();
      };
    }, removeRemoteEntry: (store, path, callback) => {
      var req = store.delete(path);
      req.onsuccess = () => {
        callback(null);
      };
      req.onerror = (e) => {
        callback(e.target.error);
        e.preventDefault();
      };
    }, reconcile: (src, dst, callback) => {
      var total = 0;
      var create = [];
      Object.keys(src.entries).forEach(function(key) {
        var e = src.entries[key];
        var e2 = dst.entries[key];
        if (!e2 || e["timestamp"].getTime() != e2["timestamp"].getTime()) {
          create.push(key);
          total++;
        }
      });
      var remove = [];
      Object.keys(dst.entries).forEach(function(key) {
        if (!src.entries[key]) {
          remove.push(key);
          total++;
        }
      });
      if (!total) {
        return callback(null);
      }
      var errored = false;
      var db = src.type === "remote" ? src.db : dst.db;
      var transaction = db.transaction([IDBFS.DB_STORE_NAME], "readwrite");
      var store = transaction.objectStore(IDBFS.DB_STORE_NAME);
      function done(err2) {
        if (err2 && !errored) {
          errored = true;
          return callback(err2);
        }
      }
      transaction.onerror = (e) => {
        done(this.error);
        e.preventDefault();
      };
      transaction.oncomplete = (e) => {
        if (!errored) {
          callback(null);
        }
      };
      create.sort().forEach((path) => {
        if (dst.type === "local") {
          IDBFS.loadRemoteEntry(store, path, (err2, entry) => {
            if (err2) return done(err2);
            IDBFS.storeLocalEntry(path, entry, done);
          });
        } else {
          IDBFS.loadLocalEntry(path, (err2, entry) => {
            if (err2) return done(err2);
            IDBFS.storeRemoteEntry(store, path, entry, done);
          });
        }
      });
      remove.sort().reverse().forEach((path) => {
        if (dst.type === "local") {
          IDBFS.removeLocalEntry(path, done);
        } else {
          IDBFS.removeRemoteEntry(store, path, done);
        }
      });
    } };
    var ERRNO_MESSAGES = { 0: "Success", 1: "Arg list too long", 2: "Permission denied", 3: "Address already in use", 4: "Address not available", 5: "Address family not supported by protocol family", 6: "No more processes", 7: "Socket already connected", 8: "Bad file number", 9: "Trying to read unreadable message", 10: "Mount device busy", 11: "Operation canceled", 12: "No children", 13: "Connection aborted", 14: "Connection refused", 15: "Connection reset by peer", 16: "File locking deadlock error", 17: "Destination address required", 18: "Math arg out of domain of func", 19: "Quota exceeded", 20: "File exists", 21: "Bad address", 22: "File too large", 23: "Host is unreachable", 24: "Identifier removed", 25: "Illegal byte sequence", 26: "Connection already in progress", 27: "Interrupted system call", 28: "Invalid argument", 29: "I/O error", 30: "Socket is already connected", 31: "Is a directory", 32: "Too many symbolic links", 33: "Too many open files", 34: "Too many links", 35: "Message too long", 36: "Multihop attempted", 37: "File or path name too long", 38: "Network interface is not configured", 39: "Connection reset by network", 40: "Network is unreachable", 41: "Too many open files in system", 42: "No buffer space available", 43: "No such device", 44: "No such file or directory", 45: "Exec format error", 46: "No record locks available", 47: "The link has been severed", 48: "Not enough core", 49: "No message of desired type", 50: "Protocol not available", 51: "No space left on device", 52: "Function not implemented", 53: "Socket is not connected", 54: "Not a directory", 55: "Directory not empty", 56: "State not recoverable", 57: "Socket operation on non-socket", 59: "Not a typewriter", 60: "No such device or address", 61: "Value too large for defined data type", 62: "Previous owner died", 63: "Not super-user", 64: "Broken pipe", 65: "Protocol error", 66: "Unknown protocol", 67: "Protocol wrong type for socket", 68: "Math result not representable", 69: "Read only file system", 70: "Illegal seek", 71: "No such process", 72: "Stale file handle", 73: "Connection timed out", 74: "Text file busy", 75: "Cross-device link", 100: "Device not a stream", 101: "Bad font file fmt", 102: "Invalid slot", 103: "Invalid request code", 104: "No anode", 105: "Block device required", 106: "Channel number out of range", 107: "Level 3 halted", 108: "Level 3 reset", 109: "Link number out of range", 110: "Protocol driver not attached", 111: "No CSI structure available", 112: "Level 2 halted", 113: "Invalid exchange", 114: "Invalid request descriptor", 115: "Exchange full", 116: "No data (for no delay io)", 117: "Timer expired", 118: "Out of streams resources", 119: "Machine is not on the network", 120: "Package not installed", 121: "The object is remote", 122: "Advertise error", 123: "Srmount error", 124: "Communication error on send", 125: "Cross mount point (not really error)", 126: "Given log. name not unique", 127: "f.d. invalid for this operation", 128: "Remote address changed", 129: "Can   access a needed shared lib", 130: "Accessing a corrupted shared lib", 131: ".lib section in a.out corrupted", 132: "Attempting to link in too many libs", 133: "Attempting to exec a shared library", 135: "Streams pipe error", 136: "Too many users", 137: "Socket type not supported", 138: "Not supported", 139: "Protocol family not supported", 140: "Can't send after socket shutdown", 141: "Too many references", 142: "Host is down", 148: "No medium (in tape drive)", 156: "Level 2 not synchronized" };
    var ERRNO_CODES = {};
    function demangle(func) {
      warnOnce("warning: build with -sDEMANGLE_SUPPORT to link in libcxxabi demangling");
      return func;
    }
    function demangleAll(text) {
      var regex = /\b_Z[\w\d_]+/g;
      return text.replace(regex, function(x2) {
        var y = demangle(x2);
        return x2 === y ? x2 : y + " [" + x2 + "]";
      });
    }
    var FS = { root: null, mounts: [], devices: {}, streams: [], nextInode: 1, nameTable: null, currentPath: "/", initialized: false, ignorePermissions: true, ErrnoError: null, genericErrors: {}, filesystems: null, syncFSRequests: 0, lookupPath: (path, opts = {}) => {
      path = PATH_FS.resolve(path);
      if (!path) return { path: "", node: null };
      var defaults = { follow_mount: true, recurse_count: 0 };
      opts = Object.assign(defaults, opts);
      if (opts.recurse_count > 8) {
        throw new FS.ErrnoError(32);
      }
      var parts = path.split("/").filter((p) => !!p);
      var current = FS.root;
      var current_path = "/";
      for (var i2 = 0; i2 < parts.length; i2++) {
        var islast = i2 === parts.length - 1;
        if (islast && opts.parent) {
          break;
        }
        current = FS.lookupNode(current, parts[i2]);
        current_path = PATH.join2(current_path, parts[i2]);
        if (FS.isMountpoint(current)) {
          if (!islast || islast && opts.follow_mount) {
            current = current.mounted.root;
          }
        }
        if (!islast || opts.follow) {
          var count = 0;
          while (FS.isLink(current.mode)) {
            var link = FS.readlink(current_path);
            current_path = PATH_FS.resolve(PATH.dirname(current_path), link);
            var lookup = FS.lookupPath(current_path, { recurse_count: opts.recurse_count + 1 });
            current = lookup.node;
            if (count++ > 40) {
              throw new FS.ErrnoError(32);
            }
          }
        }
      }
      return { path: current_path, node: current };
    }, getPath: (node) => {
      var path;
      while (true) {
        if (FS.isRoot(node)) {
          var mount = node.mount.mountpoint;
          if (!path) return mount;
          return mount[mount.length - 1] !== "/" ? `${mount}/${path}` : mount + path;
        }
        path = path ? `${node.name}/${path}` : node.name;
        node = node.parent;
      }
    }, hashName: (parentid, name) => {
      var hash = 0;
      for (var i2 = 0; i2 < name.length; i2++) {
        hash = (hash << 5) - hash + name.charCodeAt(i2) | 0;
      }
      return (parentid + hash >>> 0) % FS.nameTable.length;
    }, hashAddNode: (node) => {
      var hash = FS.hashName(node.parent.id, node.name);
      node.name_next = FS.nameTable[hash];
      FS.nameTable[hash] = node;
    }, hashRemoveNode: (node) => {
      var hash = FS.hashName(node.parent.id, node.name);
      if (FS.nameTable[hash] === node) {
        FS.nameTable[hash] = node.name_next;
      } else {
        var current = FS.nameTable[hash];
        while (current) {
          if (current.name_next === node) {
            current.name_next = node.name_next;
            break;
          }
          current = current.name_next;
        }
      }
    }, lookupNode: (parent, name) => {
      var errCode = FS.mayLookup(parent);
      if (errCode) {
        throw new FS.ErrnoError(errCode, parent);
      }
      var hash = FS.hashName(parent.id, name);
      for (var node = FS.nameTable[hash]; node; node = node.name_next) {
        var nodeName = node.name;
        if (node.parent.id === parent.id && nodeName === name) {
          return node;
        }
      }
      return FS.lookup(parent, name);
    }, createNode: (parent, name, mode, rdev) => {
      assert(typeof parent == "object");
      var node = new FS.FSNode(parent, name, mode, rdev);
      FS.hashAddNode(node);
      return node;
    }, destroyNode: (node) => {
      FS.hashRemoveNode(node);
    }, isRoot: (node) => node === node.parent, isMountpoint: (node) => !!node.mounted, isFile: (mode) => (mode & 61440) === 32768, isDir: (mode) => (mode & 61440) === 16384, isLink: (mode) => (mode & 61440) === 40960, isChrdev: (mode) => (mode & 61440) === 8192, isBlkdev: (mode) => (mode & 61440) === 24576, isFIFO: (mode) => (mode & 61440) === 4096, isSocket: (mode) => (mode & 49152) === 49152, flagsToPermissionString: (flag) => {
      var perms = ["r", "w", "rw"][flag & 3];
      if (flag & 512) {
        perms += "w";
      }
      return perms;
    }, nodePermissions: (node, perms) => {
      if (FS.ignorePermissions) {
        return 0;
      }
      if (perms.includes("r") && !(node.mode & 292)) {
        return 2;
      } else if (perms.includes("w") && !(node.mode & 146)) {
        return 2;
      } else if (perms.includes("x") && !(node.mode & 73)) {
        return 2;
      }
      return 0;
    }, mayLookup: (dir) => {
      var errCode = FS.nodePermissions(dir, "x");
      if (errCode) return errCode;
      if (!dir.node_ops.lookup) return 2;
      return 0;
    }, mayCreate: (dir, name) => {
      try {
        var node = FS.lookupNode(dir, name);
        return 20;
      } catch (e) {
      }
      return FS.nodePermissions(dir, "wx");
    }, mayDelete: (dir, name, isdir) => {
      var node;
      try {
        node = FS.lookupNode(dir, name);
      } catch (e) {
        return e.errno;
      }
      var errCode = FS.nodePermissions(dir, "wx");
      if (errCode) {
        return errCode;
      }
      if (isdir) {
        if (!FS.isDir(node.mode)) {
          return 54;
        }
        if (FS.isRoot(node) || FS.getPath(node) === FS.cwd()) {
          return 10;
        }
      } else {
        if (FS.isDir(node.mode)) {
          return 31;
        }
      }
      return 0;
    }, mayOpen: (node, flags) => {
      if (!node) {
        return 44;
      }
      if (FS.isLink(node.mode)) {
        return 32;
      } else if (FS.isDir(node.mode)) {
        if (FS.flagsToPermissionString(flags) !== "r" || flags & 512) {
          return 31;
        }
      }
      return FS.nodePermissions(node, FS.flagsToPermissionString(flags));
    }, MAX_OPEN_FDS: 4096, nextfd: () => {
      for (var fd2 = 0; fd2 <= FS.MAX_OPEN_FDS; fd2++) {
        if (!FS.streams[fd2]) {
          return fd2;
        }
      }
      throw new FS.ErrnoError(33);
    }, getStreamChecked: (fd2) => {
      var stream = FS.getStream(fd2);
      if (!stream) {
        throw new FS.ErrnoError(8);
      }
      return stream;
    }, getStream: (fd2) => FS.streams[fd2], createStream: (stream, fd2 = -1) => {
      if (!FS.FSStream) {
        FS.FSStream = function() {
          this.shared = {};
        };
        FS.FSStream.prototype = {};
        Object.defineProperties(FS.FSStream.prototype, { object: { get() {
          return this.node;
        }, set(val) {
          this.node = val;
        } }, isRead: { get() {
          return (this.flags & 2097155) !== 1;
        } }, isWrite: { get() {
          return (this.flags & 2097155) !== 0;
        } }, isAppend: { get() {
          return this.flags & 1024;
        } }, flags: { get() {
          return this.shared.flags;
        }, set(val) {
          this.shared.flags = val;
        } }, position: { get() {
          return this.shared.position;
        }, set(val) {
          this.shared.position = val;
        } } });
      }
      stream = Object.assign(new FS.FSStream(), stream);
      if (fd2 == -1) {
        fd2 = FS.nextfd();
      }
      stream.fd = fd2;
      FS.streams[fd2] = stream;
      return stream;
    }, closeStream: (fd2) => {
      FS.streams[fd2] = null;
    }, chrdev_stream_ops: { open: (stream) => {
      var device = FS.getDevice(stream.node.rdev);
      stream.stream_ops = device.stream_ops;
      if (stream.stream_ops.open) {
        stream.stream_ops.open(stream);
      }
    }, llseek: () => {
      throw new FS.ErrnoError(70);
    } }, major: (dev) => dev >> 8, minor: (dev) => dev & 255, makedev: (ma, mi) => ma << 8 | mi, registerDevice: (dev, ops) => {
      FS.devices[dev] = { stream_ops: ops };
    }, getDevice: (dev) => FS.devices[dev], getMounts: (mount) => {
      var mounts = [];
      var check = [mount];
      while (check.length) {
        var m = check.pop();
        mounts.push(m);
        check.push.apply(check, m.mounts);
      }
      return mounts;
    }, syncfs: (populate, callback) => {
      if (typeof populate == "function") {
        callback = populate;
        populate = false;
      }
      FS.syncFSRequests++;
      if (FS.syncFSRequests > 1) {
        err(`warning: ${FS.syncFSRequests} FS.syncfs operations in flight at once, probably just doing extra work`);
      }
      var mounts = FS.getMounts(FS.root.mount);
      var completed = 0;
      function doCallback(errCode) {
        assert(FS.syncFSRequests > 0);
        FS.syncFSRequests--;
        return callback(errCode);
      }
      function done(errCode) {
        if (errCode) {
          if (!done.errored) {
            done.errored = true;
            return doCallback(errCode);
          }
          return;
        }
        if (++completed >= mounts.length) {
          doCallback(null);
        }
      }
      mounts.forEach((mount) => {
        if (!mount.type.syncfs) {
          return done(null);
        }
        mount.type.syncfs(mount, populate, done);
      });
    }, mount: (type, opts, mountpoint) => {
      if (typeof type == "string") {
        throw type;
      }
      var root = mountpoint === "/";
      var pseudo = !mountpoint;
      var node;
      if (root && FS.root) {
        throw new FS.ErrnoError(10);
      } else if (!root && !pseudo) {
        var lookup = FS.lookupPath(mountpoint, { follow_mount: false });
        mountpoint = lookup.path;
        node = lookup.node;
        if (FS.isMountpoint(node)) {
          throw new FS.ErrnoError(10);
        }
        if (!FS.isDir(node.mode)) {
          throw new FS.ErrnoError(54);
        }
      }
      var mount = { type, opts, mountpoint, mounts: [] };
      var mountRoot = type.mount(mount);
      mountRoot.mount = mount;
      mount.root = mountRoot;
      if (root) {
        FS.root = mountRoot;
      } else if (node) {
        node.mounted = mount;
        if (node.mount) {
          node.mount.mounts.push(mount);
        }
      }
      return mountRoot;
    }, unmount: (mountpoint) => {
      var lookup = FS.lookupPath(mountpoint, { follow_mount: false });
      if (!FS.isMountpoint(lookup.node)) {
        throw new FS.ErrnoError(28);
      }
      var node = lookup.node;
      var mount = node.mounted;
      var mounts = FS.getMounts(mount);
      Object.keys(FS.nameTable).forEach((hash) => {
        var current = FS.nameTable[hash];
        while (current) {
          var next = current.name_next;
          if (mounts.includes(current.mount)) {
            FS.destroyNode(current);
          }
          current = next;
        }
      });
      node.mounted = null;
      var idx = node.mount.mounts.indexOf(mount);
      assert(idx !== -1);
      node.mount.mounts.splice(idx, 1);
    }, lookup: (parent, name) => parent.node_ops.lookup(parent, name), mknod: (path, mode, dev) => {
      var lookup = FS.lookupPath(path, { parent: true });
      var parent = lookup.node;
      var name = PATH.basename(path);
      if (!name || name === "." || name === "..") {
        throw new FS.ErrnoError(28);
      }
      var errCode = FS.mayCreate(parent, name);
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      if (!parent.node_ops.mknod) {
        throw new FS.ErrnoError(63);
      }
      return parent.node_ops.mknod(parent, name, mode, dev);
    }, create: (path, mode) => {
      mode = mode !== void 0 ? mode : 438;
      mode &= 4095;
      mode |= 32768;
      return FS.mknod(path, mode, 0);
    }, mkdir: (path, mode) => {
      mode = mode !== void 0 ? mode : 511;
      mode &= 511 | 512;
      mode |= 16384;
      return FS.mknod(path, mode, 0);
    }, mkdirTree: (path, mode) => {
      var dirs = path.split("/");
      var d = "";
      for (var i2 = 0; i2 < dirs.length; ++i2) {
        if (!dirs[i2]) continue;
        d += "/" + dirs[i2];
        try {
          FS.mkdir(d, mode);
        } catch (e) {
          if (e.errno != 20) throw e;
        }
      }
    }, mkdev: (path, mode, dev) => {
      if (typeof dev == "undefined") {
        dev = mode;
        mode = 438;
      }
      mode |= 8192;
      return FS.mknod(path, mode, dev);
    }, symlink: (oldpath, newpath) => {
      if (!PATH_FS.resolve(oldpath)) {
        throw new FS.ErrnoError(44);
      }
      var lookup = FS.lookupPath(newpath, { parent: true });
      var parent = lookup.node;
      if (!parent) {
        throw new FS.ErrnoError(44);
      }
      var newname = PATH.basename(newpath);
      var errCode = FS.mayCreate(parent, newname);
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      if (!parent.node_ops.symlink) {
        throw new FS.ErrnoError(63);
      }
      return parent.node_ops.symlink(parent, newname, oldpath);
    }, rename: (old_path, new_path) => {
      var old_dirname = PATH.dirname(old_path);
      var new_dirname = PATH.dirname(new_path);
      var old_name = PATH.basename(old_path);
      var new_name = PATH.basename(new_path);
      var lookup, old_dir, new_dir;
      lookup = FS.lookupPath(old_path, { parent: true });
      old_dir = lookup.node;
      lookup = FS.lookupPath(new_path, { parent: true });
      new_dir = lookup.node;
      if (!old_dir || !new_dir) throw new FS.ErrnoError(44);
      if (old_dir.mount !== new_dir.mount) {
        throw new FS.ErrnoError(75);
      }
      var old_node = FS.lookupNode(old_dir, old_name);
      var relative = PATH_FS.relative(old_path, new_dirname);
      if (relative.charAt(0) !== ".") {
        throw new FS.ErrnoError(28);
      }
      relative = PATH_FS.relative(new_path, old_dirname);
      if (relative.charAt(0) !== ".") {
        throw new FS.ErrnoError(55);
      }
      var new_node;
      try {
        new_node = FS.lookupNode(new_dir, new_name);
      } catch (e) {
      }
      if (old_node === new_node) {
        return;
      }
      var isdir = FS.isDir(old_node.mode);
      var errCode = FS.mayDelete(old_dir, old_name, isdir);
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      errCode = new_node ? FS.mayDelete(new_dir, new_name, isdir) : FS.mayCreate(new_dir, new_name);
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      if (!old_dir.node_ops.rename) {
        throw new FS.ErrnoError(63);
      }
      if (FS.isMountpoint(old_node) || new_node && FS.isMountpoint(new_node)) {
        throw new FS.ErrnoError(10);
      }
      if (new_dir !== old_dir) {
        errCode = FS.nodePermissions(old_dir, "w");
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
      }
      FS.hashRemoveNode(old_node);
      try {
        old_dir.node_ops.rename(old_node, new_dir, new_name);
      } catch (e) {
        throw e;
      } finally {
        FS.hashAddNode(old_node);
      }
    }, rmdir: (path) => {
      var lookup = FS.lookupPath(path, { parent: true });
      var parent = lookup.node;
      var name = PATH.basename(path);
      var node = FS.lookupNode(parent, name);
      var errCode = FS.mayDelete(parent, name, true);
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      if (!parent.node_ops.rmdir) {
        throw new FS.ErrnoError(63);
      }
      if (FS.isMountpoint(node)) {
        throw new FS.ErrnoError(10);
      }
      parent.node_ops.rmdir(parent, name);
      FS.destroyNode(node);
    }, readdir: (path) => {
      var lookup = FS.lookupPath(path, { follow: true });
      var node = lookup.node;
      if (!node.node_ops.readdir) {
        throw new FS.ErrnoError(54);
      }
      return node.node_ops.readdir(node);
    }, unlink: (path) => {
      var lookup = FS.lookupPath(path, { parent: true });
      var parent = lookup.node;
      if (!parent) {
        throw new FS.ErrnoError(44);
      }
      var name = PATH.basename(path);
      var node = FS.lookupNode(parent, name);
      var errCode = FS.mayDelete(parent, name, false);
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      if (!parent.node_ops.unlink) {
        throw new FS.ErrnoError(63);
      }
      if (FS.isMountpoint(node)) {
        throw new FS.ErrnoError(10);
      }
      parent.node_ops.unlink(parent, name);
      FS.destroyNode(node);
    }, readlink: (path) => {
      var lookup = FS.lookupPath(path);
      var link = lookup.node;
      if (!link) {
        throw new FS.ErrnoError(44);
      }
      if (!link.node_ops.readlink) {
        throw new FS.ErrnoError(28);
      }
      return PATH_FS.resolve(FS.getPath(link.parent), link.node_ops.readlink(link));
    }, stat: (path, dontFollow) => {
      var lookup = FS.lookupPath(path, { follow: !dontFollow });
      var node = lookup.node;
      if (!node) {
        throw new FS.ErrnoError(44);
      }
      if (!node.node_ops.getattr) {
        throw new FS.ErrnoError(63);
      }
      return node.node_ops.getattr(node);
    }, lstat: (path) => FS.stat(path, true), chmod: (path, mode, dontFollow) => {
      var node;
      if (typeof path == "string") {
        var lookup = FS.lookupPath(path, { follow: !dontFollow });
        node = lookup.node;
      } else {
        node = path;
      }
      if (!node.node_ops.setattr) {
        throw new FS.ErrnoError(63);
      }
      node.node_ops.setattr(node, { mode: mode & 4095 | node.mode & -4096, timestamp: Date.now() });
    }, lchmod: (path, mode) => {
      FS.chmod(path, mode, true);
    }, fchmod: (fd2, mode) => {
      var stream = FS.getStreamChecked(fd2);
      FS.chmod(stream.node, mode);
    }, chown: (path, uid, gid, dontFollow) => {
      var node;
      if (typeof path == "string") {
        var lookup = FS.lookupPath(path, { follow: !dontFollow });
        node = lookup.node;
      } else {
        node = path;
      }
      if (!node.node_ops.setattr) {
        throw new FS.ErrnoError(63);
      }
      node.node_ops.setattr(node, { timestamp: Date.now() });
    }, lchown: (path, uid, gid) => {
      FS.chown(path, uid, gid, true);
    }, fchown: (fd2, uid, gid) => {
      var stream = FS.getStreamChecked(fd2);
      FS.chown(stream.node, uid, gid);
    }, truncate: (path, len2) => {
      if (len2 < 0) {
        throw new FS.ErrnoError(28);
      }
      var node;
      if (typeof path == "string") {
        var lookup = FS.lookupPath(path, { follow: true });
        node = lookup.node;
      } else {
        node = path;
      }
      if (!node.node_ops.setattr) {
        throw new FS.ErrnoError(63);
      }
      if (FS.isDir(node.mode)) {
        throw new FS.ErrnoError(31);
      }
      if (!FS.isFile(node.mode)) {
        throw new FS.ErrnoError(28);
      }
      var errCode = FS.nodePermissions(node, "w");
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      node.node_ops.setattr(node, { size: len2, timestamp: Date.now() });
    }, ftruncate: (fd2, len2) => {
      var stream = FS.getStreamChecked(fd2);
      if ((stream.flags & 2097155) === 0) {
        throw new FS.ErrnoError(28);
      }
      FS.truncate(stream.node, len2);
    }, utime: (path, atime, mtime) => {
      var lookup = FS.lookupPath(path, { follow: true });
      var node = lookup.node;
      node.node_ops.setattr(node, { timestamp: Math.max(atime, mtime) });
    }, open: (path, flags, mode) => {
      if (path === "") {
        throw new FS.ErrnoError(44);
      }
      flags = typeof flags == "string" ? FS_modeStringToFlags(flags) : flags;
      mode = typeof mode == "undefined" ? 438 : mode;
      if (flags & 64) {
        mode = mode & 4095 | 32768;
      } else {
        mode = 0;
      }
      var node;
      if (typeof path == "object") {
        node = path;
      } else {
        path = PATH.normalize(path);
        try {
          var lookup = FS.lookupPath(path, { follow: !(flags & 131072) });
          node = lookup.node;
        } catch (e) {
        }
      }
      var created = false;
      if (flags & 64) {
        if (node) {
          if (flags & 128) {
            throw new FS.ErrnoError(20);
          }
        } else {
          node = FS.mknod(path, mode, 0);
          created = true;
        }
      }
      if (!node) {
        throw new FS.ErrnoError(44);
      }
      if (FS.isChrdev(node.mode)) {
        flags &= -513;
      }
      if (flags & 65536 && !FS.isDir(node.mode)) {
        throw new FS.ErrnoError(54);
      }
      if (!created) {
        var errCode = FS.mayOpen(node, flags);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
      }
      if (flags & 512 && !created) {
        FS.truncate(node, 0);
      }
      flags &= -131713;
      var stream = FS.createStream({ node, path: FS.getPath(node), flags, seekable: true, position: 0, stream_ops: node.stream_ops, ungotten: [], error: false });
      if (stream.stream_ops.open) {
        stream.stream_ops.open(stream);
      }
      if (Module["logReadFiles"] && !(flags & 1)) {
        if (!FS.readFiles) FS.readFiles = {};
        if (!(path in FS.readFiles)) {
          FS.readFiles[path] = 1;
        }
      }
      return stream;
    }, close: (stream) => {
      if (FS.isClosed(stream)) {
        throw new FS.ErrnoError(8);
      }
      if (stream.getdents) stream.getdents = null;
      try {
        if (stream.stream_ops.close) {
          stream.stream_ops.close(stream);
        }
      } catch (e) {
        throw e;
      } finally {
        FS.closeStream(stream.fd);
      }
      stream.fd = null;
    }, isClosed: (stream) => stream.fd === null, llseek: (stream, offset, whence) => {
      if (FS.isClosed(stream)) {
        throw new FS.ErrnoError(8);
      }
      if (!stream.seekable || !stream.stream_ops.llseek) {
        throw new FS.ErrnoError(70);
      }
      if (whence != 0 && whence != 1 && whence != 2) {
        throw new FS.ErrnoError(28);
      }
      stream.position = stream.stream_ops.llseek(stream, offset, whence);
      stream.ungotten = [];
      return stream.position;
    }, read: (stream, buffer, offset, length, position) => {
      assert(offset >= 0);
      if (length < 0 || position < 0) {
        throw new FS.ErrnoError(28);
      }
      if (FS.isClosed(stream)) {
        throw new FS.ErrnoError(8);
      }
      if ((stream.flags & 2097155) === 1) {
        throw new FS.ErrnoError(8);
      }
      if (FS.isDir(stream.node.mode)) {
        throw new FS.ErrnoError(31);
      }
      if (!stream.stream_ops.read) {
        throw new FS.ErrnoError(28);
      }
      var seeking = typeof position != "undefined";
      if (!seeking) {
        position = stream.position;
      } else if (!stream.seekable) {
        throw new FS.ErrnoError(70);
      }
      var bytesRead = stream.stream_ops.read(stream, buffer, offset, length, position);
      if (!seeking) stream.position += bytesRead;
      return bytesRead;
    }, write: (stream, buffer, offset, length, position, canOwn) => {
      assert(offset >= 0);
      if (length < 0 || position < 0) {
        throw new FS.ErrnoError(28);
      }
      if (FS.isClosed(stream)) {
        throw new FS.ErrnoError(8);
      }
      if ((stream.flags & 2097155) === 0) {
        throw new FS.ErrnoError(8);
      }
      if (FS.isDir(stream.node.mode)) {
        throw new FS.ErrnoError(31);
      }
      if (!stream.stream_ops.write) {
        throw new FS.ErrnoError(28);
      }
      if (stream.seekable && stream.flags & 1024) {
        FS.llseek(stream, 0, 2);
      }
      var seeking = typeof position != "undefined";
      if (!seeking) {
        position = stream.position;
      } else if (!stream.seekable) {
        throw new FS.ErrnoError(70);
      }
      var bytesWritten = stream.stream_ops.write(stream, buffer, offset, length, position, canOwn);
      if (!seeking) stream.position += bytesWritten;
      return bytesWritten;
    }, allocate: (stream, offset, length) => {
      if (FS.isClosed(stream)) {
        throw new FS.ErrnoError(8);
      }
      if (offset < 0 || length <= 0) {
        throw new FS.ErrnoError(28);
      }
      if ((stream.flags & 2097155) === 0) {
        throw new FS.ErrnoError(8);
      }
      if (!FS.isFile(stream.node.mode) && !FS.isDir(stream.node.mode)) {
        throw new FS.ErrnoError(43);
      }
      if (!stream.stream_ops.allocate) {
        throw new FS.ErrnoError(138);
      }
      stream.stream_ops.allocate(stream, offset, length);
    }, mmap: (stream, length, position, prot, flags) => {
      if ((prot & 2) !== 0 && (flags & 2) === 0 && (stream.flags & 2097155) !== 2) {
        throw new FS.ErrnoError(2);
      }
      if ((stream.flags & 2097155) === 1) {
        throw new FS.ErrnoError(2);
      }
      if (!stream.stream_ops.mmap) {
        throw new FS.ErrnoError(43);
      }
      return stream.stream_ops.mmap(stream, length, position, prot, flags);
    }, msync: (stream, buffer, offset, length, mmapFlags) => {
      assert(offset >= 0);
      if (!stream.stream_ops.msync) {
        return 0;
      }
      return stream.stream_ops.msync(stream, buffer, offset, length, mmapFlags);
    }, munmap: (stream) => 0, ioctl: (stream, cmd, arg) => {
      if (!stream.stream_ops.ioctl) {
        throw new FS.ErrnoError(59);
      }
      return stream.stream_ops.ioctl(stream, cmd, arg);
    }, readFile: (path, opts = {}) => {
      opts.flags = opts.flags || 0;
      opts.encoding = opts.encoding || "binary";
      if (opts.encoding !== "utf8" && opts.encoding !== "binary") {
        throw new Error(`Invalid encoding type "${opts.encoding}"`);
      }
      var ret;
      var stream = FS.open(path, opts.flags);
      var stat = FS.stat(path);
      var length = stat.size;
      var buf = new Uint8Array(length);
      FS.read(stream, buf, 0, length, 0);
      if (opts.encoding === "utf8") {
        ret = UTF8ArrayToString(buf, 0);
      } else if (opts.encoding === "binary") {
        ret = buf;
      }
      FS.close(stream);
      return ret;
    }, writeFile: (path, data, opts = {}) => {
      opts.flags = opts.flags || 577;
      var stream = FS.open(path, opts.flags, opts.mode);
      if (typeof data == "string") {
        var buf = new Uint8Array(lengthBytesUTF8(data) + 1);
        var actualNumBytes = stringToUTF8Array(data, buf, 0, buf.length);
        FS.write(stream, buf, 0, actualNumBytes, void 0, opts.canOwn);
      } else if (ArrayBuffer.isView(data)) {
        FS.write(stream, data, 0, data.byteLength, void 0, opts.canOwn);
      } else {
        throw new Error("Unsupported data type");
      }
      FS.close(stream);
    }, cwd: () => FS.currentPath, chdir: (path) => {
      var lookup = FS.lookupPath(path, { follow: true });
      if (lookup.node === null) {
        throw new FS.ErrnoError(44);
      }
      if (!FS.isDir(lookup.node.mode)) {
        throw new FS.ErrnoError(54);
      }
      var errCode = FS.nodePermissions(lookup.node, "x");
      if (errCode) {
        throw new FS.ErrnoError(errCode);
      }
      FS.currentPath = lookup.path;
    }, createDefaultDirectories: () => {
      FS.mkdir("/tmp");
      FS.mkdir("/home");
      FS.mkdir("/home/web_user");
    }, createDefaultDevices: () => {
      FS.mkdir("/dev");
      FS.registerDevice(FS.makedev(1, 3), { read: () => 0, write: (stream, buffer, offset, length, pos) => length });
      FS.mkdev("/dev/null", FS.makedev(1, 3));
      TTY.register(FS.makedev(5, 0), TTY.default_tty_ops);
      TTY.register(FS.makedev(6, 0), TTY.default_tty1_ops);
      FS.mkdev("/dev/tty", FS.makedev(5, 0));
      FS.mkdev("/dev/tty1", FS.makedev(6, 0));
      var randomBuffer = new Uint8Array(1024), randomLeft = 0;
      var randomByte = () => {
        if (randomLeft === 0) {
          randomLeft = randomFill(randomBuffer).byteLength;
        }
        return randomBuffer[--randomLeft];
      };
      FS.createDevice("/dev", "random", randomByte);
      FS.createDevice("/dev", "urandom", randomByte);
      FS.mkdir("/dev/shm");
      FS.mkdir("/dev/shm/tmp");
    }, createSpecialDirectories: () => {
      FS.mkdir("/proc");
      var proc_self = FS.mkdir("/proc/self");
      FS.mkdir("/proc/self/fd");
      FS.mount({ mount: () => {
        var node = FS.createNode(proc_self, "fd", 16384 | 511, 73);
        node.node_ops = { lookup: (parent, name) => {
          var fd2 = +name;
          var stream = FS.getStreamChecked(fd2);
          var ret = { parent: null, mount: { mountpoint: "fake" }, node_ops: { readlink: () => stream.path } };
          ret.parent = ret;
          return ret;
        } };
        return node;
      } }, {}, "/proc/self/fd");
    }, createStandardStreams: () => {
      if (Module["stdin"]) {
        FS.createDevice("/dev", "stdin", Module["stdin"]);
      } else {
        FS.symlink("/dev/tty", "/dev/stdin");
      }
      if (Module["stdout"]) {
        FS.createDevice("/dev", "stdout", null, Module["stdout"]);
      } else {
        FS.symlink("/dev/tty", "/dev/stdout");
      }
      if (Module["stderr"]) {
        FS.createDevice("/dev", "stderr", null, Module["stderr"]);
      } else {
        FS.symlink("/dev/tty1", "/dev/stderr");
      }
      var stdin = FS.open("/dev/stdin", 0);
      var stdout = FS.open("/dev/stdout", 1);
      var stderr = FS.open("/dev/stderr", 1);
      assert(stdin.fd === 0, `invalid handle for stdin (${stdin.fd})`);
      assert(stdout.fd === 1, `invalid handle for stdout (${stdout.fd})`);
      assert(stderr.fd === 2, `invalid handle for stderr (${stderr.fd})`);
    }, ensureErrnoError: () => {
      if (FS.ErrnoError) return;
      FS.ErrnoError = function ErrnoError(errno, node) {
        this.name = "ErrnoError";
        this.node = node;
        this.setErrno = function(errno2) {
          this.errno = errno2;
          for (var key in ERRNO_CODES) {
            if (ERRNO_CODES[key] === errno2) {
              this.code = key;
              break;
            }
          }
        };
        this.setErrno(errno);
        this.message = ERRNO_MESSAGES[errno];
        if (this.stack) {
          Object.defineProperty(this, "stack", { value: new Error().stack, writable: true });
          this.stack = demangleAll(this.stack);
        }
      };
      FS.ErrnoError.prototype = new Error();
      FS.ErrnoError.prototype.constructor = FS.ErrnoError;
      [44].forEach((code) => {
        FS.genericErrors[code] = new FS.ErrnoError(code);
        FS.genericErrors[code].stack = "<generic error, no stack>";
      });
    }, staticInit: () => {
      FS.ensureErrnoError();
      FS.nameTable = new Array(4096);
      FS.mount(MEMFS, {}, "/");
      FS.createDefaultDirectories();
      FS.createDefaultDevices();
      FS.createSpecialDirectories();
      FS.filesystems = { "MEMFS": MEMFS, "IDBFS": IDBFS };
    }, init: (input, output, error) => {
      assert(!FS.init.initialized, "FS.init was previously called. If you want to initialize later with custom parameters, remove any earlier calls (note that one is automatically added to the generated code)");
      FS.init.initialized = true;
      FS.ensureErrnoError();
      Module["stdin"] = input || Module["stdin"];
      Module["stdout"] = output || Module["stdout"];
      Module["stderr"] = error || Module["stderr"];
      FS.createStandardStreams();
    }, quit: () => {
      FS.init.initialized = false;
      _fflush(0);
      for (var i2 = 0; i2 < FS.streams.length; i2++) {
        var stream = FS.streams[i2];
        if (!stream) {
          continue;
        }
        FS.close(stream);
      }
    }, findObject: (path, dontResolveLastLink) => {
      var ret = FS.analyzePath(path, dontResolveLastLink);
      if (!ret.exists) {
        return null;
      }
      return ret.object;
    }, analyzePath: (path, dontResolveLastLink) => {
      try {
        var lookup = FS.lookupPath(path, { follow: !dontResolveLastLink });
        path = lookup.path;
      } catch (e) {
      }
      var ret = { isRoot: false, exists: false, error: 0, name: null, path: null, object: null, parentExists: false, parentPath: null, parentObject: null };
      try {
        var lookup = FS.lookupPath(path, { parent: true });
        ret.parentExists = true;
        ret.parentPath = lookup.path;
        ret.parentObject = lookup.node;
        ret.name = PATH.basename(path);
        lookup = FS.lookupPath(path, { follow: !dontResolveLastLink });
        ret.exists = true;
        ret.path = lookup.path;
        ret.object = lookup.node;
        ret.name = lookup.node.name;
        ret.isRoot = lookup.path === "/";
      } catch (e) {
        ret.error = e.errno;
      }
      return ret;
    }, createPath: (parent, path, canRead, canWrite) => {
      parent = typeof parent == "string" ? parent : FS.getPath(parent);
      var parts = path.split("/").reverse();
      while (parts.length) {
        var part = parts.pop();
        if (!part) continue;
        var current = PATH.join2(parent, part);
        try {
          FS.mkdir(current);
        } catch (e) {
        }
        parent = current;
      }
      return current;
    }, createFile: (parent, name, properties, canRead, canWrite) => {
      var path = PATH.join2(typeof parent == "string" ? parent : FS.getPath(parent), name);
      var mode = FS_getMode(canRead, canWrite);
      return FS.create(path, mode);
    }, createDataFile: (parent, name, data, canRead, canWrite, canOwn) => {
      var path = name;
      if (parent) {
        parent = typeof parent == "string" ? parent : FS.getPath(parent);
        path = name ? PATH.join2(parent, name) : parent;
      }
      var mode = FS_getMode(canRead, canWrite);
      var node = FS.create(path, mode);
      if (data) {
        if (typeof data == "string") {
          var arr = new Array(data.length);
          for (var i2 = 0, len2 = data.length; i2 < len2; ++i2) arr[i2] = data.charCodeAt(i2);
          data = arr;
        }
        FS.chmod(node, mode | 146);
        var stream = FS.open(node, 577);
        FS.write(stream, data, 0, data.length, 0, canOwn);
        FS.close(stream);
        FS.chmod(node, mode);
      }
      return node;
    }, createDevice: (parent, name, input, output) => {
      var path = PATH.join2(typeof parent == "string" ? parent : FS.getPath(parent), name);
      var mode = FS_getMode(!!input, !!output);
      if (!FS.createDevice.major) FS.createDevice.major = 64;
      var dev = FS.makedev(FS.createDevice.major++, 0);
      FS.registerDevice(dev, { open: (stream) => {
        stream.seekable = false;
      }, close: (stream) => {
        if (output && output.buffer && output.buffer.length) {
          output(10);
        }
      }, read: (stream, buffer, offset, length, pos) => {
        var bytesRead = 0;
        for (var i2 = 0; i2 < length; i2++) {
          var result;
          try {
            result = input();
          } catch (e) {
            throw new FS.ErrnoError(29);
          }
          if (result === void 0 && bytesRead === 0) {
            throw new FS.ErrnoError(6);
          }
          if (result === null || result === void 0) break;
          bytesRead++;
          buffer[offset + i2] = result;
        }
        if (bytesRead) {
          stream.node.timestamp = Date.now();
        }
        return bytesRead;
      }, write: (stream, buffer, offset, length, pos) => {
        for (var i2 = 0; i2 < length; i2++) {
          try {
            output(buffer[offset + i2]);
          } catch (e) {
            throw new FS.ErrnoError(29);
          }
        }
        if (length) {
          stream.node.timestamp = Date.now();
        }
        return i2;
      } });
      return FS.mkdev(path, mode, dev);
    }, forceLoadFile: (obj) => {
      if (obj.isDevice || obj.isFolder || obj.link || obj.contents) return true;
      if (typeof XMLHttpRequest != "undefined") {
        throw new Error("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");
      } else if (read_) {
        try {
          obj.contents = intArrayFromString(read_(obj.url), true);
          obj.usedBytes = obj.contents.length;
        } catch (e) {
          throw new FS.ErrnoError(29);
        }
      } else {
        throw new Error("Cannot load without read() or XMLHttpRequest.");
      }
    }, createLazyFile: (parent, name, url, canRead, canWrite) => {
      function LazyUint8Array() {
        this.lengthKnown = false;
        this.chunks = [];
      }
      LazyUint8Array.prototype.get = function LazyUint8Array_get(idx) {
        if (idx > this.length - 1 || idx < 0) {
          return void 0;
        }
        var chunkOffset = idx % this.chunkSize;
        var chunkNum = idx / this.chunkSize | 0;
        return this.getter(chunkNum)[chunkOffset];
      };
      LazyUint8Array.prototype.setDataGetter = function LazyUint8Array_setDataGetter(getter) {
        this.getter = getter;
      };
      LazyUint8Array.prototype.cacheLength = function LazyUint8Array_cacheLength() {
        var xhr = new XMLHttpRequest();
        xhr.open("HEAD", url, false);
        xhr.send(null);
        if (!(xhr.status >= 200 && xhr.status < 300 || xhr.status === 304)) throw new Error("Couldn't load " + url + ". Status: " + xhr.status);
        var datalength = Number(xhr.getResponseHeader("Content-length"));
        var header;
        var hasByteServing = (header = xhr.getResponseHeader("Accept-Ranges")) && header === "bytes";
        var usesGzip = (header = xhr.getResponseHeader("Content-Encoding")) && header === "gzip";
        var chunkSize = 1024 * 1024;
        if (!hasByteServing) chunkSize = datalength;
        var doXHR = (from, to) => {
          if (from > to) throw new Error("invalid range (" + from + ", " + to + ") or no bytes requested!");
          if (to > datalength - 1) throw new Error("only " + datalength + " bytes available! programmer error!");
          var xhr2 = new XMLHttpRequest();
          xhr2.open("GET", url, false);
          if (datalength !== chunkSize) xhr2.setRequestHeader("Range", "bytes=" + from + "-" + to);
          xhr2.responseType = "arraybuffer";
          if (xhr2.overrideMimeType) {
            xhr2.overrideMimeType("text/plain; charset=x-user-defined");
          }
          xhr2.send(null);
          if (!(xhr2.status >= 200 && xhr2.status < 300 || xhr2.status === 304)) throw new Error("Couldn't load " + url + ". Status: " + xhr2.status);
          if (xhr2.response !== void 0) {
            return new Uint8Array(xhr2.response || []);
          }
          return intArrayFromString(xhr2.responseText || "", true);
        };
        var lazyArray2 = this;
        lazyArray2.setDataGetter((chunkNum) => {
          var start = chunkNum * chunkSize;
          var end = (chunkNum + 1) * chunkSize - 1;
          end = Math.min(end, datalength - 1);
          if (typeof lazyArray2.chunks[chunkNum] == "undefined") {
            lazyArray2.chunks[chunkNum] = doXHR(start, end);
          }
          if (typeof lazyArray2.chunks[chunkNum] == "undefined") throw new Error("doXHR failed!");
          return lazyArray2.chunks[chunkNum];
        });
        if (usesGzip || !datalength) {
          chunkSize = datalength = 1;
          datalength = this.getter(0).length;
          chunkSize = datalength;
          out("LazyFiles on gzip forces download of the whole file when length is accessed");
        }
        this._length = datalength;
        this._chunkSize = chunkSize;
        this.lengthKnown = true;
      };
      if (typeof XMLHttpRequest != "undefined") {
        throw "Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc";
        var lazyArray = new LazyUint8Array();
        var properties = { isDevice: false, contents: lazyArray };
      } else {
        var properties = { isDevice: false, url };
      }
      var node = FS.createFile(parent, name, properties, canRead, canWrite);
      if (properties.contents) {
        node.contents = properties.contents;
      } else if (properties.url) {
        node.contents = null;
        node.url = properties.url;
      }
      Object.defineProperties(node, { usedBytes: { get: function() {
        return this.contents.length;
      } } });
      var stream_ops = {};
      var keys = Object.keys(node.stream_ops);
      keys.forEach((key) => {
        var fn = node.stream_ops[key];
        stream_ops[key] = function forceLoadLazyFile() {
          FS.forceLoadFile(node);
          return fn.apply(null, arguments);
        };
      });
      function writeChunks(stream, buffer, offset, length, position) {
        var contents = stream.node.contents;
        if (position >= contents.length) return 0;
        var size = Math.min(contents.length - position, length);
        assert(size >= 0);
        if (contents.slice) {
          for (var i2 = 0; i2 < size; i2++) {
            buffer[offset + i2] = contents[position + i2];
          }
        } else {
          for (var i2 = 0; i2 < size; i2++) {
            buffer[offset + i2] = contents.get(position + i2);
          }
        }
        return size;
      }
      stream_ops.read = (stream, buffer, offset, length, position) => {
        FS.forceLoadFile(node);
        return writeChunks(stream, buffer, offset, length, position);
      };
      stream_ops.mmap = (stream, length, position, prot, flags) => {
        FS.forceLoadFile(node);
        var ptr = mmapAlloc(length);
        if (!ptr) {
          throw new FS.ErrnoError(48);
        }
        writeChunks(stream, HEAP8, ptr, length, position);
        return { ptr, allocated: true };
      };
      node.stream_ops = stream_ops;
      return node;
    }, absolutePath: () => {
      abort("FS.absolutePath has been removed; use PATH_FS.resolve instead");
    }, createFolder: () => {
      abort("FS.createFolder has been removed; use FS.mkdir instead");
    }, createLink: () => {
      abort("FS.createLink has been removed; use FS.symlink instead");
    }, joinPath: () => {
      abort("FS.joinPath has been removed; use PATH.join instead");
    }, mmapAlloc: () => {
      abort("FS.mmapAlloc has been replaced by the top level function mmapAlloc");
    }, standardizePath: () => {
      abort("FS.standardizePath has been removed; use PATH.normalize instead");
    } };
    var SYSCALLS = { DEFAULT_POLLMASK: 5, calculateAt: function(dirfd, path, allowEmpty) {
      if (PATH.isAbs(path)) {
        return path;
      }
      var dir;
      if (dirfd === -100) {
        dir = FS.cwd();
      } else {
        var dirstream = SYSCALLS.getStreamFromFD(dirfd);
        dir = dirstream.path;
      }
      if (path.length == 0) {
        if (!allowEmpty) {
          throw new FS.ErrnoError(44);
        }
        return dir;
      }
      return PATH.join2(dir, path);
    }, doStat: function(func, path, buf) {
      try {
        var stat = func(path);
      } catch (e) {
        if (e && e.node && PATH.normalize(path) !== PATH.normalize(FS.getPath(e.node))) {
          return -54;
        }
        throw e;
      }
      HEAP32[buf >>> 2] = stat.dev;
      HEAP32[buf + 4 >>> 2] = stat.mode;
      HEAPU32[buf + 8 >>> 2] = stat.nlink;
      HEAP32[buf + 12 >>> 2] = stat.uid;
      HEAP32[buf + 16 >>> 2] = stat.gid;
      HEAP32[buf + 20 >>> 2] = stat.rdev;
      tempI64 = [stat.size >>> 0, (tempDouble = stat.size, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[buf + 24 >>> 2] = tempI64[0], HEAP32[buf + 28 >>> 2] = tempI64[1];
      HEAP32[buf + 32 >>> 2] = 4096;
      HEAP32[buf + 36 >>> 2] = stat.blocks;
      var atime = stat.atime.getTime();
      var mtime = stat.mtime.getTime();
      var ctime = stat.ctime.getTime();
      tempI64 = [Math.floor(atime / 1e3) >>> 0, (tempDouble = Math.floor(atime / 1e3), +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[buf + 40 >>> 2] = tempI64[0], HEAP32[buf + 44 >>> 2] = tempI64[1];
      HEAPU32[buf + 48 >>> 2] = atime % 1e3 * 1e3;
      tempI64 = [Math.floor(mtime / 1e3) >>> 0, (tempDouble = Math.floor(mtime / 1e3), +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[buf + 56 >>> 2] = tempI64[0], HEAP32[buf + 60 >>> 2] = tempI64[1];
      HEAPU32[buf + 64 >>> 2] = mtime % 1e3 * 1e3;
      tempI64 = [Math.floor(ctime / 1e3) >>> 0, (tempDouble = Math.floor(ctime / 1e3), +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[buf + 72 >>> 2] = tempI64[0], HEAP32[buf + 76 >>> 2] = tempI64[1];
      HEAPU32[buf + 80 >>> 2] = ctime % 1e3 * 1e3;
      tempI64 = [stat.ino >>> 0, (tempDouble = stat.ino, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[buf + 88 >>> 2] = tempI64[0], HEAP32[buf + 92 >>> 2] = tempI64[1];
      return 0;
    }, doMsync: function(addr, stream, len2, flags, offset) {
      if (!FS.isFile(stream.node.mode)) {
        throw new FS.ErrnoError(43);
      }
      if (flags & 2) {
        return 0;
      }
      var buffer = HEAPU8.slice(addr, addr + len2);
      FS.msync(stream, buffer, offset, len2, flags);
    }, varargs: void 0, get() {
      assert(SYSCALLS.varargs != void 0);
      SYSCALLS.varargs += 4;
      var ret = HEAP32[SYSCALLS.varargs - 4 >>> 2];
      return ret;
    }, getStr(ptr) {
      var ret = UTF8ToString(ptr);
      return ret;
    }, getStreamFromFD: function(fd2) {
      var stream = FS.getStreamChecked(fd2);
      return stream;
    } };
    function ___syscall__newselect(nfds, readfds, writefds, exceptfds, timeout) {
      readfds >>>= 0;
      writefds >>>= 0;
      exceptfds >>>= 0;
      timeout >>>= 0;
      try {
        assert(nfds <= 64, "nfds must be less than or equal to 64");
        assert(!exceptfds, "exceptfds not supported");
        var total = 0;
        var srcReadLow = readfds ? HEAP32[readfds >>> 2] : 0, srcReadHigh = readfds ? HEAP32[readfds + 4 >>> 2] : 0;
        var srcWriteLow = writefds ? HEAP32[writefds >>> 2] : 0, srcWriteHigh = writefds ? HEAP32[writefds + 4 >>> 2] : 0;
        var srcExceptLow = exceptfds ? HEAP32[exceptfds >>> 2] : 0, srcExceptHigh = exceptfds ? HEAP32[exceptfds + 4 >>> 2] : 0;
        var dstReadLow = 0, dstReadHigh = 0;
        var dstWriteLow = 0, dstWriteHigh = 0;
        var dstExceptLow = 0, dstExceptHigh = 0;
        var allLow = (readfds ? HEAP32[readfds >>> 2] : 0) | (writefds ? HEAP32[writefds >>> 2] : 0) | (exceptfds ? HEAP32[exceptfds >>> 2] : 0);
        var allHigh = (readfds ? HEAP32[readfds + 4 >>> 2] : 0) | (writefds ? HEAP32[writefds + 4 >>> 2] : 0) | (exceptfds ? HEAP32[exceptfds + 4 >>> 2] : 0);
        var check = function(fd3, low, high, val) {
          return fd3 < 32 ? low & val : high & val;
        };
        for (var fd2 = 0; fd2 < nfds; fd2++) {
          var mask = 1 << fd2 % 32;
          if (!check(fd2, allLow, allHigh, mask)) {
            continue;
          }
          var stream = SYSCALLS.getStreamFromFD(fd2);
          var flags = SYSCALLS.DEFAULT_POLLMASK;
          if (stream.stream_ops.poll) {
            var timeoutInMillis = -1;
            if (timeout) {
              var tv_sec = readfds ? HEAP32[timeout >>> 2] : 0, tv_usec = readfds ? HEAP32[timeout + 8 >>> 2] : 0;
              timeoutInMillis = (tv_sec + tv_usec / 1e6) * 1e3;
            }
            flags = stream.stream_ops.poll(stream, timeoutInMillis);
          }
          if (flags & 1 && check(fd2, srcReadLow, srcReadHigh, mask)) {
            fd2 < 32 ? dstReadLow = dstReadLow | mask : dstReadHigh = dstReadHigh | mask;
            total++;
          }
          if (flags & 4 && check(fd2, srcWriteLow, srcWriteHigh, mask)) {
            fd2 < 32 ? dstWriteLow = dstWriteLow | mask : dstWriteHigh = dstWriteHigh | mask;
            total++;
          }
          if (flags & 2 && check(fd2, srcExceptLow, srcExceptHigh, mask)) {
            fd2 < 32 ? dstExceptLow = dstExceptLow | mask : dstExceptHigh = dstExceptHigh | mask;
            total++;
          }
        }
        if (readfds) {
          HEAP32[readfds >>> 2] = dstReadLow;
          HEAP32[readfds + 4 >>> 2] = dstReadHigh;
        }
        if (writefds) {
          HEAP32[writefds >>> 2] = dstWriteLow;
          HEAP32[writefds + 4 >>> 2] = dstWriteHigh;
        }
        if (exceptfds) {
          HEAP32[exceptfds >>> 2] = dstExceptLow;
          HEAP32[exceptfds + 4 >>> 2] = dstExceptHigh;
        }
        return total;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    var SOCKFS = { mount(mount) {
      Module["websocket"] = Module["websocket"] && "object" === typeof Module["websocket"] ? Module["websocket"] : {};
      Module["websocket"]._callbacks = {};
      Module["websocket"]["on"] = function(event, callback) {
        if ("function" === typeof callback) {
          this._callbacks[event] = callback;
        }
        return this;
      };
      Module["websocket"].emit = function(event, param) {
        if ("function" === typeof this._callbacks[event]) {
          this._callbacks[event].call(this, param);
        }
      };
      return FS.createNode(null, "/", 16384 | 511, 0);
    }, createSocket(family, type, protocol) {
      type &= -526337;
      var streaming = type == 1;
      if (streaming && protocol && protocol != 6) {
        throw new FS.ErrnoError(66);
      }
      var sock = { family, type, protocol, server: null, error: null, peers: {}, pending: [], recv_queue: [], sock_ops: SOCKFS.websocket_sock_ops };
      var name = SOCKFS.nextname();
      var node = FS.createNode(SOCKFS.root, name, 49152, 0);
      node.sock = sock;
      var stream = FS.createStream({ path: name, node, flags: 2, seekable: false, stream_ops: SOCKFS.stream_ops });
      sock.stream = stream;
      return sock;
    }, getSocket(fd2) {
      var stream = FS.getStream(fd2);
      if (!stream || !FS.isSocket(stream.node.mode)) {
        return null;
      }
      return stream.node.sock;
    }, stream_ops: { poll(stream) {
      var sock = stream.node.sock;
      return sock.sock_ops.poll(sock);
    }, ioctl(stream, request, varargs) {
      var sock = stream.node.sock;
      return sock.sock_ops.ioctl(sock, request, varargs);
    }, read(stream, buffer, offset, length, position) {
      var sock = stream.node.sock;
      var msg = sock.sock_ops.recvmsg(sock, length);
      if (!msg) {
        return 0;
      }
      buffer.set(msg.buffer, offset);
      return msg.buffer.length;
    }, write(stream, buffer, offset, length, position) {
      var sock = stream.node.sock;
      return sock.sock_ops.sendmsg(sock, buffer, offset, length);
    }, close(stream) {
      var sock = stream.node.sock;
      sock.sock_ops.close(sock);
    } }, nextname() {
      if (!SOCKFS.nextname.current) {
        SOCKFS.nextname.current = 0;
      }
      return "socket[" + SOCKFS.nextname.current++ + "]";
    }, websocket_sock_ops: { createPeer(sock, addr, port) {
      var ws;
      if (typeof addr == "object") {
        ws = addr;
        addr = null;
        port = null;
      }
      if (ws) {
        if (ws._socket) {
          addr = ws._socket.remoteAddress;
          port = ws._socket.remotePort;
        } else {
          var result = /ws[s]?:\/\/([^:]+):(\d+)/.exec(ws.url);
          if (!result) {
            throw new Error("WebSocket URL must be in the format ws(s)://address:port");
          }
          addr = result[1];
          port = parseInt(result[2], 10);
        }
      } else {
        try {
          var runtimeConfig = Module["websocket"] && "object" === typeof Module["websocket"];
          var url = "ws:#".replace("#", "//");
          if (runtimeConfig) {
            if ("string" === typeof Module["websocket"]["url"]) {
              url = Module["websocket"]["url"];
            }
          }
          if (url === "ws://" || url === "wss://") {
            var parts = addr.split("/");
            url = url + parts[0] + ":" + port + "/" + parts.slice(1).join("/");
          }
          var subProtocols = "binary";
          if (runtimeConfig) {
            if ("string" === typeof Module["websocket"]["subprotocol"]) {
              subProtocols = Module["websocket"]["subprotocol"];
            }
          }
          var opts = void 0;
          if (subProtocols !== "null") {
            subProtocols = subProtocols.replace(/^ +| +$/g, "").split(/ *, */);
            opts = subProtocols;
          }
          if (runtimeConfig && null === Module["websocket"]["subprotocol"]) {
            subProtocols = "null";
            opts = void 0;
          }
          var WebSocketConstructor;
          {
            WebSocketConstructor = WebSocket;
          }
          ws = new WebSocketConstructor(url, opts);
          ws.binaryType = "arraybuffer";
        } catch (e) {
          throw new FS.ErrnoError(23);
        }
      }
      var peer = { addr, port, socket: ws, dgram_send_queue: [] };
      SOCKFS.websocket_sock_ops.addPeer(sock, peer);
      SOCKFS.websocket_sock_ops.handlePeerEvents(sock, peer);
      if (sock.type === 2 && typeof sock.sport != "undefined") {
        peer.dgram_send_queue.push(new Uint8Array([255, 255, 255, 255, "p".charCodeAt(0), "o".charCodeAt(0), "r".charCodeAt(0), "t".charCodeAt(0), (sock.sport & 65280) >> 8, sock.sport & 255]));
      }
      return peer;
    }, getPeer(sock, addr, port) {
      return sock.peers[addr + ":" + port];
    }, addPeer(sock, peer) {
      sock.peers[peer.addr + ":" + peer.port] = peer;
    }, removePeer(sock, peer) {
      delete sock.peers[peer.addr + ":" + peer.port];
    }, handlePeerEvents(sock, peer) {
      var first = true;
      var handleOpen = function() {
        Module["websocket"].emit("open", sock.stream.fd);
        try {
          var queued = peer.dgram_send_queue.shift();
          while (queued) {
            peer.socket.send(queued);
            queued = peer.dgram_send_queue.shift();
          }
        } catch (e) {
          peer.socket.close();
        }
      };
      function handleMessage(data) {
        if (typeof data == "string") {
          var encoder = new TextEncoder();
          data = encoder.encode(data);
        } else {
          assert(data.byteLength !== void 0);
          if (data.byteLength == 0) {
            return;
          }
          data = new Uint8Array(data);
        }
        var wasfirst = first;
        first = false;
        if (wasfirst && data.length === 10 && data[0] === 255 && data[1] === 255 && data[2] === 255 && data[3] === 255 && data[4] === "p".charCodeAt(0) && data[5] === "o".charCodeAt(0) && data[6] === "r".charCodeAt(0) && data[7] === "t".charCodeAt(0)) {
          var newport = data[8] << 8 | data[9];
          SOCKFS.websocket_sock_ops.removePeer(sock, peer);
          peer.port = newport;
          SOCKFS.websocket_sock_ops.addPeer(sock, peer);
          return;
        }
        sock.recv_queue.push({ addr: peer.addr, port: peer.port, data });
        Module["websocket"].emit("message", sock.stream.fd);
      }
      {
        peer.socket.onopen = handleOpen;
        peer.socket.onclose = function() {
          Module["websocket"].emit("close", sock.stream.fd);
        };
        peer.socket.onmessage = function peer_socket_onmessage(event) {
          handleMessage(event.data);
        };
        peer.socket.onerror = function(error) {
          sock.error = 14;
          Module["websocket"].emit("error", [sock.stream.fd, sock.error, "ECONNREFUSED: Connection refused"]);
        };
      }
    }, poll(sock) {
      if (sock.type === 1 && sock.server) {
        return sock.pending.length ? 64 | 1 : 0;
      }
      var mask = 0;
      var dest = sock.type === 1 ? SOCKFS.websocket_sock_ops.getPeer(sock, sock.daddr, sock.dport) : null;
      if (sock.recv_queue.length || !dest || dest && dest.socket.readyState === dest.socket.CLOSING || dest && dest.socket.readyState === dest.socket.CLOSED) {
        mask |= 64 | 1;
      }
      if (!dest || dest && dest.socket.readyState === dest.socket.OPEN) {
        mask |= 4;
      }
      if (dest && dest.socket.readyState === dest.socket.CLOSING || dest && dest.socket.readyState === dest.socket.CLOSED) {
        mask |= 16;
      }
      return mask;
    }, ioctl(sock, request, arg) {
      switch (request) {
        case 21531:
          var bytes = 0;
          if (sock.recv_queue.length) {
            bytes = sock.recv_queue[0].data.length;
          }
          HEAP32[arg >>> 2] = bytes;
          return 0;
        default:
          return 28;
      }
    }, close(sock) {
      if (sock.server) {
        try {
          sock.server.close();
        } catch (e) {
        }
        sock.server = null;
      }
      var peers = Object.keys(sock.peers);
      for (var i2 = 0; i2 < peers.length; i2++) {
        var peer = sock.peers[peers[i2]];
        try {
          peer.socket.close();
        } catch (e) {
        }
        SOCKFS.websocket_sock_ops.removePeer(sock, peer);
      }
      return 0;
    }, bind(sock, addr, port) {
      if (typeof sock.saddr != "undefined" || typeof sock.sport != "undefined") {
        throw new FS.ErrnoError(28);
      }
      sock.saddr = addr;
      sock.sport = port;
      if (sock.type === 2) {
        if (sock.server) {
          sock.server.close();
          sock.server = null;
        }
        try {
          sock.sock_ops.listen(sock, 0);
        } catch (e) {
          if (!(e.name === "ErrnoError")) throw e;
          if (e.errno !== 138) throw e;
        }
      }
    }, connect(sock, addr, port) {
      if (sock.server) {
        throw new FS.ErrnoError(138);
      }
      if (typeof sock.daddr != "undefined" && typeof sock.dport != "undefined") {
        var dest = SOCKFS.websocket_sock_ops.getPeer(sock, sock.daddr, sock.dport);
        if (dest) {
          if (dest.socket.readyState === dest.socket.CONNECTING) {
            throw new FS.ErrnoError(7);
          } else {
            throw new FS.ErrnoError(30);
          }
        }
      }
      var peer = SOCKFS.websocket_sock_ops.createPeer(sock, addr, port);
      sock.daddr = peer.addr;
      sock.dport = peer.port;
      throw new FS.ErrnoError(26);
    }, listen(sock, backlog) {
      {
        throw new FS.ErrnoError(138);
      }
    }, accept(listensock) {
      if (!listensock.server || !listensock.pending.length) {
        throw new FS.ErrnoError(28);
      }
      var newsock = listensock.pending.shift();
      newsock.stream.flags = listensock.stream.flags;
      return newsock;
    }, getname(sock, peer) {
      var addr, port;
      if (peer) {
        if (sock.daddr === void 0 || sock.dport === void 0) {
          throw new FS.ErrnoError(53);
        }
        addr = sock.daddr;
        port = sock.dport;
      } else {
        addr = sock.saddr || 0;
        port = sock.sport || 0;
      }
      return { addr, port };
    }, sendmsg(sock, buffer, offset, length, addr, port) {
      if (sock.type === 2) {
        if (addr === void 0 || port === void 0) {
          addr = sock.daddr;
          port = sock.dport;
        }
        if (addr === void 0 || port === void 0) {
          throw new FS.ErrnoError(17);
        }
      } else {
        addr = sock.daddr;
        port = sock.dport;
      }
      var dest = SOCKFS.websocket_sock_ops.getPeer(sock, addr, port);
      if (sock.type === 1) {
        if (!dest || dest.socket.readyState === dest.socket.CLOSING || dest.socket.readyState === dest.socket.CLOSED) {
          throw new FS.ErrnoError(53);
        } else if (dest.socket.readyState === dest.socket.CONNECTING) {
          throw new FS.ErrnoError(6);
        }
      }
      if (ArrayBuffer.isView(buffer)) {
        offset += buffer.byteOffset;
        buffer = buffer.buffer;
      }
      var data;
      data = buffer.slice(offset, offset + length);
      if (sock.type === 2) {
        if (!dest || dest.socket.readyState !== dest.socket.OPEN) {
          if (!dest || dest.socket.readyState === dest.socket.CLOSING || dest.socket.readyState === dest.socket.CLOSED) {
            dest = SOCKFS.websocket_sock_ops.createPeer(sock, addr, port);
          }
          dest.dgram_send_queue.push(data);
          return length;
        }
      }
      try {
        dest.socket.send(data);
        return length;
      } catch (e) {
        throw new FS.ErrnoError(28);
      }
    }, recvmsg(sock, length) {
      if (sock.type === 1 && sock.server) {
        throw new FS.ErrnoError(53);
      }
      var queued = sock.recv_queue.shift();
      if (!queued) {
        if (sock.type === 1) {
          var dest = SOCKFS.websocket_sock_ops.getPeer(sock, sock.daddr, sock.dport);
          if (!dest) {
            throw new FS.ErrnoError(53);
          }
          if (dest.socket.readyState === dest.socket.CLOSING || dest.socket.readyState === dest.socket.CLOSED) {
            return null;
          }
          throw new FS.ErrnoError(6);
        }
        throw new FS.ErrnoError(6);
      }
      var queuedLength = queued.data.byteLength || queued.data.length;
      var queuedOffset = queued.data.byteOffset || 0;
      var queuedBuffer = queued.data.buffer || queued.data;
      var bytesRead = Math.min(length, queuedLength);
      var res = { buffer: new Uint8Array(queuedBuffer, queuedOffset, bytesRead), addr: queued.addr, port: queued.port };
      if (sock.type === 1 && bytesRead < queuedLength) {
        var bytesRemaining = queuedLength - bytesRead;
        queued.data = new Uint8Array(queuedBuffer, queuedOffset + bytesRead, bytesRemaining);
        sock.recv_queue.unshift(queued);
      }
      return res;
    } } };
    function getSocketFromFD(fd2) {
      var socket = SOCKFS.getSocket(fd2);
      if (!socket) throw new FS.ErrnoError(8);
      return socket;
    }
    var setErrNo = (value) => {
      HEAP32[___errno_location() >>> 2] = value;
      return value;
    };
    var inetPton4 = (str) => {
      var b = str.split(".");
      for (var i2 = 0; i2 < 4; i2++) {
        var tmp = Number(b[i2]);
        if (isNaN(tmp)) return null;
        b[i2] = tmp;
      }
      return (b[0] | b[1] << 8 | b[2] << 16 | b[3] << 24) >>> 0;
    };
    var jstoi_q = (str) => parseInt(str);
    var inetPton6 = (str) => {
      var words;
      var w, offset, z;
      var valid6regx = /^((?=.*::)(?!.*::.+::)(::)?([\dA-F]{1,4}:(:|\b)|){5}|([\dA-F]{1,4}:){6})((([\dA-F]{1,4}((?!\3)::|:\b|$))|(?!\2\3)){2}|(((2[0-4]|1\d|[1-9])?\d|25[0-5])\.?\b){4})$/i;
      var parts = [];
      if (!valid6regx.test(str)) {
        return null;
      }
      if (str === "::") {
        return [0, 0, 0, 0, 0, 0, 0, 0];
      }
      if (str.startsWith("::")) {
        str = str.replace("::", "Z:");
      } else {
        str = str.replace("::", ":Z:");
      }
      if (str.indexOf(".") > 0) {
        str = str.replace(new RegExp("[.]", "g"), ":");
        words = str.split(":");
        words[words.length - 4] = jstoi_q(words[words.length - 4]) + jstoi_q(words[words.length - 3]) * 256;
        words[words.length - 3] = jstoi_q(words[words.length - 2]) + jstoi_q(words[words.length - 1]) * 256;
        words = words.slice(0, words.length - 2);
      } else {
        words = str.split(":");
      }
      offset = 0;
      z = 0;
      for (w = 0; w < words.length; w++) {
        if (typeof words[w] == "string") {
          if (words[w] === "Z") {
            for (z = 0; z < 8 - words.length + 1; z++) {
              parts[w + z] = 0;
            }
            offset = z - 1;
          } else {
            parts[w + offset] = _htons(parseInt(words[w], 16));
          }
        } else {
          parts[w + offset] = words[w];
        }
      }
      return [parts[1] << 16 | parts[0], parts[3] << 16 | parts[2], parts[5] << 16 | parts[4], parts[7] << 16 | parts[6]];
    };
    var writeSockaddr = (sa, family, addr, port, addrlen) => {
      switch (family) {
        case 2:
          addr = inetPton4(addr);
          zeroMemory(sa, 16);
          if (addrlen) {
            HEAP32[addrlen >>> 2] = 16;
          }
          HEAP16[sa >>> 1] = family;
          HEAP32[sa + 4 >>> 2] = addr;
          HEAP16[sa + 2 >>> 1] = _htons(port);
          break;
        case 10:
          addr = inetPton6(addr);
          zeroMemory(sa, 28);
          if (addrlen) {
            HEAP32[addrlen >>> 2] = 28;
          }
          HEAP32[sa >>> 2] = family;
          HEAP32[sa + 8 >>> 2] = addr[0];
          HEAP32[sa + 12 >>> 2] = addr[1];
          HEAP32[sa + 16 >>> 2] = addr[2];
          HEAP32[sa + 20 >>> 2] = addr[3];
          HEAP16[sa + 2 >>> 1] = _htons(port);
          break;
        default:
          return 5;
      }
      return 0;
    };
    var DNS = { address_map: { id: 1, addrs: {}, names: {} }, lookup_name: (name) => {
      var res = inetPton4(name);
      if (res !== null) {
        return name;
      }
      res = inetPton6(name);
      if (res !== null) {
        return name;
      }
      var addr;
      if (DNS.address_map.addrs[name]) {
        addr = DNS.address_map.addrs[name];
      } else {
        var id = DNS.address_map.id++;
        assert(id < 65535, "exceeded max address mappings of 65535");
        addr = "172.29." + (id & 255) + "." + (id & 65280);
        DNS.address_map.names[addr] = name;
        DNS.address_map.addrs[name] = addr;
      }
      return addr;
    }, lookup_addr: (addr) => {
      if (DNS.address_map.names[addr]) {
        return DNS.address_map.names[addr];
      }
      return null;
    } };
    function ___syscall_accept4(fd2, addr, addrlen, flags, d1, d2) {
      addr >>>= 0;
      addrlen >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        var newsock = sock.sock_ops.accept(sock);
        if (addr) {
          var errno = writeSockaddr(addr, newsock.family, DNS.lookup_name(newsock.daddr), newsock.dport, addrlen);
          assert(!errno);
        }
        return newsock.stream.fd;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    var inetNtop4 = (addr) => (addr & 255) + "." + (addr >> 8 & 255) + "." + (addr >> 16 & 255) + "." + (addr >> 24 & 255);
    var inetNtop6 = (ints) => {
      var str = "";
      var word = 0;
      var longest = 0;
      var lastzero = 0;
      var zstart = 0;
      var len2 = 0;
      var i2 = 0;
      var parts = [ints[0] & 65535, ints[0] >> 16, ints[1] & 65535, ints[1] >> 16, ints[2] & 65535, ints[2] >> 16, ints[3] & 65535, ints[3] >> 16];
      var hasipv4 = true;
      var v4part = "";
      for (i2 = 0; i2 < 5; i2++) {
        if (parts[i2] !== 0) {
          hasipv4 = false;
          break;
        }
      }
      if (hasipv4) {
        v4part = inetNtop4(parts[6] | parts[7] << 16);
        if (parts[5] === -1) {
          str = "::ffff:";
          str += v4part;
          return str;
        }
        if (parts[5] === 0) {
          str = "::";
          if (v4part === "0.0.0.0") v4part = "";
          if (v4part === "0.0.0.1") v4part = "1";
          str += v4part;
          return str;
        }
      }
      for (word = 0; word < 8; word++) {
        if (parts[word] === 0) {
          if (word - lastzero > 1) {
            len2 = 0;
          }
          lastzero = word;
          len2++;
        }
        if (len2 > longest) {
          longest = len2;
          zstart = word - longest + 1;
        }
      }
      for (word = 0; word < 8; word++) {
        if (longest > 1) {
          if (parts[word] === 0 && word >= zstart && word < zstart + longest) {
            if (word === zstart) {
              str += ":";
              if (zstart === 0) str += ":";
            }
            continue;
          }
        }
        str += Number(_ntohs(parts[word] & 65535)).toString(16);
        str += word < 7 ? ":" : "";
      }
      return str;
    };
    var readSockaddr = (sa, salen) => {
      var family = HEAP16[sa >>> 1];
      var port = _ntohs(HEAPU16[sa + 2 >>> 1]);
      var addr;
      switch (family) {
        case 2:
          if (salen !== 16) {
            return { errno: 28 };
          }
          addr = HEAP32[sa + 4 >>> 2];
          addr = inetNtop4(addr);
          break;
        case 10:
          if (salen !== 28) {
            return { errno: 28 };
          }
          addr = [HEAP32[sa + 8 >>> 2], HEAP32[sa + 12 >>> 2], HEAP32[sa + 16 >>> 2], HEAP32[sa + 20 >>> 2]];
          addr = inetNtop6(addr);
          break;
        default:
          return { errno: 5 };
      }
      return { family, addr, port };
    };
    function getSocketAddress(addrp, addrlen, allowNull) {
      if (allowNull && addrp === 0) return null;
      var info = readSockaddr(addrp, addrlen);
      if (info.errno) throw new FS.ErrnoError(info.errno);
      info.addr = DNS.lookup_addr(info.addr) || info.addr;
      return info;
    }
    function ___syscall_bind(fd2, addr, addrlen, d1, d2, d3) {
      addr >>>= 0;
      addrlen >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        var info = getSocketAddress(addr, addrlen);
        sock.sock_ops.bind(sock, info.addr, info.port);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_chdir(path) {
      path >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        FS.chdir(path);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_chmod(path, mode) {
      path >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        FS.chmod(path, mode);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_connect(fd2, addr, addrlen, d1, d2, d3) {
      addr >>>= 0;
      addrlen >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        var info = getSocketAddress(addr, addrlen);
        sock.sock_ops.connect(sock, info.addr, info.port);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_dup(fd2) {
      try {
        var old = SYSCALLS.getStreamFromFD(fd2);
        return FS.createStream(old).fd;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_dup3(fd2, newfd, flags) {
      try {
        var old = SYSCALLS.getStreamFromFD(fd2);
        assert(!flags);
        if (old.fd === newfd) return -28;
        var existing = FS.getStream(newfd);
        if (existing) FS.close(existing);
        return FS.createStream(old, newfd).fd;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_faccessat(dirfd, path, amode, flags) {
      path >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        assert(flags === 0);
        path = SYSCALLS.calculateAt(dirfd, path);
        if (amode & ~7) {
          return -28;
        }
        var lookup = FS.lookupPath(path, { follow: true });
        var node = lookup.node;
        if (!node) {
          return -44;
        }
        var perms = "";
        if (amode & 4) perms += "r";
        if (amode & 2) perms += "w";
        if (amode & 1) perms += "x";
        if (perms && FS.nodePermissions(node, perms)) {
          return -2;
        }
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_fallocate(fd2, mode, offset_low, offset_high, len_low, len_high) {
      var offset = convertI32PairToI53Checked(offset_low, offset_high);
      var len2 = convertI32PairToI53Checked(len_low, len_high);
      try {
        if (isNaN(offset)) return 61;
        var stream = SYSCALLS.getStreamFromFD(fd2);
        assert(mode === 0);
        FS.allocate(stream, offset, len2);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_fchmod(fd2, mode) {
      try {
        FS.fchmod(fd2, mode);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_fchown32(fd2, owner, group) {
      try {
        FS.fchown(fd2, owner, group);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_fchownat(dirfd, path, owner, group, flags) {
      path >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        var nofollow = flags & 256;
        flags = flags & ~256;
        assert(flags === 0);
        path = SYSCALLS.calculateAt(dirfd, path);
        (nofollow ? FS.lchown : FS.chown)(path, owner, group);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_fcntl64(fd2, cmd, varargs) {
      varargs >>>= 0;
      SYSCALLS.varargs = varargs;
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        switch (cmd) {
          case 0: {
            var arg = SYSCALLS.get();
            if (arg < 0) {
              return -28;
            }
            var newStream;
            newStream = FS.createStream(stream, arg);
            return newStream.fd;
          }
          case 1:
          case 2:
            return 0;
          case 3:
            return stream.flags;
          case 4: {
            var arg = SYSCALLS.get();
            stream.flags |= arg;
            return 0;
          }
          case 5: {
            var arg = SYSCALLS.get();
            var offset = 0;
            HEAP16[arg + offset >>> 1] = 2;
            return 0;
          }
          case 6:
          case 7:
            return 0;
          case 16:
          case 8:
            return -28;
          case 9:
            setErrNo(28);
            return -1;
          default: {
            return -28;
          }
        }
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_fdatasync(fd2) {
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_fstat64(fd2, buf) {
      buf >>>= 0;
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        return SYSCALLS.doStat(FS.stat, stream.path, buf);
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_ftruncate64(fd2, length_low, length_high) {
      var length = convertI32PairToI53Checked(length_low, length_high);
      try {
        if (isNaN(length)) return 61;
        FS.ftruncate(fd2, length);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    var stringToUTF8 = (str, outPtr, maxBytesToWrite) => {
      assert(typeof maxBytesToWrite == "number", "stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!");
      return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
    };
    function ___syscall_getcwd(buf, size) {
      buf >>>= 0;
      size >>>= 0;
      try {
        if (size === 0) return -28;
        var cwd = FS.cwd();
        var cwdLengthInBytes = lengthBytesUTF8(cwd) + 1;
        if (size < cwdLengthInBytes) return -68;
        stringToUTF8(cwd, buf, size);
        return cwdLengthInBytes;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_getdents64(fd2, dirp, count) {
      dirp >>>= 0;
      count >>>= 0;
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        if (!stream.getdents) {
          stream.getdents = FS.readdir(stream.path);
        }
        var struct_size = 280;
        var pos = 0;
        var off = FS.llseek(stream, 0, 1);
        var idx = Math.floor(off / struct_size);
        while (idx < stream.getdents.length && pos + struct_size <= count) {
          var id;
          var type;
          var name = stream.getdents[idx];
          if (name === ".") {
            id = stream.node.id;
            type = 4;
          } else if (name === "..") {
            var lookup = FS.lookupPath(stream.path, { parent: true });
            id = lookup.node.id;
            type = 4;
          } else {
            var child = FS.lookupNode(stream.node, name);
            id = child.id;
            type = FS.isChrdev(child.mode) ? 2 : FS.isDir(child.mode) ? 4 : FS.isLink(child.mode) ? 10 : 8;
          }
          assert(id);
          tempI64 = [id >>> 0, (tempDouble = id, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[dirp + pos >>> 2] = tempI64[0], HEAP32[dirp + pos + 4 >>> 2] = tempI64[1];
          tempI64 = [(idx + 1) * struct_size >>> 0, (tempDouble = (idx + 1) * struct_size, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[dirp + pos + 8 >>> 2] = tempI64[0], HEAP32[dirp + pos + 12 >>> 2] = tempI64[1];
          HEAP16[dirp + pos + 16 >>> 1] = 280;
          HEAP8[dirp + pos + 18 >>> 0] = type;
          stringToUTF8(name, dirp + pos + 19, 256);
          pos += struct_size;
          idx += 1;
        }
        FS.llseek(stream, idx * struct_size, 0);
        return pos;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_getpeername(fd2, addr, addrlen, d1, d2, d3) {
      addr >>>= 0;
      addrlen >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        if (!sock.daddr) {
          return -53;
        }
        var errno = writeSockaddr(addr, sock.family, DNS.lookup_name(sock.daddr), sock.dport, addrlen);
        assert(!errno);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_getsockname(fd2, addr, addrlen, d1, d2, d3) {
      addr >>>= 0;
      addrlen >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        var errno = writeSockaddr(addr, sock.family, DNS.lookup_name(sock.saddr || "0.0.0.0"), sock.sport, addrlen);
        assert(!errno);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_getsockopt(fd2, level, optname, optval, optlen, d1) {
      optval >>>= 0;
      optlen >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        if (level === 1) {
          if (optname === 4) {
            HEAP32[optval >>> 2] = sock.error;
            HEAP32[optlen >>> 2] = 4;
            sock.error = null;
            return 0;
          }
        }
        return -50;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_ioctl(fd2, op, varargs) {
      varargs >>>= 0;
      SYSCALLS.varargs = varargs;
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        switch (op) {
          case 21509: {
            if (!stream.tty) return -59;
            return 0;
          }
          case 21505: {
            if (!stream.tty) return -59;
            if (stream.tty.ops.ioctl_tcgets) {
              var termios = stream.tty.ops.ioctl_tcgets(stream);
              var argp = SYSCALLS.get();
              HEAP32[argp >>> 2] = termios.c_iflag || 0;
              HEAP32[argp + 4 >>> 2] = termios.c_oflag || 0;
              HEAP32[argp + 8 >>> 2] = termios.c_cflag || 0;
              HEAP32[argp + 12 >>> 2] = termios.c_lflag || 0;
              for (var i2 = 0; i2 < 32; i2++) {
                HEAP8[argp + i2 + 17 >>> 0] = termios.c_cc[i2] || 0;
              }
              return 0;
            }
            return 0;
          }
          case 21510:
          case 21511:
          case 21512: {
            if (!stream.tty) return -59;
            return 0;
          }
          case 21506:
          case 21507:
          case 21508: {
            if (!stream.tty) return -59;
            if (stream.tty.ops.ioctl_tcsets) {
              var argp = SYSCALLS.get();
              var c_iflag = HEAP32[argp >>> 2];
              var c_oflag = HEAP32[argp + 4 >>> 2];
              var c_cflag = HEAP32[argp + 8 >>> 2];
              var c_lflag = HEAP32[argp + 12 >>> 2];
              var c_cc = [];
              for (var i2 = 0; i2 < 32; i2++) {
                c_cc.push(HEAP8[argp + i2 + 17 >>> 0]);
              }
              return stream.tty.ops.ioctl_tcsets(stream.tty, op, { c_iflag, c_oflag, c_cflag, c_lflag, c_cc });
            }
            return 0;
          }
          case 21519: {
            if (!stream.tty) return -59;
            var argp = SYSCALLS.get();
            HEAP32[argp >>> 2] = 0;
            return 0;
          }
          case 21520: {
            if (!stream.tty) return -59;
            return -28;
          }
          case 21531: {
            var argp = SYSCALLS.get();
            return FS.ioctl(stream, op, argp);
          }
          case 21523: {
            if (!stream.tty) return -59;
            if (stream.tty.ops.ioctl_tiocgwinsz) {
              var winsize = stream.tty.ops.ioctl_tiocgwinsz(stream.tty);
              var argp = SYSCALLS.get();
              HEAP16[argp >>> 1] = winsize[0];
              HEAP16[argp + 2 >>> 1] = winsize[1];
            }
            return 0;
          }
          case 21524: {
            if (!stream.tty) return -59;
            return 0;
          }
          case 21515: {
            if (!stream.tty) return -59;
            return 0;
          }
          default:
            return -28;
        }
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_listen(fd2, backlog) {
      try {
        var sock = getSocketFromFD(fd2);
        sock.sock_ops.listen(sock, backlog);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_lstat64(path, buf) {
      path >>>= 0;
      buf >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        return SYSCALLS.doStat(FS.lstat, path, buf);
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_mkdirat(dirfd, path, mode) {
      path >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        path = SYSCALLS.calculateAt(dirfd, path);
        path = PATH.normalize(path);
        if (path[path.length - 1] === "/") path = path.substr(0, path.length - 1);
        FS.mkdir(path, mode, 0);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_newfstatat(dirfd, path, buf, flags) {
      path >>>= 0;
      buf >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        var nofollow = flags & 256;
        var allowEmpty = flags & 4096;
        flags = flags & ~6400;
        assert(!flags, `unknown flags in __syscall_newfstatat: ${flags}`);
        path = SYSCALLS.calculateAt(dirfd, path, allowEmpty);
        return SYSCALLS.doStat(nofollow ? FS.lstat : FS.stat, path, buf);
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_openat(dirfd, path, flags, varargs) {
      path >>>= 0;
      varargs >>>= 0;
      SYSCALLS.varargs = varargs;
      try {
        path = SYSCALLS.getStr(path);
        path = SYSCALLS.calculateAt(dirfd, path);
        var mode = varargs ? SYSCALLS.get() : 0;
        return FS.open(path, flags, mode).fd;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    var PIPEFS = { BUCKET_BUFFER_SIZE: 8192, mount(mount) {
      return FS.createNode(null, "/", 16384 | 511, 0);
    }, createPipe() {
      var pipe = { buckets: [], refcnt: 2 };
      pipe.buckets.push({ buffer: new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE), offset: 0, roffset: 0 });
      var rName = PIPEFS.nextname();
      var wName = PIPEFS.nextname();
      var rNode = FS.createNode(PIPEFS.root, rName, 4096, 0);
      var wNode = FS.createNode(PIPEFS.root, wName, 4096, 0);
      rNode.pipe = pipe;
      wNode.pipe = pipe;
      var readableStream = FS.createStream({ path: rName, node: rNode, flags: 0, seekable: false, stream_ops: PIPEFS.stream_ops });
      rNode.stream = readableStream;
      var writableStream = FS.createStream({ path: wName, node: wNode, flags: 1, seekable: false, stream_ops: PIPEFS.stream_ops });
      wNode.stream = writableStream;
      return { readable_fd: readableStream.fd, writable_fd: writableStream.fd };
    }, stream_ops: { poll(stream) {
      var pipe = stream.node.pipe;
      if ((stream.flags & 2097155) === 1) {
        return 256 | 4;
      }
      if (pipe.buckets.length > 0) {
        for (var i2 = 0; i2 < pipe.buckets.length; i2++) {
          var bucket = pipe.buckets[i2];
          if (bucket.offset - bucket.roffset > 0) {
            return 64 | 1;
          }
        }
      }
      return 0;
    }, ioctl(stream, request, varargs) {
      return 28;
    }, fsync(stream) {
      return 28;
    }, read(stream, buffer, offset, length, position) {
      var pipe = stream.node.pipe;
      var currentLength = 0;
      for (var i2 = 0; i2 < pipe.buckets.length; i2++) {
        var bucket = pipe.buckets[i2];
        currentLength += bucket.offset - bucket.roffset;
      }
      assert(buffer instanceof ArrayBuffer || ArrayBuffer.isView(buffer));
      var data = buffer.subarray(offset, offset + length);
      if (length <= 0) {
        return 0;
      }
      if (currentLength == 0) {
        throw new FS.ErrnoError(6);
      }
      var toRead = Math.min(currentLength, length);
      var totalRead = toRead;
      var toRemove = 0;
      for (var i2 = 0; i2 < pipe.buckets.length; i2++) {
        var currBucket = pipe.buckets[i2];
        var bucketSize = currBucket.offset - currBucket.roffset;
        if (toRead <= bucketSize) {
          var tmpSlice = currBucket.buffer.subarray(currBucket.roffset, currBucket.offset);
          if (toRead < bucketSize) {
            tmpSlice = tmpSlice.subarray(0, toRead);
            currBucket.roffset += toRead;
          } else {
            toRemove++;
          }
          data.set(tmpSlice);
          break;
        } else {
          var tmpSlice = currBucket.buffer.subarray(currBucket.roffset, currBucket.offset);
          data.set(tmpSlice);
          data = data.subarray(tmpSlice.byteLength);
          toRead -= tmpSlice.byteLength;
          toRemove++;
        }
      }
      if (toRemove && toRemove == pipe.buckets.length) {
        toRemove--;
        pipe.buckets[toRemove].offset = 0;
        pipe.buckets[toRemove].roffset = 0;
      }
      pipe.buckets.splice(0, toRemove);
      return totalRead;
    }, write(stream, buffer, offset, length, position) {
      var pipe = stream.node.pipe;
      assert(buffer instanceof ArrayBuffer || ArrayBuffer.isView(buffer));
      var data = buffer.subarray(offset, offset + length);
      var dataLen = data.byteLength;
      if (dataLen <= 0) {
        return 0;
      }
      var currBucket = null;
      if (pipe.buckets.length == 0) {
        currBucket = { buffer: new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE), offset: 0, roffset: 0 };
        pipe.buckets.push(currBucket);
      } else {
        currBucket = pipe.buckets[pipe.buckets.length - 1];
      }
      assert(currBucket.offset <= PIPEFS.BUCKET_BUFFER_SIZE);
      var freeBytesInCurrBuffer = PIPEFS.BUCKET_BUFFER_SIZE - currBucket.offset;
      if (freeBytesInCurrBuffer >= dataLen) {
        currBucket.buffer.set(data, currBucket.offset);
        currBucket.offset += dataLen;
        return dataLen;
      } else if (freeBytesInCurrBuffer > 0) {
        currBucket.buffer.set(data.subarray(0, freeBytesInCurrBuffer), currBucket.offset);
        currBucket.offset += freeBytesInCurrBuffer;
        data = data.subarray(freeBytesInCurrBuffer, data.byteLength);
      }
      var numBuckets = data.byteLength / PIPEFS.BUCKET_BUFFER_SIZE | 0;
      var remElements = data.byteLength % PIPEFS.BUCKET_BUFFER_SIZE;
      for (var i2 = 0; i2 < numBuckets; i2++) {
        var newBucket = { buffer: new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE), offset: PIPEFS.BUCKET_BUFFER_SIZE, roffset: 0 };
        pipe.buckets.push(newBucket);
        newBucket.buffer.set(data.subarray(0, PIPEFS.BUCKET_BUFFER_SIZE));
        data = data.subarray(PIPEFS.BUCKET_BUFFER_SIZE, data.byteLength);
      }
      if (remElements > 0) {
        var newBucket = { buffer: new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE), offset: data.byteLength, roffset: 0 };
        pipe.buckets.push(newBucket);
        newBucket.buffer.set(data);
      }
      return dataLen;
    }, close(stream) {
      var pipe = stream.node.pipe;
      pipe.refcnt--;
      if (pipe.refcnt === 0) {
        pipe.buckets = null;
      }
    } }, nextname() {
      if (!PIPEFS.nextname.current) {
        PIPEFS.nextname.current = 0;
      }
      return "pipe[" + PIPEFS.nextname.current++ + "]";
    } };
    function ___syscall_pipe(fdPtr) {
      fdPtr >>>= 0;
      try {
        if (fdPtr == 0) {
          throw new FS.ErrnoError(21);
        }
        var res = PIPEFS.createPipe();
        HEAP32[fdPtr >>> 2] = res.readable_fd;
        HEAP32[fdPtr + 4 >>> 2] = res.writable_fd;
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_poll(fds, nfds, timeout) {
      fds >>>= 0;
      try {
        var nonzero = 0;
        for (var i2 = 0; i2 < nfds; i2++) {
          var pollfd = fds + 8 * i2;
          var fd2 = HEAP32[pollfd >>> 2];
          var events = HEAP16[pollfd + 4 >>> 1];
          var mask = 32;
          var stream = FS.getStream(fd2);
          if (stream) {
            mask = SYSCALLS.DEFAULT_POLLMASK;
            if (stream.stream_ops.poll) {
              mask = stream.stream_ops.poll(stream, -1);
            }
          }
          mask &= events | 8 | 16;
          if (mask) nonzero++;
          HEAP16[pollfd + 6 >>> 1] = mask;
        }
        return nonzero;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_readlinkat(dirfd, path, buf, bufsize) {
      path >>>= 0;
      buf >>>= 0;
      bufsize >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        path = SYSCALLS.calculateAt(dirfd, path);
        if (bufsize <= 0) return -28;
        var ret = FS.readlink(path);
        var len2 = Math.min(bufsize, lengthBytesUTF8(ret));
        var endChar = HEAP8[buf + len2 >>> 0];
        stringToUTF8(ret, buf, bufsize + 1);
        HEAP8[buf + len2 >>> 0] = endChar;
        return len2;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_recvfrom(fd2, buf, len2, flags, addr, addrlen) {
      buf >>>= 0;
      len2 >>>= 0;
      addr >>>= 0;
      addrlen >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        var msg = sock.sock_ops.recvmsg(sock, len2);
        if (!msg) return 0;
        if (addr) {
          var errno = writeSockaddr(addr, sock.family, DNS.lookup_name(msg.addr), msg.port, addrlen);
          assert(!errno);
        }
        HEAPU8.set(msg.buffer, buf >>> 0);
        return msg.buffer.byteLength;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_renameat(olddirfd, oldpath, newdirfd, newpath) {
      oldpath >>>= 0;
      newpath >>>= 0;
      try {
        oldpath = SYSCALLS.getStr(oldpath);
        newpath = SYSCALLS.getStr(newpath);
        oldpath = SYSCALLS.calculateAt(olddirfd, oldpath);
        newpath = SYSCALLS.calculateAt(newdirfd, newpath);
        FS.rename(oldpath, newpath);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_rmdir(path) {
      path >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        FS.rmdir(path);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_sendto(fd2, message, length, flags, addr, addr_len) {
      message >>>= 0;
      length >>>= 0;
      addr >>>= 0;
      addr_len >>>= 0;
      try {
        var sock = getSocketFromFD(fd2);
        var dest = getSocketAddress(addr, addr_len, true);
        if (!dest) {
          return FS.write(sock.stream, HEAP8, message, length);
        }
        return sock.sock_ops.sendmsg(sock, HEAP8, message, length, dest.addr, dest.port);
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_socket(domain, type, protocol) {
      try {
        var sock = SOCKFS.createSocket(domain, type, protocol);
        assert(sock.stream.fd < 64);
        return sock.stream.fd;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_stat64(path, buf) {
      path >>>= 0;
      buf >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        return SYSCALLS.doStat(FS.stat, path, buf);
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_statfs64(path, size, buf) {
      path >>>= 0;
      size >>>= 0;
      buf >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        assert(size === 64);
        HEAP32[buf + 4 >>> 2] = 4096;
        HEAP32[buf + 40 >>> 2] = 4096;
        HEAP32[buf + 8 >>> 2] = 1e6;
        HEAP32[buf + 12 >>> 2] = 5e5;
        HEAP32[buf + 16 >>> 2] = 5e5;
        HEAP32[buf + 20 >>> 2] = FS.nextInode;
        HEAP32[buf + 24 >>> 2] = 1e6;
        HEAP32[buf + 28 >>> 2] = 42;
        HEAP32[buf + 44 >>> 2] = 2;
        HEAP32[buf + 36 >>> 2] = 255;
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_symlink(target, linkpath) {
      target >>>= 0;
      linkpath >>>= 0;
      try {
        target = SYSCALLS.getStr(target);
        linkpath = SYSCALLS.getStr(linkpath);
        FS.symlink(target, linkpath);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function ___syscall_unlinkat(dirfd, path, flags) {
      path >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        path = SYSCALLS.calculateAt(dirfd, path);
        if (flags === 0) {
          FS.unlink(path);
        } else if (flags === 512) {
          FS.rmdir(path);
        } else {
          abort("Invalid flags passed to unlinkat");
        }
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function readI53FromI64(ptr) {
      return HEAPU32[ptr >>> 2] + HEAP32[ptr + 4 >>> 2] * 4294967296;
    }
    function ___syscall_utimensat(dirfd, path, times, flags) {
      path >>>= 0;
      times >>>= 0;
      try {
        path = SYSCALLS.getStr(path);
        assert(flags === 0);
        path = SYSCALLS.calculateAt(dirfd, path, true);
        if (!times) {
          var atime = Date.now();
          var mtime = atime;
        } else {
          var seconds = readI53FromI64(times);
          var nanoseconds = HEAP32[times + 8 >>> 2];
          atime = seconds * 1e3 + nanoseconds / (1e3 * 1e3);
          times += 16;
          seconds = readI53FromI64(times);
          nanoseconds = HEAP32[times + 8 >>> 2];
          mtime = seconds * 1e3 + nanoseconds / (1e3 * 1e3);
        }
        FS.utime(path, atime, mtime);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    var nowIsMonotonic = true;
    var __emscripten_get_now_is_monotonic = () => nowIsMonotonic;
    var __emscripten_throw_longjmp = () => {
      throw Infinity;
    };
    function __gmtime_js(time_low, time_high, tmPtr) {
      var time = convertI32PairToI53Checked(time_low, time_high);
      tmPtr >>>= 0;
      var date = new Date(time * 1e3);
      HEAP32[tmPtr >>> 2] = date.getUTCSeconds();
      HEAP32[tmPtr + 4 >>> 2] = date.getUTCMinutes();
      HEAP32[tmPtr + 8 >>> 2] = date.getUTCHours();
      HEAP32[tmPtr + 12 >>> 2] = date.getUTCDate();
      HEAP32[tmPtr + 16 >>> 2] = date.getUTCMonth();
      HEAP32[tmPtr + 20 >>> 2] = date.getUTCFullYear() - 1900;
      HEAP32[tmPtr + 24 >>> 2] = date.getUTCDay();
      var start = Date.UTC(date.getUTCFullYear(), 0, 1, 0, 0, 0, 0);
      var yday = (date.getTime() - start) / (1e3 * 60 * 60 * 24) | 0;
      HEAP32[tmPtr + 28 >>> 2] = yday;
    }
    var isLeapYear = (year) => year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    var MONTH_DAYS_LEAP_CUMULATIVE = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];
    var MONTH_DAYS_REGULAR_CUMULATIVE = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    var ydayFromDate = (date) => {
      var leap = isLeapYear(date.getFullYear());
      var monthDaysCumulative = leap ? MONTH_DAYS_LEAP_CUMULATIVE : MONTH_DAYS_REGULAR_CUMULATIVE;
      var yday = monthDaysCumulative[date.getMonth()] + date.getDate() - 1;
      return yday;
    };
    function __localtime_js(time_low, time_high, tmPtr) {
      var time = convertI32PairToI53Checked(time_low, time_high);
      tmPtr >>>= 0;
      var date = new Date(time * 1e3);
      HEAP32[tmPtr >>> 2] = date.getSeconds();
      HEAP32[tmPtr + 4 >>> 2] = date.getMinutes();
      HEAP32[tmPtr + 8 >>> 2] = date.getHours();
      HEAP32[tmPtr + 12 >>> 2] = date.getDate();
      HEAP32[tmPtr + 16 >>> 2] = date.getMonth();
      HEAP32[tmPtr + 20 >>> 2] = date.getFullYear() - 1900;
      HEAP32[tmPtr + 24 >>> 2] = date.getDay();
      var yday = ydayFromDate(date) | 0;
      HEAP32[tmPtr + 28 >>> 2] = yday;
      HEAP32[tmPtr + 36 >>> 2] = -(date.getTimezoneOffset() * 60);
      var start = new Date(date.getFullYear(), 0, 1);
      var summerOffset = new Date(date.getFullYear(), 6, 1).getTimezoneOffset();
      var winterOffset = start.getTimezoneOffset();
      var dst = (summerOffset != winterOffset && date.getTimezoneOffset() == Math.min(winterOffset, summerOffset)) | 0;
      HEAP32[tmPtr + 32 >>> 2] = dst;
    }
    var __mktime_js = function(tmPtr) {
      tmPtr >>>= 0;
      var ret = (() => {
        var date = new Date(HEAP32[tmPtr + 20 >>> 2] + 1900, HEAP32[tmPtr + 16 >>> 2], HEAP32[tmPtr + 12 >>> 2], HEAP32[tmPtr + 8 >>> 2], HEAP32[tmPtr + 4 >>> 2], HEAP32[tmPtr >>> 2], 0);
        var dst = HEAP32[tmPtr + 32 >>> 2];
        var guessedOffset = date.getTimezoneOffset();
        var start = new Date(date.getFullYear(), 0, 1);
        var summerOffset = new Date(date.getFullYear(), 6, 1).getTimezoneOffset();
        var winterOffset = start.getTimezoneOffset();
        var dstOffset = Math.min(winterOffset, summerOffset);
        if (dst < 0) {
          HEAP32[tmPtr + 32 >>> 2] = Number(summerOffset != winterOffset && dstOffset == guessedOffset);
        } else if (dst > 0 != (dstOffset == guessedOffset)) {
          var nonDstOffset = Math.max(winterOffset, summerOffset);
          var trueOffset = dst > 0 ? dstOffset : nonDstOffset;
          date.setTime(date.getTime() + (trueOffset - guessedOffset) * 6e4);
        }
        HEAP32[tmPtr + 24 >>> 2] = date.getDay();
        var yday = ydayFromDate(date) | 0;
        HEAP32[tmPtr + 28 >>> 2] = yday;
        HEAP32[tmPtr >>> 2] = date.getSeconds();
        HEAP32[tmPtr + 4 >>> 2] = date.getMinutes();
        HEAP32[tmPtr + 8 >>> 2] = date.getHours();
        HEAP32[tmPtr + 12 >>> 2] = date.getDate();
        HEAP32[tmPtr + 16 >>> 2] = date.getMonth();
        HEAP32[tmPtr + 20 >>> 2] = date.getYear();
        return date.getTime() / 1e3;
      })();
      return setTempRet0((tempDouble = ret, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)), ret >>> 0;
    };
    function __mmap_js(len2, prot, flags, fd2, offset_low, offset_high, allocated, addr) {
      len2 >>>= 0;
      var offset = convertI32PairToI53Checked(offset_low, offset_high);
      allocated >>>= 0;
      addr >>>= 0;
      try {
        if (isNaN(offset)) return 61;
        var stream = SYSCALLS.getStreamFromFD(fd2);
        var res = FS.mmap(stream, len2, offset, prot, flags);
        var ptr = res.ptr;
        HEAP32[allocated >>> 2] = res.allocated;
        HEAPU32[addr >>> 2] = ptr;
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    function __munmap_js(addr, len2, prot, flags, fd2, offset_low, offset_high) {
      addr >>>= 0;
      len2 >>>= 0;
      var offset = convertI32PairToI53Checked(offset_low, offset_high);
      try {
        if (isNaN(offset)) return 61;
        var stream = SYSCALLS.getStreamFromFD(fd2);
        if (prot & 2) {
          SYSCALLS.doMsync(addr, stream, len2, flags, offset);
        }
        FS.munmap(stream);
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return -e.errno;
      }
    }
    var timers = {};
    var handleException = (e) => {
      if (e instanceof ExitStatus || e == "unwind") {
        return EXITSTATUS;
      }
      checkStackCookie();
      if (e instanceof WebAssembly.RuntimeError) {
        if (_emscripten_stack_get_current() <= 0) {
          err("Stack overflow detected.  You can try increasing -sSTACK_SIZE (currently set to 65536)");
        }
      }
      quit_(1, e);
    };
    var _proc_exit = (code) => {
      EXITSTATUS = code;
      if (!keepRuntimeAlive()) {
        if (Module["onExit"]) Module["onExit"](code);
        ABORT = true;
      }
      quit_(code, new ExitStatus(code));
    };
    var exitJS = (status, implicit) => {
      EXITSTATUS = status;
      if (!keepRuntimeAlive()) {
        exitRuntime();
      }
      if (keepRuntimeAlive() && !implicit) {
        var msg = `program exited (with status: ${status}), but keepRuntimeAlive() is set (counter=${runtimeKeepaliveCounter}) due to an async operation, so halting execution but not exiting the runtime or preventing further async execution (you can use emscripten_force_exit, if you want to force a true shutdown)`;
        readyPromiseReject(msg);
        err(msg);
      }
      _proc_exit(status);
    };
    var _exit = exitJS;
    var maybeExit = () => {
      if (runtimeExited) {
        return;
      }
      if (!keepRuntimeAlive()) {
        try {
          _exit(EXITSTATUS);
        } catch (e) {
          handleException(e);
        }
      }
    };
    var callUserCallback = (func) => {
      if (runtimeExited || ABORT) {
        err("user callback triggered after runtime exited or application aborted.  Ignoring.");
        return;
      }
      try {
        func();
        maybeExit();
      } catch (e) {
        handleException(e);
      }
    };
    var _emscripten_get_now;
    _emscripten_get_now = () => performance.now();
    var __setitimer_js = (which, timeout_ms) => {
      if (timers[which]) {
        clearTimeout(timers[which].id);
        delete timers[which];
      }
      if (!timeout_ms) return 0;
      var id = setTimeout(() => {
        assert(which in timers);
        delete timers[which];
        callUserCallback(() => __emscripten_timeout(which, _emscripten_get_now()));
      }, timeout_ms);
      timers[which] = { id, timeout_ms };
      return 0;
    };
    var stringToNewUTF8 = (str) => {
      var size = lengthBytesUTF8(str) + 1;
      var ret = _malloc(size);
      if (ret) stringToUTF8(str, ret, size);
      return ret;
    };
    function __tzset_js(timezone, daylight, tzname) {
      timezone >>>= 0;
      daylight >>>= 0;
      tzname >>>= 0;
      var currentYear = (/* @__PURE__ */ new Date()).getFullYear();
      var winter = new Date(currentYear, 0, 1);
      var summer = new Date(currentYear, 6, 1);
      var winterOffset = winter.getTimezoneOffset();
      var summerOffset = summer.getTimezoneOffset();
      var stdTimezoneOffset = Math.max(winterOffset, summerOffset);
      HEAPU32[timezone >>> 2] = stdTimezoneOffset * 60;
      HEAP32[daylight >>> 2] = Number(winterOffset != summerOffset);
      function extractZone(date) {
        var match = date.toTimeString().match(/\(([A-Za-z ]+)\)$/);
        return match ? match[1] : "GMT";
      }
      var winterName = extractZone(winter);
      var summerName = extractZone(summer);
      var winterNamePtr = stringToNewUTF8(winterName);
      var summerNamePtr = stringToNewUTF8(summerName);
      if (summerOffset < winterOffset) {
        HEAPU32[tzname >>> 2] = winterNamePtr;
        HEAPU32[tzname + 4 >>> 2] = summerNamePtr;
      } else {
        HEAPU32[tzname >>> 2] = summerNamePtr;
        HEAPU32[tzname + 4 >>> 2] = winterNamePtr;
      }
    }
    var _abort = () => {
      abort("native code called abort()");
    };
    var readEmAsmArgsArray = [];
    var readEmAsmArgs = (sigPtr, buf) => {
      assert(Array.isArray(readEmAsmArgsArray));
      assert(buf % 16 == 0);
      readEmAsmArgsArray.length = 0;
      var ch;
      buf >>= 2;
      while (ch = HEAPU8[sigPtr++ >>> 0]) {
        var chr = String.fromCharCode(ch);
        var validChars = ["d", "f", "i"];
        assert(validChars.includes(chr), `Invalid character ${ch}("${chr}") in readEmAsmArgs! Use only [${validChars}], and do not specify "v" for void return argument.`);
        buf += ch != 105 & buf;
        readEmAsmArgsArray.push(ch == 105 ? HEAP32[buf >>> 0] : HEAPF64[buf++ >>> 1]);
        ++buf;
      }
      return readEmAsmArgsArray;
    };
    var runEmAsmFunction = (code, sigPtr, argbuf) => {
      var args = readEmAsmArgs(sigPtr, argbuf);
      if (!ASM_CONSTS.hasOwnProperty(code)) abort(`No EM_ASM constant found at address ${code}`);
      return ASM_CONSTS[code].apply(null, args);
    };
    function _emscripten_asm_const_int(code, sigPtr, argbuf) {
      code >>>= 0;
      sigPtr >>>= 0;
      argbuf >>>= 0;
      return runEmAsmFunction(code, sigPtr, argbuf);
    }
    function _emscripten_asm_const_ptr(code, sigPtr, argbuf) {
      code >>>= 0;
      sigPtr >>>= 0;
      argbuf >>>= 0;
      return runEmAsmFunction(code, sigPtr, argbuf);
    }
    function _emscripten_console_error(str) {
      str >>>= 0;
      assert(typeof str == "number");
      console.error(UTF8ToString(str));
    }
    function _emscripten_date_now() {
      return Date.now();
    }
    var getHeapMax = () => 4294901760;
    function _emscripten_get_heap_max() {
      return getHeapMax();
    }
    var growMemory = (size) => {
      var b = wasmMemory.buffer;
      var pages = size - b.byteLength + 65535 >>> 16;
      try {
        wasmMemory.grow(pages);
        updateMemoryViews();
        return 1;
      } catch (e) {
        err(`growMemory: Attempted to grow heap from ${b.byteLength} bytes to ${size} bytes, but got error: ${e}`);
      }
    };
    function _emscripten_resize_heap(requestedSize) {
      requestedSize >>>= 0;
      var oldSize = HEAPU8.length;
      assert(requestedSize > oldSize);
      var maxHeapSize = getHeapMax();
      if (requestedSize > maxHeapSize) {
        err(`Cannot enlarge memory, asked to go up to ${requestedSize} bytes, but the limit is ${maxHeapSize} bytes!`);
        return false;
      }
      var alignUp = (x2, multiple) => x2 + (multiple - x2 % multiple) % multiple;
      for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
        var overGrownHeapSize = oldSize * (1 + 0.2 / cutDown);
        overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296);
        var newSize = Math.min(maxHeapSize, alignUp(Math.max(requestedSize, overGrownHeapSize), 65536));
        var replacement = growMemory(newSize);
        if (replacement) {
          return true;
        }
      }
      err(`Failed to grow the heap from ${oldSize} bytes to ${newSize} bytes, not enough memory!`);
      return false;
    }
    var ENV = {};
    var getExecutableName = () => thisProgram || "./this.program";
    var getEnvStrings = () => {
      if (!getEnvStrings.strings) {
        var lang = (typeof navigator == "object" && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8";
        var env = { "USER": "web_user", "LOGNAME": "web_user", "PATH": "/", "PWD": "/", "HOME": "/home/web_user", "LANG": lang, "_": getExecutableName() };
        for (var x2 in ENV) {
          if (ENV[x2] === void 0) delete env[x2];
          else env[x2] = ENV[x2];
        }
        var strings = [];
        for (var x2 in env) {
          strings.push(`${x2}=${env[x2]}`);
        }
        getEnvStrings.strings = strings;
      }
      return getEnvStrings.strings;
    };
    var stringToAscii = (str, buffer) => {
      for (var i2 = 0; i2 < str.length; ++i2) {
        assert(str.charCodeAt(i2) === (str.charCodeAt(i2) & 255));
        HEAP8[buffer++ >>> 0] = str.charCodeAt(i2);
      }
      HEAP8[buffer >>> 0] = 0;
    };
    function _environ_get(__environ, environ_buf) {
      __environ >>>= 0;
      environ_buf >>>= 0;
      var bufSize = 0;
      getEnvStrings().forEach(function(string, i2) {
        var ptr = environ_buf + bufSize;
        HEAPU32[__environ + i2 * 4 >>> 2] = ptr;
        stringToAscii(string, ptr);
        bufSize += string.length + 1;
      });
      return 0;
    }
    function _environ_sizes_get(penviron_count, penviron_buf_size) {
      penviron_count >>>= 0;
      penviron_buf_size >>>= 0;
      var strings = getEnvStrings();
      HEAPU32[penviron_count >>> 2] = strings.length;
      var bufSize = 0;
      strings.forEach(function(string) {
        bufSize += string.length + 1;
      });
      HEAPU32[penviron_buf_size >>> 2] = bufSize;
      return 0;
    }
    function _fd_close(fd2) {
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        FS.close(stream);
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return e.errno;
      }
    }
    function _fd_fdstat_get(fd2, pbuf) {
      pbuf >>>= 0;
      try {
        var rightsBase = 0;
        var rightsInheriting = 0;
        var flags = 0;
        {
          var stream = SYSCALLS.getStreamFromFD(fd2);
          var type = stream.tty ? 2 : FS.isDir(stream.mode) ? 3 : FS.isLink(stream.mode) ? 7 : 4;
        }
        HEAP8[pbuf >>> 0] = type;
        HEAP16[pbuf + 2 >>> 1] = flags;
        tempI64 = [rightsBase >>> 0, (tempDouble = rightsBase, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[pbuf + 8 >>> 2] = tempI64[0], HEAP32[pbuf + 12 >>> 2] = tempI64[1];
        tempI64 = [rightsInheriting >>> 0, (tempDouble = rightsInheriting, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[pbuf + 16 >>> 2] = tempI64[0], HEAP32[pbuf + 20 >>> 2] = tempI64[1];
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return e.errno;
      }
    }
    var doReadv = (stream, iov, iovcnt, offset) => {
      var ret = 0;
      for (var i2 = 0; i2 < iovcnt; i2++) {
        var ptr = HEAPU32[iov >>> 2];
        var len2 = HEAPU32[iov + 4 >>> 2];
        iov += 8;
        var curr = FS.read(stream, HEAP8, ptr, len2, offset);
        if (curr < 0) return -1;
        ret += curr;
        if (curr < len2) break;
      }
      return ret;
    };
    function _fd_read(fd2, iov, iovcnt, pnum) {
      iov >>>= 0;
      iovcnt >>>= 0;
      pnum >>>= 0;
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        var num = doReadv(stream, iov, iovcnt);
        HEAPU32[pnum >>> 2] = num;
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return e.errno;
      }
    }
    function _fd_seek(fd2, offset_low, offset_high, whence, newOffset) {
      var offset = convertI32PairToI53Checked(offset_low, offset_high);
      newOffset >>>= 0;
      try {
        if (isNaN(offset)) return 61;
        var stream = SYSCALLS.getStreamFromFD(fd2);
        FS.llseek(stream, offset, whence);
        tempI64 = [stream.position >>> 0, (tempDouble = stream.position, +Math.abs(tempDouble) >= 1 ? tempDouble > 0 ? +Math.floor(tempDouble / 4294967296) >>> 0 : ~~+Math.ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[newOffset >>> 2] = tempI64[0], HEAP32[newOffset + 4 >>> 2] = tempI64[1];
        if (stream.getdents && offset === 0 && whence === 0) stream.getdents = null;
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return e.errno;
      }
    }
    function _fd_sync(fd2) {
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        return Asyncify.handleSleep(function(wakeUp) {
          var mount = stream.node.mount;
          if (!mount.type.syncfs) {
            wakeUp(0);
            return;
          }
          mount.type.syncfs(mount, false, function(err2) {
            if (err2) {
              wakeUp(function() {
                return 29;
              });
              return;
            }
            wakeUp(0);
          });
        });
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return e.errno;
      }
    }
    var doWritev = (stream, iov, iovcnt, offset) => {
      var ret = 0;
      for (var i2 = 0; i2 < iovcnt; i2++) {
        var ptr = HEAPU32[iov >>> 2];
        var len2 = HEAPU32[iov + 4 >>> 2];
        iov += 8;
        var curr = FS.write(stream, HEAP8, ptr, len2, offset);
        if (curr < 0) return -1;
        ret += curr;
      }
      return ret;
    };
    function _fd_write(fd2, iov, iovcnt, pnum) {
      iov >>>= 0;
      iovcnt >>>= 0;
      pnum >>>= 0;
      try {
        var stream = SYSCALLS.getStreamFromFD(fd2);
        var num = doWritev(stream, iov, iovcnt);
        HEAPU32[pnum >>> 2] = num;
        return 0;
      } catch (e) {
        if (typeof FS == "undefined" || !(e.name === "ErrnoError")) throw e;
        return e.errno;
      }
    }
    function _getaddrinfo(node, service, hint, out2) {
      node >>>= 0;
      service >>>= 0;
      hint >>>= 0;
      out2 >>>= 0;
      var addr = 0;
      var port = 0;
      var flags = 0;
      var family = 0;
      var type = 0;
      var proto = 0;
      var ai;
      function allocaddrinfo(family2, type2, proto2, canon, addr2, port2) {
        var sa, salen, ai2;
        var errno;
        salen = family2 === 10 ? 28 : 16;
        addr2 = family2 === 10 ? inetNtop6(addr2) : inetNtop4(addr2);
        sa = _malloc(salen);
        errno = writeSockaddr(sa, family2, addr2, port2);
        assert(!errno);
        ai2 = _malloc(32);
        HEAP32[ai2 + 4 >>> 2] = family2;
        HEAP32[ai2 + 8 >>> 2] = type2;
        HEAP32[ai2 + 12 >>> 2] = proto2;
        HEAPU32[ai2 + 24 >>> 2] = canon;
        HEAPU32[ai2 + 20 >>> 2] = sa;
        if (family2 === 10) {
          HEAP32[ai2 + 16 >>> 2] = 28;
        } else {
          HEAP32[ai2 + 16 >>> 2] = 16;
        }
        HEAP32[ai2 + 28 >>> 2] = 0;
        return ai2;
      }
      if (hint) {
        flags = HEAP32[hint >>> 2];
        family = HEAP32[hint + 4 >>> 2];
        type = HEAP32[hint + 8 >>> 2];
        proto = HEAP32[hint + 12 >>> 2];
      }
      if (type && !proto) {
        proto = type === 2 ? 17 : 6;
      }
      if (!type && proto) {
        type = proto === 17 ? 2 : 1;
      }
      if (proto === 0) {
        proto = 6;
      }
      if (type === 0) {
        type = 1;
      }
      if (!node && !service) {
        return -2;
      }
      if (flags & -1088) {
        return -1;
      }
      if (hint !== 0 && HEAP32[hint >>> 2] & 2 && !node) {
        return -1;
      }
      if (flags & 32) {
        return -2;
      }
      if (type !== 0 && type !== 1 && type !== 2) {
        return -7;
      }
      if (family !== 0 && family !== 2 && family !== 10) {
        return -6;
      }
      if (service) {
        service = UTF8ToString(service);
        port = parseInt(service, 10);
        if (isNaN(port)) {
          if (flags & 1024) {
            return -2;
          }
          return -8;
        }
      }
      if (!node) {
        if (family === 0) {
          family = 2;
        }
        if ((flags & 1) === 0) {
          if (family === 2) {
            addr = _htonl(2130706433);
          } else {
            addr = [0, 0, 0, 1];
          }
        }
        ai = allocaddrinfo(family, type, proto, null, addr, port);
        HEAPU32[out2 >>> 2] = ai;
        return 0;
      }
      node = UTF8ToString(node);
      addr = inetPton4(node);
      if (addr !== null) {
        if (family === 0 || family === 2) {
          family = 2;
        } else if (family === 10 && flags & 8) {
          addr = [0, 0, _htonl(65535), addr];
          family = 10;
        } else {
          return -2;
        }
      } else {
        addr = inetPton6(node);
        if (addr !== null) {
          if (family === 0 || family === 10) {
            family = 10;
          } else {
            return -2;
          }
        }
      }
      if (addr != null) {
        ai = allocaddrinfo(family, type, proto, node, addr, port);
        HEAPU32[out2 >>> 2] = ai;
        return 0;
      }
      if (flags & 4) {
        return -2;
      }
      node = DNS.lookup_name(node);
      addr = inetPton4(node);
      if (family === 0) {
        family = 2;
      } else if (family === 10) {
        addr = [0, 0, _htonl(65535), addr];
      }
      ai = allocaddrinfo(family, type, proto, null, addr, port);
      HEAPU32[out2 >>> 2] = ai;
      return 0;
    }
    function _getcontext() {
      err("missing function: getcontext");
      abort(-1);
    }
    function _getdtablesize() {
      err("missing function: getdtablesize");
      abort(-1);
    }
    var getHostByName = (name) => {
      var ret = _malloc(20);
      var nameBuf = stringToNewUTF8(name);
      HEAPU32[ret >>> 2] = nameBuf;
      var aliasesBuf = _malloc(4);
      HEAPU32[aliasesBuf >>> 2] = 0;
      HEAPU32[ret + 4 >>> 2] = aliasesBuf;
      var afinet = 2;
      HEAP32[ret + 8 >>> 2] = afinet;
      HEAP32[ret + 12 >>> 2] = 4;
      var addrListBuf = _malloc(12);
      HEAPU32[addrListBuf >>> 2] = addrListBuf + 8;
      HEAPU32[addrListBuf + 4 >>> 2] = 0;
      HEAP32[addrListBuf + 8 >>> 2] = inetPton4(DNS.lookup_name(name));
      HEAPU32[ret + 16 >>> 2] = addrListBuf;
      return ret;
    };
    function _gethostbyname(name) {
      name >>>= 0;
      return getHostByName(UTF8ToString(name));
    }
    function _gethostbyname_r(name, ret, buf, buflen, out2, err2) {
      name >>>= 0;
      ret >>>= 0;
      out2 >>>= 0;
      err2 >>>= 0;
      var data = _gethostbyname(name);
      _memcpy(ret, data, 20);
      _free(data);
      HEAP32[err2 >>> 2] = 0;
      HEAPU32[out2 >>> 2] = ret;
      return 0;
    }
    function _getloadavg(loadavg, nelem) {
      loadavg >>>= 0;
      var limit = Math.min(nelem, 3);
      var doubleSize = 8;
      for (var i2 = 0; i2 < limit; i2++) {
        HEAPF64[loadavg + i2 * doubleSize >>> 3] = 0.1;
      }
      return limit;
    }
    function _getnameinfo(sa, salen, node, nodelen, serv, servlen, flags) {
      sa >>>= 0;
      node >>>= 0;
      serv >>>= 0;
      var info = readSockaddr(sa, salen);
      if (info.errno) {
        return -6;
      }
      var port = info.port;
      var addr = info.addr;
      var overflowed = false;
      if (node && nodelen) {
        var lookup;
        if (flags & 1 || !(lookup = DNS.lookup_addr(addr))) {
          if (flags & 8) {
            return -2;
          }
        } else {
          addr = lookup;
        }
        var numBytesWrittenExclNull = stringToUTF8(addr, node, nodelen);
        if (numBytesWrittenExclNull + 1 >= nodelen) {
          overflowed = true;
        }
      }
      if (serv && servlen) {
        port = "" + port;
        var numBytesWrittenExclNull = stringToUTF8(port, serv, servlen);
        if (numBytesWrittenExclNull + 1 >= servlen) {
          overflowed = true;
        }
      }
      if (overflowed) {
        return -12;
      }
      return 0;
    }
    var Protocols = { list: [], map: {} };
    var _setprotoent = (stayopen) => {
      function allocprotoent(name, proto, aliases) {
        var nameBuf = _malloc(name.length + 1);
        stringToAscii(name, nameBuf);
        var j = 0;
        var length = aliases.length;
        var aliasListBuf = _malloc((length + 1) * 4);
        for (var i2 = 0; i2 < length; i2++, j += 4) {
          var alias = aliases[i2];
          var aliasBuf = _malloc(alias.length + 1);
          stringToAscii(alias, aliasBuf);
          HEAPU32[aliasListBuf + j >>> 2] = aliasBuf;
        }
        HEAPU32[aliasListBuf + j >>> 2] = 0;
        var pe = _malloc(12);
        HEAPU32[pe >>> 2] = nameBuf;
        HEAPU32[pe + 4 >>> 2] = aliasListBuf;
        HEAP32[pe + 8 >>> 2] = proto;
        return pe;
      }
      var list = Protocols.list;
      var map = Protocols.map;
      if (list.length === 0) {
        var entry = allocprotoent("tcp", 6, ["TCP"]);
        list.push(entry);
        map["tcp"] = map["6"] = entry;
        entry = allocprotoent("udp", 17, ["UDP"]);
        list.push(entry);
        map["udp"] = map["17"] = entry;
      }
      _setprotoent.index = 0;
    };
    function _getprotobyname(name) {
      name >>>= 0;
      name = UTF8ToString(name);
      _setprotoent();
      var result = Protocols.map[name];
      return result;
    }
    function _getprotobynumber(number) {
      _setprotoent();
      var result = Protocols.map[number];
      return result;
    }
    function _makecontext() {
      err("missing function: makecontext");
      abort(-1);
    }
    var arraySum = (array, index) => {
      var sum = 0;
      for (var i2 = 0; i2 <= index; sum += array[i2++]) {
      }
      return sum;
    };
    var MONTH_DAYS_LEAP = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var MONTH_DAYS_REGULAR = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var addDays = (date, days) => {
      var newDate = new Date(date.getTime());
      while (days > 0) {
        var leap = isLeapYear(newDate.getFullYear());
        var currentMonth = newDate.getMonth();
        var daysInCurrentMonth = (leap ? MONTH_DAYS_LEAP : MONTH_DAYS_REGULAR)[currentMonth];
        if (days > daysInCurrentMonth - newDate.getDate()) {
          days -= daysInCurrentMonth - newDate.getDate() + 1;
          newDate.setDate(1);
          if (currentMonth < 11) {
            newDate.setMonth(currentMonth + 1);
          } else {
            newDate.setMonth(0);
            newDate.setFullYear(newDate.getFullYear() + 1);
          }
        } else {
          newDate.setDate(newDate.getDate() + days);
          return newDate;
        }
      }
      return newDate;
    };
    var writeArrayToMemory = (array, buffer) => {
      assert(array.length >= 0, "writeArrayToMemory array must have a length (should be an array or typed array)");
      HEAP8.set(array, buffer >>> 0);
    };
    function _strftime(s, maxsize, format, tm) {
      s >>>= 0;
      maxsize >>>= 0;
      format >>>= 0;
      tm >>>= 0;
      var tm_zone = HEAP32[tm + 40 >>> 2];
      var date = { tm_sec: HEAP32[tm >>> 2], tm_min: HEAP32[tm + 4 >>> 2], tm_hour: HEAP32[tm + 8 >>> 2], tm_mday: HEAP32[tm + 12 >>> 2], tm_mon: HEAP32[tm + 16 >>> 2], tm_year: HEAP32[tm + 20 >>> 2], tm_wday: HEAP32[tm + 24 >>> 2], tm_yday: HEAP32[tm + 28 >>> 2], tm_isdst: HEAP32[tm + 32 >>> 2], tm_gmtoff: HEAP32[tm + 36 >>> 2], tm_zone: tm_zone ? UTF8ToString(tm_zone) : "" };
      var pattern = UTF8ToString(format);
      var EXPANSION_RULES_1 = { "%c": "%a %b %d %H:%M:%S %Y", "%D": "%m/%d/%y", "%F": "%Y-%m-%d", "%h": "%b", "%r": "%I:%M:%S %p", "%R": "%H:%M", "%T": "%H:%M:%S", "%x": "%m/%d/%y", "%X": "%H:%M:%S", "%Ec": "%c", "%EC": "%C", "%Ex": "%m/%d/%y", "%EX": "%H:%M:%S", "%Ey": "%y", "%EY": "%Y", "%Od": "%d", "%Oe": "%e", "%OH": "%H", "%OI": "%I", "%Om": "%m", "%OM": "%M", "%OS": "%S", "%Ou": "%u", "%OU": "%U", "%OV": "%V", "%Ow": "%w", "%OW": "%W", "%Oy": "%y" };
      for (var rule in EXPANSION_RULES_1) {
        pattern = pattern.replace(new RegExp(rule, "g"), EXPANSION_RULES_1[rule]);
      }
      var WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
      var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      function leadingSomething(value, digits, character) {
        var str = typeof value == "number" ? value.toString() : value || "";
        while (str.length < digits) {
          str = character[0] + str;
        }
        return str;
      }
      function leadingNulls(value, digits) {
        return leadingSomething(value, digits, "0");
      }
      function compareByDay(date1, date2) {
        function sgn(value) {
          return value < 0 ? -1 : value > 0 ? 1 : 0;
        }
        var compare;
        if ((compare = sgn(date1.getFullYear() - date2.getFullYear())) === 0) {
          if ((compare = sgn(date1.getMonth() - date2.getMonth())) === 0) {
            compare = sgn(date1.getDate() - date2.getDate());
          }
        }
        return compare;
      }
      function getFirstWeekStartDate(janFourth) {
        switch (janFourth.getDay()) {
          case 0:
            return new Date(janFourth.getFullYear() - 1, 11, 29);
          case 1:
            return janFourth;
          case 2:
            return new Date(janFourth.getFullYear(), 0, 3);
          case 3:
            return new Date(janFourth.getFullYear(), 0, 2);
          case 4:
            return new Date(janFourth.getFullYear(), 0, 1);
          case 5:
            return new Date(janFourth.getFullYear() - 1, 11, 31);
          case 6:
            return new Date(janFourth.getFullYear() - 1, 11, 30);
        }
      }
      function getWeekBasedYear(date2) {
        var thisDate = addDays(new Date(date2.tm_year + 1900, 0, 1), date2.tm_yday);
        var janFourthThisYear = new Date(thisDate.getFullYear(), 0, 4);
        var janFourthNextYear = new Date(thisDate.getFullYear() + 1, 0, 4);
        var firstWeekStartThisYear = getFirstWeekStartDate(janFourthThisYear);
        var firstWeekStartNextYear = getFirstWeekStartDate(janFourthNextYear);
        if (compareByDay(firstWeekStartThisYear, thisDate) <= 0) {
          if (compareByDay(firstWeekStartNextYear, thisDate) <= 0) {
            return thisDate.getFullYear() + 1;
          }
          return thisDate.getFullYear();
        }
        return thisDate.getFullYear() - 1;
      }
      var EXPANSION_RULES_2 = { "%a": (date2) => WEEKDAYS[date2.tm_wday].substring(0, 3), "%A": (date2) => WEEKDAYS[date2.tm_wday], "%b": (date2) => MONTHS[date2.tm_mon].substring(0, 3), "%B": (date2) => MONTHS[date2.tm_mon], "%C": (date2) => {
        var year = date2.tm_year + 1900;
        return leadingNulls(year / 100 | 0, 2);
      }, "%d": (date2) => leadingNulls(date2.tm_mday, 2), "%e": (date2) => leadingSomething(date2.tm_mday, 2, " "), "%g": (date2) => getWeekBasedYear(date2).toString().substring(2), "%G": (date2) => getWeekBasedYear(date2), "%H": (date2) => leadingNulls(date2.tm_hour, 2), "%I": (date2) => {
        var twelveHour = date2.tm_hour;
        if (twelveHour == 0) twelveHour = 12;
        else if (twelveHour > 12) twelveHour -= 12;
        return leadingNulls(twelveHour, 2);
      }, "%j": (date2) => leadingNulls(date2.tm_mday + arraySum(isLeapYear(date2.tm_year + 1900) ? MONTH_DAYS_LEAP : MONTH_DAYS_REGULAR, date2.tm_mon - 1), 3), "%m": (date2) => leadingNulls(date2.tm_mon + 1, 2), "%M": (date2) => leadingNulls(date2.tm_min, 2), "%n": () => "\n", "%p": (date2) => {
        if (date2.tm_hour >= 0 && date2.tm_hour < 12) {
          return "AM";
        }
        return "PM";
      }, "%S": (date2) => leadingNulls(date2.tm_sec, 2), "%t": () => "	", "%u": (date2) => date2.tm_wday || 7, "%U": (date2) => {
        var days = date2.tm_yday + 7 - date2.tm_wday;
        return leadingNulls(Math.floor(days / 7), 2);
      }, "%V": (date2) => {
        var val = Math.floor((date2.tm_yday + 7 - (date2.tm_wday + 6) % 7) / 7);
        if ((date2.tm_wday + 371 - date2.tm_yday - 2) % 7 <= 2) {
          val++;
        }
        if (!val) {
          val = 52;
          var dec31 = (date2.tm_wday + 7 - date2.tm_yday - 1) % 7;
          if (dec31 == 4 || dec31 == 5 && isLeapYear(date2.tm_year % 400 - 1)) {
            val++;
          }
        } else if (val == 53) {
          var jan1 = (date2.tm_wday + 371 - date2.tm_yday) % 7;
          if (jan1 != 4 && (jan1 != 3 || !isLeapYear(date2.tm_year))) val = 1;
        }
        return leadingNulls(val, 2);
      }, "%w": (date2) => date2.tm_wday, "%W": (date2) => {
        var days = date2.tm_yday + 7 - (date2.tm_wday + 6) % 7;
        return leadingNulls(Math.floor(days / 7), 2);
      }, "%y": (date2) => (date2.tm_year + 1900).toString().substring(2), "%Y": (date2) => date2.tm_year + 1900, "%z": (date2) => {
        var off = date2.tm_gmtoff;
        var ahead = off >= 0;
        off = Math.abs(off) / 60;
        off = off / 60 * 100 + off % 60;
        return (ahead ? "+" : "-") + String("0000" + off).slice(-4);
      }, "%Z": (date2) => date2.tm_zone, "%%": () => "%" };
      pattern = pattern.replace(/%%/g, "\0\0");
      for (var rule in EXPANSION_RULES_2) {
        if (pattern.includes(rule)) {
          pattern = pattern.replace(new RegExp(rule, "g"), EXPANSION_RULES_2[rule](date));
        }
      }
      pattern = pattern.replace(/\0\0/g, "%");
      var bytes = intArrayFromString(pattern, false);
      if (bytes.length > maxsize) {
        return 0;
      }
      writeArrayToMemory(bytes, s);
      return bytes.length - 1;
    }
    function _strptime(buf, format, tm) {
      buf >>>= 0;
      format >>>= 0;
      tm >>>= 0;
      var pattern = UTF8ToString(format);
      var SPECIAL_CHARS = "\\!@#$^&*()+=-[]/{}|:<>?,.";
      for (var i2 = 0, ii = SPECIAL_CHARS.length; i2 < ii; ++i2) {
        pattern = pattern.replace(new RegExp("\\" + SPECIAL_CHARS[i2], "g"), "\\" + SPECIAL_CHARS[i2]);
      }
      var EQUIVALENT_MATCHERS = { "%A": "%a", "%B": "%b", "%c": "%a %b %d %H:%M:%S %Y", "%D": "%m\\/%d\\/%y", "%e": "%d", "%F": "%Y-%m-%d", "%h": "%b", "%R": "%H\\:%M", "%r": "%I\\:%M\\:%S\\s%p", "%T": "%H\\:%M\\:%S", "%x": "%m\\/%d\\/(?:%y|%Y)", "%X": "%H\\:%M\\:%S" };
      for (var matcher in EQUIVALENT_MATCHERS) {
        pattern = pattern.replace(matcher, EQUIVALENT_MATCHERS[matcher]);
      }
      var DATE_PATTERNS = { "%a": "(?:Sun(?:day)?)|(?:Mon(?:day)?)|(?:Tue(?:sday)?)|(?:Wed(?:nesday)?)|(?:Thu(?:rsday)?)|(?:Fri(?:day)?)|(?:Sat(?:urday)?)", "%b": "(?:Jan(?:uary)?)|(?:Feb(?:ruary)?)|(?:Mar(?:ch)?)|(?:Apr(?:il)?)|May|(?:Jun(?:e)?)|(?:Jul(?:y)?)|(?:Aug(?:ust)?)|(?:Sep(?:tember)?)|(?:Oct(?:ober)?)|(?:Nov(?:ember)?)|(?:Dec(?:ember)?)", "%C": "\\d\\d", "%d": "0[1-9]|[1-9](?!\\d)|1\\d|2\\d|30|31", "%H": "\\d(?!\\d)|[0,1]\\d|20|21|22|23", "%I": "\\d(?!\\d)|0\\d|10|11|12", "%j": "00[1-9]|0?[1-9](?!\\d)|0?[1-9]\\d(?!\\d)|[1,2]\\d\\d|3[0-6]\\d", "%m": "0[1-9]|[1-9](?!\\d)|10|11|12", "%M": "0\\d|\\d(?!\\d)|[1-5]\\d", "%n": "\\s", "%p": "AM|am|PM|pm|A\\.M\\.|a\\.m\\.|P\\.M\\.|p\\.m\\.", "%S": "0\\d|\\d(?!\\d)|[1-5]\\d|60", "%U": "0\\d|\\d(?!\\d)|[1-4]\\d|50|51|52|53", "%W": "0\\d|\\d(?!\\d)|[1-4]\\d|50|51|52|53", "%w": "[0-6]", "%y": "\\d\\d", "%Y": "\\d\\d\\d\\d", "%%": "%", "%t": "\\s" };
      var MONTH_NUMBERS = { JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5, JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11 };
      var DAY_NUMBERS_SUN_FIRST = { SUN: 0, MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };
      var DAY_NUMBERS_MON_FIRST = { MON: 0, TUE: 1, WED: 2, THU: 3, FRI: 4, SAT: 5, SUN: 6 };
      for (var datePattern in DATE_PATTERNS) {
        pattern = pattern.replace(datePattern, "(" + datePattern + DATE_PATTERNS[datePattern] + ")");
      }
      var capture = [];
      for (var i2 = pattern.indexOf("%"); i2 >= 0; i2 = pattern.indexOf("%")) {
        capture.push(pattern[i2 + 1]);
        pattern = pattern.replace(new RegExp("\\%" + pattern[i2 + 1], "g"), "");
      }
      var matches = new RegExp("^" + pattern, "i").exec(UTF8ToString(buf));
      function initDate() {
        function fixup(value2, min, max2) {
          return typeof value2 != "number" || isNaN(value2) ? min : value2 >= min ? value2 <= max2 ? value2 : max2 : min;
        }
        return { year: fixup(HEAP32[tm + 20 >>> 2] + 1900, 1970, 9999), month: fixup(HEAP32[tm + 16 >>> 2], 0, 11), day: fixup(HEAP32[tm + 12 >>> 2], 1, 31), hour: fixup(HEAP32[tm + 8 >>> 2], 0, 23), min: fixup(HEAP32[tm + 4 >>> 2], 0, 59), sec: fixup(HEAP32[tm >>> 2], 0, 59) };
      }
      if (matches) {
        var date = initDate();
        var value;
        var getMatch = (symbol) => {
          var pos = capture.indexOf(symbol);
          if (pos >= 0) {
            return matches[pos + 1];
          }
          return;
        };
        if (value = getMatch("S")) {
          date.sec = jstoi_q(value);
        }
        if (value = getMatch("M")) {
          date.min = jstoi_q(value);
        }
        if (value = getMatch("H")) {
          date.hour = jstoi_q(value);
        } else if (value = getMatch("I")) {
          var hour = jstoi_q(value);
          if (value = getMatch("p")) {
            hour += value.toUpperCase()[0] === "P" ? 12 : 0;
          }
          date.hour = hour;
        }
        if (value = getMatch("Y")) {
          date.year = jstoi_q(value);
        } else if (value = getMatch("y")) {
          var year = jstoi_q(value);
          if (value = getMatch("C")) {
            year += jstoi_q(value) * 100;
          } else {
            year += year < 69 ? 2e3 : 1900;
          }
          date.year = year;
        }
        if (value = getMatch("m")) {
          date.month = jstoi_q(value) - 1;
        } else if (value = getMatch("b")) {
          date.month = MONTH_NUMBERS[value.substring(0, 3).toUpperCase()] || 0;
        }
        if (value = getMatch("d")) {
          date.day = jstoi_q(value);
        } else if (value = getMatch("j")) {
          var day = jstoi_q(value);
          var leapYear = isLeapYear(date.year);
          for (var month = 0; month < 12; ++month) {
            var daysUntilMonth = arraySum(leapYear ? MONTH_DAYS_LEAP : MONTH_DAYS_REGULAR, month - 1);
            if (day <= daysUntilMonth + (leapYear ? MONTH_DAYS_LEAP : MONTH_DAYS_REGULAR)[month]) {
              date.day = day - daysUntilMonth;
            }
          }
        } else if (value = getMatch("a")) {
          var weekDay = value.substring(0, 3).toUpperCase();
          if (value = getMatch("U")) {
            var weekDayNumber = DAY_NUMBERS_SUN_FIRST[weekDay];
            var weekNumber = jstoi_q(value);
            var janFirst = new Date(date.year, 0, 1);
            var endDate;
            if (janFirst.getDay() === 0) {
              endDate = addDays(janFirst, weekDayNumber + 7 * (weekNumber - 1));
            } else {
              endDate = addDays(janFirst, 7 - janFirst.getDay() + weekDayNumber + 7 * (weekNumber - 1));
            }
            date.day = endDate.getDate();
            date.month = endDate.getMonth();
          } else if (value = getMatch("W")) {
            var weekDayNumber = DAY_NUMBERS_MON_FIRST[weekDay];
            var weekNumber = jstoi_q(value);
            var janFirst = new Date(date.year, 0, 1);
            var endDate;
            if (janFirst.getDay() === 1) {
              endDate = addDays(janFirst, weekDayNumber + 7 * (weekNumber - 1));
            } else {
              endDate = addDays(janFirst, 7 - janFirst.getDay() + 1 + weekDayNumber + 7 * (weekNumber - 1));
            }
            date.day = endDate.getDate();
            date.month = endDate.getMonth();
          }
        }
        var fullDate = new Date(date.year, date.month, date.day, date.hour, date.min, date.sec, 0);
        HEAP32[tm >>> 2] = fullDate.getSeconds();
        HEAP32[tm + 4 >>> 2] = fullDate.getMinutes();
        HEAP32[tm + 8 >>> 2] = fullDate.getHours();
        HEAP32[tm + 12 >>> 2] = fullDate.getDate();
        HEAP32[tm + 16 >>> 2] = fullDate.getMonth();
        HEAP32[tm + 20 >>> 2] = fullDate.getFullYear() - 1900;
        HEAP32[tm + 24 >>> 2] = fullDate.getDay();
        HEAP32[tm + 28 >>> 2] = arraySum(isLeapYear(fullDate.getFullYear()) ? MONTH_DAYS_LEAP : MONTH_DAYS_REGULAR, fullDate.getMonth() - 1) + fullDate.getDate() - 1;
        HEAP32[tm + 32 >>> 2] = 0;
        return buf + intArrayFromString(matches[0]).length - 1;
      }
      return 0;
    }
    function _swapcontext() {
      err("missing function: swapcontext");
      abort(-1);
    }
    function runAndAbortIfError(func) {
      try {
        return func();
      } catch (e) {
        abort(e);
      }
    }
    var runtimeKeepalivePush = () => {
      runtimeKeepaliveCounter += 1;
    };
    var runtimeKeepalivePop = () => {
      assert(runtimeKeepaliveCounter > 0);
      runtimeKeepaliveCounter -= 1;
    };
    var Asyncify = { instrumentWasmImports: function(imports) {
      var importPatterns = [/^invoke_.*$/, /^fd_sync$/, /^__wasi_fd_sync$/, /^__asyncjs__.*$/, /^emscripten_promise_await$/, /^emscripten_idb_load$/, /^emscripten_idb_store$/, /^emscripten_idb_delete$/, /^emscripten_idb_exists$/, /^emscripten_idb_load_blob$/, /^emscripten_idb_store_blob$/, /^emscripten_sleep$/, /^emscripten_wget_data$/, /^emscripten_scan_registers$/, /^emscripten_lazy_load_code$/, /^_load_secondary_module$/, /^emscripten_fiber_swap$/, /^SDL_Delay$/];
      for (var x2 in imports) {
        (function(x3) {
          var original = imports[x3];
          original.sig;
          if (typeof original == "function") {
            var isAsyncifyImport = original.isAsync || importPatterns.some((pattern) => !!x3.match(pattern));
            imports[x3] = function() {
              var originalAsyncifyState = Asyncify.state;
              try {
                return original.apply(null, arguments);
              } finally {
                var changedToDisabled = originalAsyncifyState === Asyncify.State.Normal && Asyncify.state === Asyncify.State.Disabled;
                var ignoredInvoke = x3.startsWith("invoke_") && true;
                if (Asyncify.state !== originalAsyncifyState && !isAsyncifyImport && !changedToDisabled && !ignoredInvoke) {
                  throw new Error(`import ${x3} was not in ASYNCIFY_IMPORTS, but changed the state`);
                }
              }
            };
          }
        })(x2);
      }
    }, instrumentWasmExports: function(exports) {
      var ret = {};
      for (var x2 in exports) {
        (function(x3) {
          var original = exports[x3];
          if (typeof original == "function") {
            ret[x3] = function() {
              Asyncify.exportCallStack.push(x3);
              try {
                return original.apply(null, arguments);
              } finally {
                if (!ABORT) {
                  var y = Asyncify.exportCallStack.pop();
                  assert(y === x3);
                  Asyncify.maybeStopUnwind();
                }
              }
            };
          } else {
            ret[x3] = original;
          }
        })(x2);
      }
      return ret;
    }, State: { Normal: 0, Unwinding: 1, Rewinding: 2, Disabled: 3 }, state: 0, StackSize: 4096, currData: null, handleSleepReturnValue: 0, exportCallStack: [], callStackNameToId: {}, callStackIdToName: {}, callStackId: 0, asyncPromiseHandlers: null, sleepCallbacks: [], getCallStackId: function(funcName) {
      var id = Asyncify.callStackNameToId[funcName];
      if (id === void 0) {
        id = Asyncify.callStackId++;
        Asyncify.callStackNameToId[funcName] = id;
        Asyncify.callStackIdToName[id] = funcName;
      }
      return id;
    }, maybeStopUnwind: function() {
      if (Asyncify.currData && Asyncify.state === Asyncify.State.Unwinding && Asyncify.exportCallStack.length === 0) {
        Asyncify.state = Asyncify.State.Normal;
        runtimeKeepalivePush();
        runAndAbortIfError(_asyncify_stop_unwind);
        if (typeof Fibers != "undefined") {
          Fibers.trampoline();
        }
      }
    }, whenDone: function() {
      assert(Asyncify.currData, "Tried to wait for an async operation when none is in progress.");
      assert(!Asyncify.asyncPromiseHandlers, "Cannot have multiple async operations in flight at once");
      return new Promise((resolve, reject) => {
        Asyncify.asyncPromiseHandlers = { resolve, reject };
      });
    }, allocateData: function() {
      var ptr = _malloc(12 + Asyncify.StackSize);
      Asyncify.setDataHeader(ptr, ptr + 12, Asyncify.StackSize);
      Asyncify.setDataRewindFunc(ptr);
      return ptr;
    }, setDataHeader: function(ptr, stack, stackSize) {
      HEAP32[ptr >>> 2] = stack;
      HEAP32[ptr + 4 >>> 2] = stack + stackSize;
    }, setDataRewindFunc: function(ptr) {
      var bottomOfCallStack = Asyncify.exportCallStack[0];
      var rewindId = Asyncify.getCallStackId(bottomOfCallStack);
      HEAP32[ptr + 8 >>> 2] = rewindId;
    }, getDataRewindFunc: function(ptr) {
      var id = HEAP32[ptr + 8 >>> 2];
      var name = Asyncify.callStackIdToName[id];
      var func = Module["asm"][name];
      return func;
    }, doRewind: function(ptr) {
      var start = Asyncify.getDataRewindFunc(ptr);
      runtimeKeepalivePop();
      return start();
    }, handleSleep: function(startAsync) {
      assert(Asyncify.state !== Asyncify.State.Disabled, "Asyncify cannot be done during or after the runtime exits");
      if (ABORT) return;
      if (Asyncify.state === Asyncify.State.Normal) {
        var reachedCallback = false;
        var reachedAfterCallback = false;
        startAsync((handleSleepReturnValue = 0) => {
          assert(!handleSleepReturnValue || typeof handleSleepReturnValue == "number" || typeof handleSleepReturnValue == "boolean");
          if (ABORT) return;
          Asyncify.handleSleepReturnValue = handleSleepReturnValue;
          reachedCallback = true;
          if (!reachedAfterCallback) {
            return;
          }
          assert(!Asyncify.exportCallStack.length, "Waking up (starting to rewind) must be done from JS, without compiled code on the stack.");
          Asyncify.state = Asyncify.State.Rewinding;
          runAndAbortIfError(() => _asyncify_start_rewind(Asyncify.currData));
          if (typeof Browser != "undefined" && Browser.mainLoop.func) {
            Browser.mainLoop.resume();
          }
          var asyncWasmReturnValue, isError = false;
          try {
            asyncWasmReturnValue = Asyncify.doRewind(Asyncify.currData);
          } catch (err2) {
            asyncWasmReturnValue = err2;
            isError = true;
          }
          var handled = false;
          if (!Asyncify.currData) {
            var asyncPromiseHandlers = Asyncify.asyncPromiseHandlers;
            if (asyncPromiseHandlers) {
              Asyncify.asyncPromiseHandlers = null;
              (isError ? asyncPromiseHandlers.reject : asyncPromiseHandlers.resolve)(asyncWasmReturnValue);
              handled = true;
            }
          }
          if (isError && !handled) {
            throw asyncWasmReturnValue;
          }
        });
        reachedAfterCallback = true;
        if (!reachedCallback) {
          Asyncify.state = Asyncify.State.Unwinding;
          Asyncify.currData = Asyncify.allocateData();
          if (typeof Browser != "undefined" && Browser.mainLoop.func) {
            Browser.mainLoop.pause();
          }
          runAndAbortIfError(() => _asyncify_start_unwind(Asyncify.currData));
        }
      } else if (Asyncify.state === Asyncify.State.Rewinding) {
        Asyncify.state = Asyncify.State.Normal;
        runAndAbortIfError(_asyncify_stop_rewind);
        _free(Asyncify.currData);
        Asyncify.currData = null;
        Asyncify.sleepCallbacks.forEach((func) => callUserCallback(func));
      } else {
        abort(`invalid state: ${Asyncify.state}`);
      }
      return Asyncify.handleSleepReturnValue;
    }, handleAsync: function(startAsync) {
      return Asyncify.handleSleep((wakeUp) => {
        startAsync().then(wakeUp);
      });
    } };
    function getCFunc(ident) {
      var func = Module["_" + ident];
      assert(func, "Cannot call unknown function " + ident + ", make sure it is exported");
      return func;
    }
    var stringToUTF8OnStack = (str) => {
      var size = lengthBytesUTF8(str) + 1;
      var ret = stackAlloc(size);
      stringToUTF8(str, ret, size);
      return ret;
    };
    var ccall = function(ident, returnType, argTypes, args, opts) {
      var toC = { "string": (str) => {
        var ret2 = 0;
        if (str !== null && str !== void 0 && str !== 0) {
          ret2 = stringToUTF8OnStack(str);
        }
        return ret2;
      }, "array": (arr) => {
        var ret2 = stackAlloc(arr.length);
        writeArrayToMemory(arr, ret2);
        return ret2;
      } };
      function convertReturnValue(ret2) {
        if (returnType === "string") {
          return UTF8ToString(ret2);
        }
        if (returnType === "boolean") return Boolean(ret2);
        return ret2;
      }
      var func = getCFunc(ident);
      var cArgs = [];
      var stack = 0;
      assert(returnType !== "array", 'Return type should not be "array".');
      if (args) {
        for (var i2 = 0; i2 < args.length; i2++) {
          var converter = toC[argTypes[i2]];
          if (converter) {
            if (stack === 0) stack = stackSave();
            cArgs[i2] = converter(args[i2]);
          } else {
            cArgs[i2] = args[i2];
          }
        }
      }
      var previousAsync = Asyncify.currData;
      var ret = func.apply(null, cArgs);
      function onDone(ret2) {
        runtimeKeepalivePop();
        if (stack !== 0) stackRestore(stack);
        return convertReturnValue(ret2);
      }
      var asyncMode = opts && opts.async;
      runtimeKeepalivePush();
      if (Asyncify.currData != previousAsync) {
        assert(!(previousAsync && Asyncify.currData), "We cannot start an async operation when one is already flight");
        assert(!(previousAsync && !Asyncify.currData), "We cannot stop an async operation in flight");
        assert(asyncMode, "The call to " + ident + " is running asynchronously. If this was intended, add the async option to the ccall/cwrap call.");
        return Asyncify.whenDone().then(onDone);
      }
      ret = onDone(ret);
      if (asyncMode) return Promise.resolve(ret);
      return ret;
    };
    var FSNode = function(parent, name, mode, rdev) {
      if (!parent) {
        parent = this;
      }
      this.parent = parent;
      this.mount = parent.mount;
      this.mounted = null;
      this.id = FS.nextInode++;
      this.name = name;
      this.mode = mode;
      this.node_ops = {};
      this.stream_ops = {};
      this.rdev = rdev;
    };
    var readMode = 292 | 73;
    var writeMode = 146;
    Object.defineProperties(FSNode.prototype, { read: { get: function() {
      return (this.mode & readMode) === readMode;
    }, set: function(val) {
      val ? this.mode |= readMode : this.mode &= ~readMode;
    } }, write: { get: function() {
      return (this.mode & writeMode) === writeMode;
    }, set: function(val) {
      val ? this.mode |= writeMode : this.mode &= ~writeMode;
    } }, isFolder: { get: function() {
      return FS.isDir(this.mode);
    } }, isDevice: { get: function() {
      return FS.isChrdev(this.mode);
    } } });
    FS.FSNode = FSNode;
    FS.createPreloadedFile = FS_createPreloadedFile;
    FS.staticInit();
    Module["FS_createPath"] = FS.createPath;
    Module["FS_createDataFile"] = FS.createDataFile;
    Module["FS_createPreloadedFile"] = FS.createPreloadedFile;
    Module["FS_unlink"] = FS.unlink;
    Module["FS_createLazyFile"] = FS.createLazyFile;
    Module["FS_createDevice"] = FS.createDevice;
    ERRNO_CODES = { "EPERM": 63, "ENOENT": 44, "ESRCH": 71, "EINTR": 27, "EIO": 29, "ENXIO": 60, "E2BIG": 1, "ENOEXEC": 45, "EBADF": 8, "ECHILD": 12, "EAGAIN": 6, "EWOULDBLOCK": 6, "ENOMEM": 48, "EACCES": 2, "EFAULT": 21, "ENOTBLK": 105, "EBUSY": 10, "EEXIST": 20, "EXDEV": 75, "ENODEV": 43, "ENOTDIR": 54, "EISDIR": 31, "EINVAL": 28, "ENFILE": 41, "EMFILE": 33, "ENOTTY": 59, "ETXTBSY": 74, "EFBIG": 22, "ENOSPC": 51, "ESPIPE": 70, "EROFS": 69, "EMLINK": 34, "EPIPE": 64, "EDOM": 18, "ERANGE": 68, "ENOMSG": 49, "EIDRM": 24, "ECHRNG": 106, "EL2NSYNC": 156, "EL3HLT": 107, "EL3RST": 108, "ELNRNG": 109, "EUNATCH": 110, "ENOCSI": 111, "EL2HLT": 112, "EDEADLK": 16, "ENOLCK": 46, "EBADE": 113, "EBADR": 114, "EXFULL": 115, "ENOANO": 104, "EBADRQC": 103, "EBADSLT": 102, "EDEADLOCK": 16, "EBFONT": 101, "ENOSTR": 100, "ENODATA": 116, "ETIME": 117, "ENOSR": 118, "ENONET": 119, "ENOPKG": 120, "EREMOTE": 121, "ENOLINK": 47, "EADV": 122, "ESRMNT": 123, "ECOMM": 124, "EPROTO": 65, "EMULTIHOP": 36, "EDOTDOT": 125, "EBADMSG": 9, "ENOTUNIQ": 126, "EBADFD": 127, "EREMCHG": 128, "ELIBACC": 129, "ELIBBAD": 130, "ELIBSCN": 131, "ELIBMAX": 132, "ELIBEXEC": 133, "ENOSYS": 52, "ENOTEMPTY": 55, "ENAMETOOLONG": 37, "ELOOP": 32, "EOPNOTSUPP": 138, "EPFNOSUPPORT": 139, "ECONNRESET": 15, "ENOBUFS": 42, "EAFNOSUPPORT": 5, "EPROTOTYPE": 67, "ENOTSOCK": 57, "ENOPROTOOPT": 50, "ESHUTDOWN": 140, "ECONNREFUSED": 14, "EADDRINUSE": 3, "ECONNABORTED": 13, "ENETUNREACH": 40, "ENETDOWN": 38, "ETIMEDOUT": 73, "EHOSTDOWN": 142, "EHOSTUNREACH": 23, "EINPROGRESS": 26, "EALREADY": 7, "EDESTADDRREQ": 17, "EMSGSIZE": 35, "EPROTONOSUPPORT": 66, "ESOCKTNOSUPPORT": 137, "EADDRNOTAVAIL": 4, "ENETRESET": 39, "EISCONN": 30, "ENOTCONN": 53, "ETOOMANYREFS": 141, "EUSERS": 136, "EDQUOT": 19, "ESTALE": 72, "ENOTSUP": 138, "ENOMEDIUM": 148, "EILSEQ": 25, "EOVERFLOW": 61, "ECANCELED": 11, "ENOTRECOVERABLE": 56, "EOWNERDEAD": 62, "ESTRPIPE": 135 };
    function checkIncomingModuleAPI() {
      ignoredModuleProp("fetchSettings");
    }
    var wasmImports = { __assert_fail: ___assert_fail, __asyncjs__pdo_vrzno_real_stmt_execute, __asyncjs__vrzno_await_internal, __call_sighandler: ___call_sighandler, __syscall__newselect: ___syscall__newselect, __syscall_accept4: ___syscall_accept4, __syscall_bind: ___syscall_bind, __syscall_chdir: ___syscall_chdir, __syscall_chmod: ___syscall_chmod, __syscall_connect: ___syscall_connect, __syscall_dup: ___syscall_dup, __syscall_dup3: ___syscall_dup3, __syscall_faccessat: ___syscall_faccessat, __syscall_fallocate: ___syscall_fallocate, __syscall_fchmod: ___syscall_fchmod, __syscall_fchown32: ___syscall_fchown32, __syscall_fchownat: ___syscall_fchownat, __syscall_fcntl64: ___syscall_fcntl64, __syscall_fdatasync: ___syscall_fdatasync, __syscall_fstat64: ___syscall_fstat64, __syscall_ftruncate64: ___syscall_ftruncate64, __syscall_getcwd: ___syscall_getcwd, __syscall_getdents64: ___syscall_getdents64, __syscall_getpeername: ___syscall_getpeername, __syscall_getsockname: ___syscall_getsockname, __syscall_getsockopt: ___syscall_getsockopt, __syscall_ioctl: ___syscall_ioctl, __syscall_listen: ___syscall_listen, __syscall_lstat64: ___syscall_lstat64, __syscall_mkdirat: ___syscall_mkdirat, __syscall_newfstatat: ___syscall_newfstatat, __syscall_openat: ___syscall_openat, __syscall_pipe: ___syscall_pipe, __syscall_poll: ___syscall_poll, __syscall_readlinkat: ___syscall_readlinkat, __syscall_recvfrom: ___syscall_recvfrom, __syscall_renameat: ___syscall_renameat, __syscall_rmdir: ___syscall_rmdir, __syscall_sendto: ___syscall_sendto, __syscall_socket: ___syscall_socket, __syscall_stat64: ___syscall_stat64, __syscall_statfs64: ___syscall_statfs64, __syscall_symlink: ___syscall_symlink, __syscall_unlinkat: ___syscall_unlinkat, __syscall_utimensat: ___syscall_utimensat, _emscripten_get_now_is_monotonic: __emscripten_get_now_is_monotonic, _emscripten_throw_longjmp: __emscripten_throw_longjmp, _gmtime_js: __gmtime_js, _localtime_js: __localtime_js, _mktime_js: __mktime_js, _mmap_js: __mmap_js, _munmap_js: __munmap_js, _setitimer_js: __setitimer_js, _tzset_js: __tzset_js, abort: _abort, emscripten_asm_const_int: _emscripten_asm_const_int, emscripten_asm_const_ptr: _emscripten_asm_const_ptr, emscripten_console_error: _emscripten_console_error, emscripten_date_now: _emscripten_date_now, emscripten_get_heap_max: _emscripten_get_heap_max, emscripten_get_now: _emscripten_get_now, emscripten_resize_heap: _emscripten_resize_heap, environ_get: _environ_get, environ_sizes_get: _environ_sizes_get, exit: _exit, fd_close: _fd_close, fd_fdstat_get: _fd_fdstat_get, fd_read: _fd_read, fd_seek: _fd_seek, fd_sync: _fd_sync, fd_write: _fd_write, getaddrinfo: _getaddrinfo, getcontext: _getcontext, getdtablesize: _getdtablesize, gethostbyname_r: _gethostbyname_r, getloadavg: _getloadavg, getnameinfo: _getnameinfo, getprotobyname: _getprotobyname, getprotobynumber: _getprotobynumber, invoke_i, invoke_ii, invoke_iii, invoke_iiii, invoke_iiiii, invoke_iiiiii, invoke_iiiiiii, invoke_iiiiiiii, invoke_iiiiiiiiii, invoke_v, invoke_vi, invoke_vii, invoke_viidii, invoke_viii, invoke_viiii, invoke_viiiii, invoke_viiiiii, makecontext: _makecontext, proc_exit: _proc_exit, strftime: _strftime, strptime: _strptime, swapcontext: _swapcontext };
    Asyncify.instrumentWasmImports(wasmImports);
    createWasm();
    Module["_vrzno_expose_inc_zrefcount"] = createExportWrapper("vrzno_expose_inc_zrefcount");
    Module["_vrzno_expose_dec_zrefcount"] = createExportWrapper("vrzno_expose_dec_zrefcount");
    Module["_vrzno_expose_zrefcount"] = createExportWrapper("vrzno_expose_zrefcount");
    Module["_vrzno_expose_inc_crefcount"] = createExportWrapper("vrzno_expose_inc_crefcount");
    Module["_vrzno_expose_dec_crefcount"] = createExportWrapper("vrzno_expose_dec_crefcount");
    Module["_vrzno_expose_crefcount"] = createExportWrapper("vrzno_expose_crefcount");
    Module["_vrzno_expose_efree"] = createExportWrapper("vrzno_expose_efree");
    Module["_vrzno_expose_create_bool"] = createExportWrapper("vrzno_expose_create_bool");
    Module["_vrzno_expose_create_null"] = createExportWrapper("vrzno_expose_create_null");
    Module["_vrzno_expose_create_undef"] = createExportWrapper("vrzno_expose_create_undef");
    Module["_vrzno_expose_create_long"] = createExportWrapper("vrzno_expose_create_long");
    Module["_vrzno_expose_create_double"] = createExportWrapper("vrzno_expose_create_double");
    Module["_vrzno_expose_create_string"] = createExportWrapper("vrzno_expose_create_string");
    Module["_vrzno_expose_create_object_for_target"] = createExportWrapper("vrzno_expose_create_object_for_target");
    Module["_vrzno_expose_create_params"] = createExportWrapper("vrzno_expose_create_params");
    Module["_vrzno_expose_set_param"] = createExportWrapper("vrzno_expose_set_param");
    Module["_vrzno_expose_zval_is_target"] = createExportWrapper("vrzno_expose_zval_is_target");
    Module["_vrzno_expose_object_keys"] = createExportWrapper("vrzno_expose_object_keys");
    Module["_vrzno_expose_zval_dump"] = createExportWrapper("vrzno_expose_zval_dump");
    Module["_vrzno_expose_type"] = createExportWrapper("vrzno_expose_type");
    Module["_vrzno_expose_callable"] = createExportWrapper("vrzno_expose_callable");
    Module["_vrzno_expose_long"] = createExportWrapper("vrzno_expose_long");
    Module["_vrzno_expose_double"] = createExportWrapper("vrzno_expose_double");
    Module["_vrzno_expose_string"] = createExportWrapper("vrzno_expose_string");
    Module["_vrzno_expose_property_pointer"] = createExportWrapper("vrzno_expose_property_pointer");
    Module["_vrzno_exec_callback"] = createExportWrapper("vrzno_exec_callback");
    Module["_vrzno_del_callback"] = createExportWrapper("vrzno_del_callback");
    Module["_zend_eval_string"] = createExportWrapper("zend_eval_string");
    Module["_php_embed_init"] = createExportWrapper("php_embed_init");
    Module["_php_embed_shutdown"] = createExportWrapper("php_embed_shutdown");
    Module["_pib_init"] = createExportWrapper("pib_init");
    var _memcpy = createExportWrapper("memcpy");
    var _free = createExportWrapper("free");
    var _malloc = createExportWrapper("malloc");
    var setTempRet0 = createExportWrapper("setTempRet0");
    var ___errno_location = createExportWrapper("__errno_location");
    var _fflush = Module["_fflush"] = createExportWrapper("fflush");
    var _htons = createExportWrapper("htons");
    var _ntohs = createExportWrapper("ntohs");
    var _htonl = createExportWrapper("htonl");
    Module["_pib_exec"] = createExportWrapper("pib_exec");
    Module["_pib_run"] = createExportWrapper("pib_run");
    Module["_pib_tokenize"] = createExportWrapper("pib_tokenize");
    Module["_pib_destroy"] = createExportWrapper("pib_destroy");
    Module["_pib_refresh"] = createExportWrapper("pib_refresh");
    Module["_exec_callback"] = createExportWrapper("exec_callback");
    Module["_del_callback"] = createExportWrapper("del_callback");
    var _main = Module["_main"] = createExportWrapper("main");
    var ___funcs_on_exit = createExportWrapper("__funcs_on_exit");
    var _emscripten_builtin_memalign = createExportWrapper("emscripten_builtin_memalign");
    var __emscripten_timeout = createExportWrapper("_emscripten_timeout");
    var _setThrew = createExportWrapper("setThrew");
    var _emscripten_stack_init = function() {
      return (_emscripten_stack_init = Module["asm"]["emscripten_stack_init"]).apply(null, arguments);
    };
    var _emscripten_stack_get_end = function() {
      return (_emscripten_stack_get_end = Module["asm"]["emscripten_stack_get_end"]).apply(null, arguments);
    };
    var stackSave = createExportWrapper("stackSave");
    var stackRestore = createExportWrapper("stackRestore");
    var stackAlloc = createExportWrapper("stackAlloc");
    var _emscripten_stack_get_current = function() {
      return (_emscripten_stack_get_current = Module["asm"]["emscripten_stack_get_current"]).apply(null, arguments);
    };
    var dynCall_vi = Module["dynCall_vi"] = createExportWrapper("dynCall_vi");
    var dynCall_iiii = Module["dynCall_iiii"] = createExportWrapper("dynCall_iiii");
    var dynCall_iii = Module["dynCall_iii"] = createExportWrapper("dynCall_iii");
    var dynCall_ii = Module["dynCall_ii"] = createExportWrapper("dynCall_ii");
    var dynCall_iiiii = Module["dynCall_iiiii"] = createExportWrapper("dynCall_iiiii");
    var dynCall_iiiiii = Module["dynCall_iiiiii"] = createExportWrapper("dynCall_iiiiii");
    var dynCall_vii = Module["dynCall_vii"] = createExportWrapper("dynCall_vii");
    var dynCall_viii = Module["dynCall_viii"] = createExportWrapper("dynCall_viii");
    var dynCall_v = Module["dynCall_v"] = createExportWrapper("dynCall_v");
    var dynCall_viiiii = Module["dynCall_viiiii"] = createExportWrapper("dynCall_viiiii");
    var dynCall_iiiiiii = Module["dynCall_iiiiiii"] = createExportWrapper("dynCall_iiiiiii");
    var dynCall_i = Module["dynCall_i"] = createExportWrapper("dynCall_i");
    var dynCall_viiii = Module["dynCall_viiii"] = createExportWrapper("dynCall_viiii");
    var dynCall_iiiiiiii = Module["dynCall_iiiiiiii"] = createExportWrapper("dynCall_iiiiiiii");
    Module["dynCall_vij"] = createExportWrapper("dynCall_vij");
    Module["dynCall_ji"] = createExportWrapper("dynCall_ji");
    Module["dynCall_viiiiiiii"] = createExportWrapper("dynCall_viiiiiiii");
    var dynCall_iiiiiiiiii = Module["dynCall_iiiiiiiiii"] = createExportWrapper("dynCall_iiiiiiiiii");
    Module["dynCall_viiiiiiiii"] = createExportWrapper("dynCall_viiiiiiiii");
    Module["dynCall_viiiiiii"] = createExportWrapper("dynCall_viiiiiii");
    var dynCall_viiiiii = Module["dynCall_viiiiii"] = createExportWrapper("dynCall_viiiiii");
    Module["dynCall_ij"] = createExportWrapper("dynCall_ij");
    Module["dynCall_iiiij"] = createExportWrapper("dynCall_iiiij");
    Module["dynCall_vijii"] = createExportWrapper("dynCall_vijii");
    Module["dynCall_iijj"] = createExportWrapper("dynCall_iijj");
    Module["dynCall_iij"] = createExportWrapper("dynCall_iij");
    Module["dynCall_iijii"] = createExportWrapper("dynCall_iijii");
    Module["dynCall_iiji"] = createExportWrapper("dynCall_iiji");
    Module["dynCall_iiiiiij"] = createExportWrapper("dynCall_iiiiiij");
    Module["dynCall_iiid"] = createExportWrapper("dynCall_iiid");
    Module["dynCall_iiij"] = createExportWrapper("dynCall_iiij");
    Module["dynCall_dii"] = createExportWrapper("dynCall_dii");
    Module["dynCall_jii"] = createExportWrapper("dynCall_jii");
    Module["dynCall_iiiiiiiii"] = createExportWrapper("dynCall_iiiiiiiii");
    Module["dynCall_vid"] = createExportWrapper("dynCall_vid");
    Module["dynCall_di"] = createExportWrapper("dynCall_di");
    Module["dynCall_iiiiijii"] = createExportWrapper("dynCall_iiiiijii");
    Module["dynCall_j"] = createExportWrapper("dynCall_j");
    Module["dynCall_jj"] = createExportWrapper("dynCall_jj");
    Module["dynCall_jiij"] = createExportWrapper("dynCall_jiij");
    Module["dynCall_iiiiji"] = createExportWrapper("dynCall_iiiiji");
    Module["dynCall_iiiijii"] = createExportWrapper("dynCall_iiiijii");
    Module["dynCall_viiji"] = createExportWrapper("dynCall_viiji");
    Module["dynCall_viijii"] = createExportWrapper("dynCall_viijii");
    Module["dynCall_iiiiiiiiiii"] = createExportWrapper("dynCall_iiiiiiiiiii");
    Module["dynCall_iiiijji"] = createExportWrapper("dynCall_iiiijji");
    Module["dynCall_dd"] = createExportWrapper("dynCall_dd");
    Module["dynCall_ddd"] = createExportWrapper("dynCall_ddd");
    Module["dynCall_jiijii"] = createExportWrapper("dynCall_jiijii");
    Module["dynCall_viiijii"] = createExportWrapper("dynCall_viiijii");
    Module["dynCall_jiiiji"] = createExportWrapper("dynCall_jiiiji");
    Module["dynCall_jiiji"] = createExportWrapper("dynCall_jiiji");
    Module["dynCall_iiiji"] = createExportWrapper("dynCall_iiiji");
    var dynCall_viidii = Module["dynCall_viidii"] = createExportWrapper("dynCall_viidii");
    Module["dynCall_jiji"] = createExportWrapper("dynCall_jiji");
    Module["dynCall_iidiiii"] = createExportWrapper("dynCall_iidiiii");
    var _asyncify_start_unwind = createExportWrapper("asyncify_start_unwind");
    var _asyncify_stop_unwind = createExportWrapper("asyncify_stop_unwind");
    var _asyncify_start_rewind = createExportWrapper("asyncify_start_rewind");
    var _asyncify_stop_rewind = createExportWrapper("asyncify_stop_rewind");
    Module["___start_em_js"] = 3584249;
    Module["___stop_em_js"] = 3584891;
    function invoke_iiii(index, a1, a2, a3) {
      var sp = stackSave();
      try {
        return dynCall_iiii(index, a1, a2, a3);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_vi(index, a1) {
      var sp = stackSave();
      try {
        dynCall_vi(index, a1);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_ii(index, a1) {
      var sp = stackSave();
      try {
        return dynCall_ii(index, a1);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_viii(index, a1, a2, a3) {
      var sp = stackSave();
      try {
        dynCall_viii(index, a1, a2, a3);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_v(index) {
      var sp = stackSave();
      try {
        dynCall_v(index);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_iii(index, a1, a2) {
      var sp = stackSave();
      try {
        return dynCall_iii(index, a1, a2);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_vii(index, a1, a2) {
      var sp = stackSave();
      try {
        dynCall_vii(index, a1, a2);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_iiiiii(index, a1, a2, a3, a4, a5) {
      var sp = stackSave();
      try {
        return dynCall_iiiiii(index, a1, a2, a3, a4, a5);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_iiiiiii(index, a1, a2, a3, a4, a5, a6) {
      var sp = stackSave();
      try {
        return dynCall_iiiiiii(index, a1, a2, a3, a4, a5, a6);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_i(index) {
      var sp = stackSave();
      try {
        return dynCall_i(index);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_iiiii(index, a1, a2, a3, a4) {
      var sp = stackSave();
      try {
        return dynCall_iiiii(index, a1, a2, a3, a4);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_viiii(index, a1, a2, a3, a4) {
      var sp = stackSave();
      try {
        dynCall_viiii(index, a1, a2, a3, a4);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_iiiiiiiiii(index, a1, a2, a3, a4, a5, a6, a7, a8, a9) {
      var sp = stackSave();
      try {
        return dynCall_iiiiiiiiii(index, a1, a2, a3, a4, a5, a6, a7, a8, a9);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_iiiiiiii(index, a1, a2, a3, a4, a5, a6, a7) {
      var sp = stackSave();
      try {
        return dynCall_iiiiiiii(index, a1, a2, a3, a4, a5, a6, a7);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_viiiiii(index, a1, a2, a3, a4, a5, a6) {
      var sp = stackSave();
      try {
        dynCall_viiiiii(index, a1, a2, a3, a4, a5, a6);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_viiiii(index, a1, a2, a3, a4, a5) {
      var sp = stackSave();
      try {
        dynCall_viiiii(index, a1, a2, a3, a4, a5);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function invoke_viidii(index, a1, a2, a3, a4, a5) {
      var sp = stackSave();
      try {
        dynCall_viidii(index, a1, a2, a3, a4, a5);
      } catch (e) {
        stackRestore(sp);
        if (e !== e + 0) throw e;
        _setThrew(1, 0);
      }
    }
    function applySignatureConversions(exports) {
      exports = Object.assign({}, exports);
      var makeWrapper_pp = (f) => (a0) => f(a0) >>> 0;
      var makeWrapper_p = (f) => () => f() >>> 0;
      var makeWrapper_ppp = (f) => (a0, a1) => f(a0, a1) >>> 0;
      exports["malloc"] = makeWrapper_pp(exports["malloc"]);
      exports["__errno_location"] = makeWrapper_p(exports["__errno_location"]);
      exports["emscripten_builtin_memalign"] = makeWrapper_ppp(exports["emscripten_builtin_memalign"]);
      exports["emscripten_stack_get_base"] = makeWrapper_p(exports["emscripten_stack_get_base"]);
      exports["emscripten_stack_get_end"] = makeWrapper_p(exports["emscripten_stack_get_end"]);
      exports["stackSave"] = makeWrapper_p(exports["stackSave"]);
      exports["stackAlloc"] = makeWrapper_pp(exports["stackAlloc"]);
      exports["emscripten_stack_get_current"] = makeWrapper_p(exports["emscripten_stack_get_current"]);
      return exports;
    }
    Module["addRunDependency"] = addRunDependency;
    Module["removeRunDependency"] = removeRunDependency;
    Module["FS_createPath"] = FS.createPath;
    Module["FS_createDataFile"] = FS.createDataFile;
    Module["FS_createLazyFile"] = FS.createLazyFile;
    Module["FS_createDevice"] = FS.createDevice;
    Module["FS_unlink"] = FS.unlink;
    Module["ccall"] = ccall;
    Module["getValue"] = getValue;
    Module["UTF8ToString"] = UTF8ToString;
    Module["lengthBytesUTF8"] = lengthBytesUTF8;
    Module["FS_createPreloadedFile"] = FS.createPreloadedFile;
    Module["FS"] = FS;
    var missingLibrarySymbols = ["writeI53ToI64", "writeI53ToI64Clamped", "writeI53ToI64Signaling", "writeI53ToU64Clamped", "writeI53ToU64Signaling", "readI53FromU64", "convertI32PairToI53", "convertU32PairToI53", "traverseStack", "getCallstack", "emscriptenLog", "convertPCtoSourceLocation", "runMainThreadEmAsm", "jstoi_s", "listenOnce", "autoResumeAudioContext", "dynCallLegacy", "getDynCaller", "dynCall", "setWasmTableEntry", "safeSetTimeout", "asmjsMangle", "handleAllocatorInit", "HandleAllocator", "getNativeTypeSize", "STACK_SIZE", "STACK_ALIGN", "POINTER_SIZE", "ASSERTIONS", "cwrap", "uleb128Encode", "generateFuncType", "convertJsFunctionToWasm", "getEmptyTableSlot", "updateTableMap", "getFunctionAddress", "addFunction", "removeFunction", "reallyNegative", "unSign", "strLen", "reSign", "formatString", "intArrayToString", "AsciiToString", "UTF16ToString", "stringToUTF16", "lengthBytesUTF16", "UTF32ToString", "stringToUTF32", "lengthBytesUTF32", "registerKeyEventCallback", "maybeCStringToJsString", "findEventTarget", "findCanvasEventTarget", "getBoundingClientRect", "fillMouseEventData", "registerMouseEventCallback", "registerWheelEventCallback", "registerUiEventCallback", "registerFocusEventCallback", "fillDeviceOrientationEventData", "registerDeviceOrientationEventCallback", "fillDeviceMotionEventData", "registerDeviceMotionEventCallback", "screenOrientation", "fillOrientationChangeEventData", "registerOrientationChangeEventCallback", "fillFullscreenChangeEventData", "registerFullscreenChangeEventCallback", "JSEvents_requestFullscreen", "JSEvents_resizeCanvasForFullscreen", "registerRestoreOldStyle", "hideEverythingExceptGivenElement", "restoreHiddenElements", "setLetterbox", "softFullscreenResizeWebGLRenderTarget", "doRequestFullscreen", "fillPointerlockChangeEventData", "registerPointerlockChangeEventCallback", "registerPointerlockErrorEventCallback", "requestPointerLock", "fillVisibilityChangeEventData", "registerVisibilityChangeEventCallback", "registerTouchEventCallback", "fillGamepadEventData", "registerGamepadEventCallback", "registerBeforeUnloadEventCallback", "fillBatteryEventData", "battery", "registerBatteryEventCallback", "setCanvasElementSize", "getCanvasElementSize", "jsStackTrace", "stackTrace", "checkWasiClock", "wasiRightsToMuslOFlags", "wasiOFlagsToMuslOFlags", "createDyncallWrapper", "setImmediateWrapped", "clearImmediateWrapped", "polyfillSetImmediate", "getPromise", "makePromise", "idsToPromises", "makePromiseCallback", "ExceptionInfo", "setMainLoop", "_setNetworkCallback", "heapObjectForWebGLType", "heapAccessShiftForWebGLHeap", "webgl_enable_ANGLE_instanced_arrays", "webgl_enable_OES_vertex_array_object", "webgl_enable_WEBGL_draw_buffers", "webgl_enable_WEBGL_multi_draw", "emscriptenWebGLGet", "computeUnpackAlignedImageSize", "colorChannelsInGlTextureFormat", "emscriptenWebGLGetTexPixelData", "__glGenObject", "emscriptenWebGLGetUniform", "webglGetUniformLocation", "webglPrepareUniformLocationsBeforeFirstUse", "webglGetLeftBracePos", "emscriptenWebGLGetVertexAttrib", "__glGetActiveAttribOrUniform", "writeGLArray", "registerWebGlEventCallback", "SDL_unicode", "SDL_ttfContext", "SDL_audio", "GLFW_Window", "ALLOC_NORMAL", "ALLOC_STACK", "allocate", "writeStringToMemory", "writeAsciiToMemory"];
    missingLibrarySymbols.forEach(missingLibrarySymbol);
    var unexportedSymbols = ["run", "addOnPreRun", "addOnInit", "addOnPreMain", "addOnExit", "addOnPostRun", "FS_createFolder", "FS_createLink", "out", "err", "callMain", "abort", "keepRuntimeAlive", "wasmMemory", "stackAlloc", "stackSave", "stackRestore", "getTempRet0", "setTempRet0", "writeStackCookie", "checkStackCookie", "readI53FromI64", "convertI32PairToI53Checked", "ptrToString", "zeroMemory", "exitJS", "getHeapMax", "growMemory", "ENV", "MONTH_DAYS_REGULAR", "MONTH_DAYS_LEAP", "MONTH_DAYS_REGULAR_CUMULATIVE", "MONTH_DAYS_LEAP_CUMULATIVE", "isLeapYear", "ydayFromDate", "arraySum", "addDays", "ERRNO_CODES", "ERRNO_MESSAGES", "setErrNo", "inetPton4", "inetNtop4", "inetPton6", "inetNtop6", "readSockaddr", "writeSockaddr", "DNS", "getHostByName", "Protocols", "Sockets", "initRandomFill", "randomFill", "timers", "warnOnce", "UNWIND_CACHE", "readEmAsmArgsArray", "readEmAsmArgs", "runEmAsmFunction", "jstoi_q", "getExecutableName", "getWasmTableEntry", "handleException", "runtimeKeepalivePush", "runtimeKeepalivePop", "callUserCallback", "maybeExit", "asyncLoad", "alignMemory", "mmapAlloc", "getCFunc", "sigToWasmTypes", "freeTableIndexes", "functionsInTableMap", "setValue", "PATH", "PATH_FS", "UTF8Decoder", "UTF8ArrayToString", "stringToUTF8Array", "stringToUTF8", "intArrayFromString", "stringToAscii", "UTF16Decoder", "stringToNewUTF8", "stringToUTF8OnStack", "writeArrayToMemory", "JSEvents", "specialHTMLTargets", "currentFullscreenStrategy", "restoreOldWindowedStyle", "demangle", "demangleAll", "ExitStatus", "getEnvStrings", "doReadv", "doWritev", "promiseMap", "uncaughtExceptionCount", "exceptionLast", "exceptionCaught", "Browser", "wget", "SYSCALLS", "getSocketFromFD", "getSocketAddress", "preloadPlugins", "FS_modeStringToFlags", "FS_getMode", "FS_stdin_getChar_buffer", "FS_stdin_getChar", "MEMFS", "TTY", "PIPEFS", "SOCKFS", "tempFixedLengthArray", "miniTempWebGLFloatBuffers", "miniTempWebGLIntBuffers", "GL", "emscripten_webgl_power_preferences", "AL", "GLUT", "EGL", "GLEW", "IDBStore", "runAndAbortIfError", "Asyncify", "Fibers", "SDL", "SDL_gfx", "GLFW", "allocateUTF8", "allocateUTF8OnStack", "IDBFS"];
    unexportedSymbols.forEach(unexportedRuntimeSymbol);
    var calledRun;
    dependenciesFulfilled = function runCaller() {
      if (!calledRun) run();
      if (!calledRun) dependenciesFulfilled = runCaller;
    };
    function callMain() {
      assert(runDependencies == 0, 'cannot call main when async dependencies remain! (listen on Module["onRuntimeInitialized"])');
      assert(__ATPRERUN__.length == 0, "cannot call main when preRun functions remain to be called");
      var entryFunction = _main;
      var argc = 0;
      var argv = 0;
      try {
        var ret = entryFunction(argc, argv);
        exitJS(ret, true);
        return ret;
      } catch (e) {
        return handleException(e);
      }
    }
    function stackCheckInit() {
      _emscripten_stack_init();
      writeStackCookie();
    }
    function run() {
      if (runDependencies > 0) {
        return;
      }
      stackCheckInit();
      preRun();
      if (runDependencies > 0) {
        return;
      }
      function doRun() {
        if (calledRun) return;
        calledRun = true;
        Module["calledRun"] = true;
        if (ABORT) return;
        initRuntime();
        preMain();
        readyPromiseResolve(Module);
        if (Module["onRuntimeInitialized"]) Module["onRuntimeInitialized"]();
        if (shouldRunNow) callMain();
        postRun();
      }
      if (Module["setStatus"]) {
        Module["setStatus"]("Running...");
        setTimeout(function() {
          setTimeout(function() {
            Module["setStatus"]("");
          }, 1);
          doRun();
        }, 1);
      } else {
        doRun();
      }
      checkStackCookie();
    }
    if (Module["preInit"]) {
      if (typeof Module["preInit"] == "function") Module["preInit"] = [Module["preInit"]];
      while (Module["preInit"].length > 0) {
        Module["preInit"].pop()();
      }
    }
    var shouldRunNow = false;
    if (Module["noInitialRun"]) shouldRunNow = false;
    run();
    return moduleArg.ready;
  };
})();
class PhpWeb extends PhpBase {
  constructor(args = {}) {
    super(PHP, args);
  }
  run(phpCode) {
    return this.binary.then((php) => {
      const sync = !php.persist ? Promise.resolve() : new Promise((accept) => php.FS.syncfs(true, (err2) => {
        if (err2) console.warn(err2);
        accept();
      }));
      const run2 = sync.then(() => super.run(phpCode));
      if (!php.persist) {
        return run2;
      }
      return run2.then(() => new Promise((accept) => php.FS.syncfs(false, (err2) => {
        if (err2) console.warn(err2);
        accept(run2);
      })));
    }).finally(() => this.flush());
  }
  exec(phpCode) {
    return this.binary.then((php) => {
      const sync = new Promise((accept) => php.FS.syncfs(true, (err2) => {
        if (err2) console.warn(err2);
        accept();
      }));
      const run2 = sync.then(() => super.exec(phpCode));
      return run2.then(() => new Promise((accept) => php.FS.syncfs(false, (err2) => {
        if (err2) console.warn(err2);
        accept(run2);
      })));
    }).finally(() => this.flush());
  }
}
var u8 = Uint8Array, u16 = Uint16Array, i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start) {
  var b = new u16(31);
  for (var i2 = 0; i2 < 31; ++i2) {
    b[i2] = start += 1 << eb[i2 - 1];
  }
  var r = new i32(b[30]);
  for (var i2 = 1; i2 < 30; ++i2) {
    for (var j = b[i2]; j < b[i2 + 1]; ++j) {
      r[j] = j - b[i2] << 5 | i2;
    }
  }
  return { b, r };
};
var _a = freb(fleb, 2), fl = _a.b, revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0), fd = _b.b;
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
  var x = (i & 43690) >> 1 | (i & 21845) << 1;
  x = (x & 52428) >> 2 | (x & 13107) << 2;
  x = (x & 61680) >> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var hMap = function(cd, mb, r) {
  var s = cd.length;
  var i2 = 0;
  var l = new u16(mb);
  for (; i2 < s; ++i2) {
    if (cd[i2])
      ++l[cd[i2] - 1];
  }
  var le = new u16(mb);
  for (i2 = 1; i2 < mb; ++i2) {
    le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        var sv = i2 << 4 | cd[i2];
        var r_1 = mb - cd[i2];
        var v = le[cd[i2] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i2 = 0; i2 < s; ++i2) {
      if (cd[i2]) {
        co[i2] = rev[le[cd[i2] - 1]++] >> 15 - cd[i2];
      }
    }
  }
  return co;
};
var flt = new u8(288);
for (var i = 0; i < 144; ++i)
  flt[i] = 8;
for (var i = 144; i < 256; ++i)
  flt[i] = 9;
for (var i = 256; i < 280; ++i)
  flt[i] = 7;
for (var i = 280; i < 288; ++i)
  flt[i] = 8;
var fdt = new u8(32);
for (var i = 0; i < 32; ++i)
  fdt[i] = 5;
var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
  var m = a[0];
  for (var i2 = 1; i2 < a.length; ++i2) {
    if (a[i2] > m)
      m = a[i2];
  }
  return m;
};
var bits = function(d, p, m) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  return new u8(v.subarray(s, e));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var inflt = function(dat, st, buf, dict) {
  var sl = dat.length, dl = dict ? dict.length : 0;
  if (!sl || st.f && !st.l)
    return buf || new u8(0);
  var noBuf = !buf;
  var resize = noBuf || st.i != 2;
  var noSt = st.i;
  if (noBuf)
    buf = new u8(sl * 3);
  var cbuf = function(l2) {
    var bl = buf.length;
    if (l2 > bl) {
      var nbuf = new u8(Math.max(bl * 2, l2));
      nbuf.set(buf);
      buf = nbuf;
    }
  };
  var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
  var tbts = sl * 8;
  do {
    if (!lm) {
      final = bits(dat, pos, 1);
      var type = bits(dat, pos + 1, 3);
      pos += 3;
      if (!type) {
        var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
        if (t > sl) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + l);
        buf.set(dat.subarray(s, t), bt);
        st.b = bt += l, st.p = pos = t * 8, st.f = final;
        continue;
      } else if (type == 1)
        lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
      else if (type == 2) {
        var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
        var tl = hLit + bits(dat, pos + 5, 31) + 1;
        pos += 14;
        var ldt = new u8(tl);
        var clt = new u8(19);
        for (var i2 = 0; i2 < hcLen; ++i2) {
          clt[clim[i2]] = bits(dat, pos + i2 * 3, 7);
        }
        pos += hcLen * 3;
        var clb = max(clt), clbmsk = (1 << clb) - 1;
        var clm = hMap(clt, clb, 1);
        for (var i2 = 0; i2 < tl; ) {
          var r = clm[bits(dat, pos, clbmsk)];
          pos += r & 15;
          var s = r >> 4;
          if (s < 16) {
            ldt[i2++] = s;
          } else {
            var c = 0, n = 0;
            if (s == 16)
              n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i2 - 1];
            else if (s == 17)
              n = 3 + bits(dat, pos, 7), pos += 3;
            else if (s == 18)
              n = 11 + bits(dat, pos, 127), pos += 7;
            while (n--)
              ldt[i2++] = c;
          }
        }
        var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
        lbt = max(lt);
        dbt = max(dt);
        lm = hMap(lt, lbt, 1);
        dm = hMap(dt, dbt, 1);
      } else
        err(1);
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
    }
    if (resize)
      cbuf(bt + 131072);
    var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
    var lpos = pos;
    for (; ; lpos = pos) {
      var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
      pos += c & 15;
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
      if (!c)
        err(2);
      if (sym < 256)
        buf[bt++] = sym;
      else if (sym == 256) {
        lpos = pos, lm = null;
        break;
      } else {
        var add = sym - 254;
        if (sym > 264) {
          var i2 = sym - 257, b = fleb[i2];
          add = bits(dat, pos, (1 << b) - 1) + fl[i2];
          pos += b;
        }
        var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
        if (!d)
          err(3);
        pos += d & 15;
        var dt = fd[dsym];
        if (dsym > 3) {
          var b = fdeb[dsym];
          dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
        }
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + 131072);
        var end = bt + add;
        if (bt < dt) {
          var shift = dl - dt, dend = Math.min(dt, end);
          if (shift + bt < 0)
            err(3);
          for (; bt < dend; ++bt)
            buf[bt] = dict[shift + bt];
        }
        for (; bt < end; ++bt)
          buf[bt] = buf[bt - dt];
      }
    }
    st.l = lm, st.p = lpos, st.b = bt, st.f = final;
    if (lm)
      final = 1, st.m = lbt, st.d = dm, st.n = dbt;
  } while (!final);
  return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var et = /* @__PURE__ */ new u8(0);
var b2 = function(d, b) {
  return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
  return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
  return b4(d, b) + b4(d, b + 4) * 4294967296;
};
function inflateSync(data, opts) {
  return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}
var dutf8 = function(d) {
  for (var r = "", i2 = 0; ; ) {
    var c = d[i2++];
    var eb = (c > 127) + (c > 223) + (c > 239);
    if (i2 + eb > d.length)
      return { s: r, r: slc(d, i2 - 1) };
    if (!eb)
      r += String.fromCharCode(c);
    else if (eb == 3) {
      c = ((c & 15) << 18 | (d[i2++] & 63) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
    } else if (eb & 1)
      r += String.fromCharCode((c & 31) << 6 | d[i2++] & 63);
    else
      r += String.fromCharCode((c & 15) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63);
  }
};
function strFromU8(dat, latin1) {
  if (latin1) {
    var r = "";
    for (var i2 = 0; i2 < dat.length; i2 += 16384)
      r += String.fromCharCode.apply(null, dat.subarray(i2, i2 + 16384));
    return r;
  } else if (td) {
    return td.decode(dat);
  } else {
    var _a2 = dutf8(dat), s = _a2.s, r = _a2.r;
    if (r.length)
      err(8);
    return s;
  }
}
var slzh = function(d, b) {
  return b + 30 + b2(d, b + 26) + b2(d, b + 28);
};
var zh = function(d, b, z) {
  var fnl = b2(d, b + 28), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl, bs = b4(d, b + 20);
  var _a2 = z && bs == 4294967295 ? z64e(d, es) : [bs, b4(d, b + 24), b4(d, b + 42)], sc = _a2[0], su = _a2[1], off = _a2[2];
  return [b2(d, b + 10), sc, su, fn, es + b2(d, b + 30) + b2(d, b + 32), off];
};
var z64e = function(d, b) {
  for (; b2(d, b) != 1; b += 4 + b2(d, b + 2))
    ;
  return [b8(d, b + 12), b8(d, b + 4), b8(d, b + 20)];
};
function unzipSync(data, opts) {
  var files = {};
  var e = data.length - 22;
  for (; b4(data, e) != 101010256; --e) {
    if (!e || data.length - e > 65558)
      err(13);
  }
  var c = b2(data, e + 8);
  if (!c)
    return {};
  var o = b4(data, e + 16);
  var z = o == 4294967295 || c == 65535;
  if (z) {
    var ze = b4(data, e - 12);
    z = b4(data, ze) == 101075792;
    if (z) {
      c = b4(data, ze + 32);
      o = b4(data, ze + 48);
    }
  }
  for (var i2 = 0; i2 < c; ++i2) {
    var _a2 = zh(data, o, z), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn = _a2[3], no = _a2[4], off = _a2[5], b = slzh(data, off);
    o = no;
    {
      if (!c_2)
        files[fn] = slc(data, b, b + sc);
      else if (c_2 == 8)
        files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
      else
        err(14, "unknown compression type " + c_2);
    }
  }
  return files;
}
class PhpWorker {
  constructor() {
    this.db = null;
    this.config = {};
    this.phpWeb = null;
    this.wasmBuffer = null;
    this.initialized = false;
    this.onMessage = this.onMessage.bind(this);
    self.onmessage = this.onMessage;
  }
  async _connectToIndexedDB(databaseName, storeName) {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(databaseName, 1);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(storeName)) {
          db.createObjectStore(storeName);
        }
      };
      request.onsuccess = (event) => {
        resolve(event.target.result);
      };
      request.onerror = () => {
        reject(request.error);
      };
    });
  }
  async _getItemFromIndexedDB(databaseConn, storeName, key) {
    if (!databaseConn) {
      throw new Error("Invalid or closed database connection.");
    }
    return new Promise((resolve, reject) => {
      const transaction = databaseConn.transaction(storeName, "readonly");
      const store = transaction.objectStore(storeName);
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error("Database request blocked."));
    });
  }
  async _storeSingleItemToIndexedDB(db, storeName, key, datData) {
    if (!db) {
      throw new Error("Invalid or closed database connection.");
    }
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, "readwrite");
      const store = transaction.objectStore(storeName);
      const request = store.put(datData, key);
      transaction.oncomplete = () => resolve(true);
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
      request.onerror = () => reject(request.error);
    });
  }
  async _storeItemsToIndexedDB(db, storeName, entries) {
    if (!db) {
      throw new Error("Invalid or closed database connection.");
    }
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, "readwrite");
      const store = transaction.objectStore(storeName);
      let successCount = 0;
      transaction.oncomplete = () => resolve(successCount);
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
      entries.forEach(({ key, value }) => {
        const request = store.put(value, key);
        request.onsuccess = () => {
          successCount++;
        };
        request.onerror = () => reject(request.error);
      });
    });
  }
  async _installWasmBin() {
    if (this.config.DEBUG) {
      console.log("[Worker] Retrieving WASM binary...");
    }
    if (this.wasmBuffer) return this.wasmBuffer;
    if (!this.db) {
      this.db = await this._connectToIndexedDB("/wasm", "FILE_DATA");
    }
    const db = this.db;
    const blob = await this._getItemFromIndexedDB(db, "FILE_DATA", "phpWasm");
    if (blob) {
      const uint8Array = blob;
      const buffer = uint8Array.buffer.slice(
        uint8Array.byteOffset,
        uint8Array.byteOffset + uint8Array.byteLength
      );
      this.wasmBuffer = buffer;
      return buffer;
    }
    const res = await fetch("/assets/wasm/php-web.js.zip");
    if (!res.ok) throw new Error(`❌ Failed to download WASM: ${res.status}`);
    const compressed = new Uint8Array(await res.arrayBuffer());
    const unzipped = unzipSync(compressed);
    const wasmFileName = Object.keys(unzipped).find(
      (name) => name.endsWith(".wasm")
    );
    if (!wasmFileName) {
      throw new Error("❌ No WASM file found in the ZIP archive");
    }
    const wasmUint8Array = unzipped[wasmFileName];
    const wasmBuffer = wasmUint8Array.buffer.slice(
      wasmUint8Array.byteOffset,
      wasmUint8Array.byteOffset + wasmUint8Array.byteLength
    );
    this.wasmBuffer = wasmBuffer;
    this._storeSingleItemToIndexedDB(db, "FILE_DATA", "phpWasm", wasmUint8Array).then(() => {
      if (this.config.DEBUG) console.log("[Worker] WASM saved to IndexedDB.");
    }).catch((err2) => {
      if (this.config.DEBUG)
        console.error("[Worker] Failed to save WASM:", err2);
    });
    return wasmBuffer;
  }
  async _markPhpInstalled() {
    if (this.config.DEBUG) {
      console.log("[Worker] Marking local installation as true...");
    }
    const db = await new Promise((resolve, reject) => {
      const request = indexedDB.open("/setup", 1);
      request.onupgradeneeded = (event) => {
        const db2 = event.target.result;
        if (!db2.objectStoreNames.contains("FILE_DATA")) {
          db2.createObjectStore("FILE_DATA");
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    await new Promise((resolve, reject) => {
      const tx = db.transaction("FILE_DATA", "readwrite");
      const store = tx.objectStore("FILE_DATA");
      store.put(true, "installed");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  }
  async _isPhpInstalled() {
    const db = await new Promise((resolve, reject) => {
      const request = indexedDB.open("/setup", 1);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const installed = await new Promise((resolve, reject) => {
      const tx = db.transaction("FILE_DATA", "readonly");
      const store = tx.objectStore("FILE_DATA");
      const req = store.get("installed");
      req.onsuccess = () => resolve(req.result === true);
      req.onerror = () => reject(req.error);
    });
    db.close();
    return installed;
  }
  async _installPhpFiles(wasmBuffer, config = {}, datUrl = "/assets/www/php_api.zip") {
    if (!this.phpWeb) {
      await this._loadPhpWasm(wasmBuffer, config);
      await this.phpWeb.ready;
    }
    const phpBin = await this.phpWeb.binary;
    const alreadyInstalled = await this._isPhpInstalled();
    if (alreadyInstalled) {
      return;
    }
    const response = await fetch(datUrl);
    if (!response.ok)
      throw new Error(
        `❌ Failed to download php_api.zip file: ${response.statusText}`
      );
    const compressedData = new Uint8Array(await response.arrayBuffer());
    const unzipped = unzipSync(compressedData);
    let filesInstalled = 0;
    for (const fileName in unzipped) {
      const content = unzipped[fileName];
      const fullPath = `/www/${fileName}`;
      const parentDir = fullPath.substring(0, fullPath.lastIndexOf("/"));
      try {
        phpBin.FS.mkdirTree(parentDir);
      } catch (e) {
      }
      if (content.length === 0 && fileName.endsWith("/")) {
        try {
          phpBin.FS.mkdir(fullPath);
        } catch (e) {
        }
      } else {
        try {
          phpBin.FS.writeFile(fullPath, content);
          filesInstalled++;
        } catch (writeError) {
          console.error(
            `[Worker] ❌ Failed to write file ${fileName}:`,
            writeError
          );
        }
      }
    }
    await new Promise((resolve, reject) => {
      phpBin.FS.syncfs(false, (err2) => {
        if (err2) {
          console.error("[Worker] ❌ Filesystem sync failed:", err2);
          return reject(err2);
        }
        resolve();
      });
    });
    if (this.config.DEBUG) {
      console.log("[Worker] PHP project installed to VFS");
    }
  }
  async _handleInstallation(config = {}) {
    try {
      const wasmBuffer = await this._installWasmBin();
      await this._installPhpFiles(wasmBuffer, config);
      await this._markPhpInstalled();
      self.postMessage({ type: "installation_finished" });
    } catch (err2) {
      if (this.config.DEBUG) {
        console.error("[Worker] ❌ Installation failed:", err2);
      }
      self.postMessage({ type: "error", error: err2.message });
    }
  }
  _stringEscape(str) {
    return String(str).replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/\r?\n/g, "\\n");
  }
  _buildHeaderVariables(headers) {
    const headerParts = [];
    for (const key in headers) {
      const keyFormatted = "HTTP_" + key.toUpperCase().replace(/-/g, "_");
      const escapedValue = this._stringEscape(headers[key]);
      headerParts.push(`$_SERVER['${keyFormatted}'] = '${escapedValue}';
`);
    }
    return headerParts.join("");
  }
  _buildConfigVariables(config) {
    const headerParts = [];
    for (const key in config) {
      const val = config[key];
      if (typeof val === "boolean") {
        headerParts.push(`$_SERVER['${key}'] = ${val ? "true" : "false"};`);
      } else if (typeof val === "number") {
        headerParts.push(`$_SERVER['${key}'] = ${val};`);
      } else {
        const strVal = this._stringEscape(val);
        headerParts.push(`$_SERVER['${key}'] = '${strVal}';`);
      }
    }
    return headerParts.join("");
  }
  _buildGetVariables(query) {
    const queryParts = [];
    const params = new URLSearchParams(query);
    for (const [key, value] of params.entries()) {
      const escapedKey = this._stringEscape(key);
      const escapedValue = this._stringEscape(value);
      queryParts.push(`$_GET['${escapedKey}'] = '${escapedValue}';`);
    }
    return queryParts.join("");
  }
  _buildPostVariables(payload) {
    const payloadParts = [];
    const params = new URLSearchParams(payload);
    for (const [key, value] of params.entries()) {
      const escapedKey = this._stringEscape(key);
      const escapedValue = this._stringEscape(value);
      payloadParts.push(`$_POST['${escapedKey}'] = '${escapedValue}';`);
    }
    return payloadParts.join("");
  }
  _parseHeaders(headersStr) {
    const headers = {};
    if (!headersStr) return headers;
    const parts = headersStr.split(/;|\r?\n/);
    for (const part of parts) {
      const trimmed = part.trim();
      if (!trimmed) continue;
      const colonIndex = trimmed.indexOf(":");
      if (colonIndex === -1) continue;
      const key = trimmed.slice(0, colonIndex).trim();
      const value = trimmed.slice(colonIndex + 1).trim();
      headers[key] = value;
    }
    return headers;
  }
  _buildPhpServerEnv({ method, query, payload, headersStr, config = {} }) {
    const headerParts = [];
    const headers = this._parseHeaders(headersStr);
    let [requestUri, queryString = ""] = (query ?? "").split("?");
    const entryPoint = config.ENTRY_POINT || null;
    let scriptFilename, scriptName, phpSelf, pathInfo;
    if (entryPoint) {
      scriptFilename = entryPoint;
      const docRoot = config.DOCUMENT_ROOT || "/www";
      scriptName = "/" + entryPoint.replace(new RegExp(`^${docRoot}/?`), "");
      phpSelf = scriptName;
      pathInfo = requestUri;
    } else {
      scriptFilename = requestUri;
      const docRoot = config.DOCUMENT_ROOT || "/www";
      scriptName = "/" + requestUri.replace(new RegExp(`^${docRoot}/?`), "");
      phpSelf = scriptName;
      pathInfo = null;
    }
    const contentType = headers["Content-Type"] || "application/x-www-form-urlencoded";
    headerParts.push(`
      $_SERVER['REMOTE_ADDR']     = '127.0.0.1';
      $_SERVER['CONTENT_TYPE']    = '${this._stringEscape(contentType)}';
      $_SERVER['CONTENT_LENGTH']  = '${(payload ?? "").length}';
      $_SERVER['REQUEST_METHOD']  = '${this._stringEscape(method)}';
      $_SERVER['REQUEST_URI']     = '${this._stringEscape(requestUri)}';
      $_SERVER['QUERY_STRING']    = '${this._stringEscape(queryString)}';
      $_SERVER['SCRIPT_FILENAME'] = '${this._stringEscape(scriptFilename)}';
      $_SERVER['SCRIPT_NAME']     = '${this._stringEscape(scriptName)}';
      $_SERVER['PHP_SELF']        = '${this._stringEscape(phpSelf)}';
      ${pathInfo ? `$_SERVER['PATH_INFO'] = '${this._stringEscape(pathInfo)}';` : ""}
    `);
    headerParts.push(this._buildHeaderVariables(headers));
    headerParts.push(this._buildConfigVariables(config));
    if (method === "GET") {
      headerParts.push(this._buildGetVariables(queryString));
    } else if (method === "POST") {
      headerParts.push(this._buildPostVariables(payload));
    } else {
      headerParts.push(
        `trigger_error("Unsupported HTTP method: ${this._stringEscape(method)}", E_USER_ERROR);`
      );
    }
    return headerParts.join("");
  }
  _captureOutput() {
    const chunks = [];
    const onOutput = (e) => {
      chunks.push(e.detail);
    };
    const onError = (e) => {
      chunks.push(e.detail);
    };
    this.phpWeb.addEventListener("output", onOutput);
    this.phpWeb.addEventListener("error", onError);
    return {
      stop: () => {
        this.phpWeb.removeEventListener("output", onOutput);
        this.phpWeb.removeEventListener("error", onError);
      },
      get: () => chunks.join("")
    };
  }
  async _loadPhpWasm(wasmBin, config = {}) {
    if (this.phpWeb) return;
    if (!wasmBin || wasmBin.byteLength === 0) {
      throw new Error("❌ Invalid WASM buffer: empty or null");
    }
    if (!(wasmBin instanceof ArrayBuffer)) {
      console.error(
        "[Worker] ❌ WASM buffer is not an ArrayBuffer:",
        typeof wasmBin,
        wasmBin.constructor.name
      );
      throw new Error("❌ WASM buffer must be an ArrayBuffer");
    }
    this.phpWeb = new PhpWeb({
      wasmBinary: wasmBin,
      persist: { mountPath: "/www" }
    });
    await this.phpWeb.ready;
    if (config) {
      this.config = { ...config };
      this.initialized = true;
      if (this.config.DEBUG) {
        console.log("[Worker] PhpWeb WASM loaded and ready");
      }
      self.postMessage({ type: "workerReady" });
    }
  }
  async _runInline(id, code) {
    try {
      await this.phpWeb.refresh();
      const cap = this._captureOutput();
      await this.phpWeb.run(code);
      cap.stop();
      if (this.config.DEBUG) {
        console.log("[Worker] Inline PHP run completed");
      }
      self.postMessage({ id, result: cap.get() });
    } catch (err2) {
      if (this.config.DEBUG) {
        console.log("[Worker] ❌ Error in runInline", err2);
      }
      self.postMessage({ id, result: `PHP ERROR: ${err2.message}` });
    }
  }
  async _runRequest(id, request) {
    try {
      const { method, query, payload, headers } = request;
      const serverEnv = this._buildPhpServerEnv({
        method,
        query,
        payload,
        headersStr: headers,
        config: this.config
      });
      const phpCode = `<?php ${serverEnv}include_once($_SERVER['SCRIPT_FILENAME']);`;
      if (this.config.DEBUG) {
        console.log("[Worker] PHP code to run:", phpCode);
      }
      await this.phpWeb.refresh();
      const cap = this._captureOutput();
      await this.phpWeb.run(phpCode);
      cap.stop();
      self.postMessage({ id, result: cap.get() });
    } catch (err2) {
      if (this.config.DEBUG) {
        console.log("[Worker] ❌ Error in runRequest", err2);
      }
      self.postMessage({ id, result: `PHP ERROR: ${err2.message}` });
    }
  }
  async onMessage(e) {
    const { data: msg } = e;
    if (this.config.DEBUG) {
      console.log("[Worker] Received message", msg);
    }
    if (msg.type === "install") {
      await this._handleInstallation(msg.cnfg);
      return;
    }
    if (msg.type === "loadWasm") {
      try {
        await this._loadPhpWasm(msg.wasmBin, msg.cnfg);
      } catch (err2) {
        self.postMessage({ type: "load_error", error: err2.message });
      }
      return;
    }
    if (!this.initialized) {
      if (this.config.DEBUG) {
        console.log("[Worker] Worker not initialized yet");
      }
      return;
    }
    const { id, request } = msg;
    if (msg.type === "runInline") {
      await this._runInline(id, request.code);
    } else {
      await this._runRequest(id, request);
    }
  }
}
new PhpWorker();
